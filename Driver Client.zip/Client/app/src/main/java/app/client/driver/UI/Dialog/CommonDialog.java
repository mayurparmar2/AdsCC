package app.client.driver.UI.Dialog;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.Window;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;

import app.client.driver.R;
import app.client.driver.Utils.Validator;
import app.client.driver.databinding.CommonLayoutBinding;

public class CommonDialog extends Dialog {

    private Activity activity;
    public int REQUEST_PERMISSION_CAMERA = 2121;
    private final String txtTitle;
    OnItemClickListener listener;

    public interface OnItemClickListener {
        void onAddClick(String gas);
    }

    CommonLayoutBinding binding;

    public CommonDialog(@NonNull Activity activity, String txtTitle, OnItemClickListener listener) {
        super(new ContextThemeWrapper(activity, R.style.CustomDialogTheme));
        this.activity = activity;
        this.txtTitle = txtTitle;
        this.listener = listener;
    }

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        if (getWindow() != null) {
            getWindow().setGravity(17);
            getWindow().setBackgroundDrawableResource(17170445);
        }
        binding = CommonLayoutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.txtTitle.setText(txtTitle);

        binding.llPtype.setVisibility(View.GONE);
        binding.llAddress.setVisibility(View.GONE);
        binding.btnCreate.setOnClickListener(v -> {
            if (Validator.isEmpty(binding.etMoney)) {
                binding.etMoney.setError("Please Enter Amount");
                binding.etMoney.requestFocus();
                return;
            }
            dismiss();
            listener.onAddClick(binding.etMoney.getText().toString());
        });


    }


}

