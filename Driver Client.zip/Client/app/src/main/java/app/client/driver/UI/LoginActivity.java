package app.client.driver.UI;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import app.client.driver.Utils.DriverPreference;
import app.client.driver.Utils.Utils;
import app.client.driver.Utils.Validator;
import app.client.driver.databinding.ActivityLoginBinding;
import app.client.driver.network.ApiService;
import app.client.driver.network.Respose.LoginResponse;
import app.client.driver.network.RetrofitClient2;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends BaseActivity {
    ActivityLoginBinding binding;
    DriverPreference preference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        preference = new DriverPreference(this);
        binding.btnLogin.setOnClickListener(v -> {


            if (Validator.isEmpty(binding.txtUserId)) {
                binding.txtUserId.setError("Trip Id is required");
                binding.txtUserId.requestFocus();
                return;
            }
            if (Validator.isEmpty(binding.EtPassword)) {
                binding.EtPassword.setError("Password is required");
                binding.EtPassword.requestFocus();
                return;
            }
            if (Utils.isInternetAvailable(getApplicationContext())) {
                login(binding.txtUserId.getText().toString(), binding.EtPassword.getText().toString());
            } else {
                Utils.showNoInternetDialog(this);
            }

        });
    }

    private void login(String username, String password) {
        progressHUD.show();
        ApiService apiService = RetrofitClient2.getClient().create(ApiService.class);
        apiService.login(username, password).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                progressHUD.dismiss();
                if (response.isSuccessful()) {
                    LoginResponse loginResponse = response.body();
                    if (!loginResponse.getError()) {
                        preference.setLogin(true);
                        preference.setAuthToken(loginResponse.getData().authToken);
                        preference.setDriverId(loginResponse.getData().driverId);
                        preference.setDriverName(loginResponse.getData().driverName);
                        Log.d("Login", "Login successful, Token: " + loginResponse.getData().driverId + "  " + loginResponse.getData().driverName + " " + loginResponse.getMsg() + "\n" + loginResponse.getData().authToken);
                        startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                        finish();
                    } else {
                        Toast.makeText(LoginActivity.this, loginResponse.getMsg(), Toast.LENGTH_SHORT).show();
                    }

                } else {


                    Log.e("Login", "Login failed");
                    Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                progressHUD.dismiss();


                Log.e("Login", "Login error: " + t.getMessage());
                Toast.makeText(LoginActivity.this, "Login error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}