package app.client.driver.Database.Converter

import androidx.room.TypeConverter
import app.client.driver.Model.PuncherDatum
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PuncherDataConverter {
    @TypeConverter
    fun fromString(value: String): List<PuncherDatum> {
        val listType = object : TypeToken<List<PuncherDatum>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromList(list: List<PuncherDatum>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}