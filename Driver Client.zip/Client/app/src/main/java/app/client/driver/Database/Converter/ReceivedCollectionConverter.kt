package app.client.driver.Database.Converter

import androidx.room.TypeConverter
import app.client.driver.Model.ReceivedCollection
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ReceivedCollectionConverter {
    @TypeConverter
    fun fromString(value: String): List<ReceivedCollection> {
        val listType = object : TypeToken<List<ReceivedCollection>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromList(list: List<ReceivedCollection>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}