package app.client.driver.network.Respose;

import com.google.gson.annotations.SerializedName;

import app.client.driver.Model.LoginToken;

public class LoginResponse {
    @SerializedName("error")
    private Boolean error;
    @SerializedName("status")
    private Integer status;
    @SerializedName("data")
    private LoginToken data;

    @SerializedName("msg")
    private String msg;


    public Boolean getError() {
        return error;
    }

    public Integer getStatus() {
        return status;
    }

    public LoginToken getData() {
        return data;
    }

    public String getMsg() {
        return msg;
    }
}
