package app.client.driver.UI;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import app.client.driver.App;
import app.client.driver.Database.Mvvm.TripViewModel;
import app.client.driver.Database.TripViewModelFactory;
import app.client.driver.Model.Token;
import app.client.driver.R;
import app.client.driver.UI.Fragment.PastTripFragment;
import app.client.driver.UI.Fragment.TodayTripFragment;

import app.client.driver.Utils.DriverPreference;
import app.client.driver.databinding.ActivityHomeBinding;
import app.client.driver.network.ApiService;
import app.client.driver.network.RetrofitClient2;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HomeActivity extends BaseActivity {
    private static HomeActivity activity;
    ActivityHomeBinding binding;
    DriverPreference preference;
    TripViewModel tripViewModel;
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    Toast.makeText(activity, "Permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity, "Permission not granted", Toast.LENGTH_SHORT).show();
                }
            });

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                Toast.makeText(activity, "Permission shouldShowRequestPermissionRationale", Toast.LENGTH_SHORT).show();
            } else {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }


    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        preference = new DriverPreference(this);

        tripViewModel = new ViewModelProvider(this, new TripViewModelFactory(getApplication())).get(TripViewModel.class);

        callPushNotificationApi();
        activity = this;
        askNotificationPermission();


        binding.viewPager.setAdapter(new ScreenSlidePagerAdapter(this));
        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                binding.bottomNavigationView.getMenu().getItem(position).setChecked(true);
            }
        });

        binding.bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.navigation_today) {
                binding.viewPager.setCurrentItem(0);
                return true;
            } else if (item.getItemId() == R.id.navigation_past) {
                binding.viewPager.setCurrentItem(1);
                return true;
            } else {
                return false;
            }
        });


        binding.btnSetting.setOnClickListener(v -> {
            startActivity(new Intent(this, SettingActivity.class));
        });
    }

    private void callPushNotificationApi() {
        ApiService apiService = RetrofitClient2.getClient(preference.getAuthToken()).create(ApiService.class);
        apiService.updateDeviceToken(preference.getDeviceToken()).enqueue(new Callback<Token>() {
            @Override
            public void onResponse(Call<Token> call, Response<Token> response) {
                if (response.isSuccessful()) {
                    if (response.body().success) {
                        Log.d("UPDATETOKEN", ": " + response.body().message);
                    } else {
                        Log.d("UPDATETOKEN", ": " + response.body().message);
                    }
                } else {
                    Log.d("UPDATETOKEN", ": " + response.message());
                }
            }

            @Override
            public void onFailure(Call<Token> call, Throwable t) {
                Log.d("UPDATETOKEN", ": " + t.getMessage().toString());
            }
        });
    }


    public static HomeActivity getInstance() {
        return activity;
    }

    private class ScreenSlidePagerAdapter extends FragmentStateAdapter {
        public ScreenSlidePagerAdapter(@NonNull AppCompatActivity fragmentActivity) {
            super(fragmentActivity);
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            if (position == 1) {
                return new PastTripFragment();
            }
            return new TodayTripFragment(tripViewModel);
        }

        @Override
        public int getItemCount() {
            return 2;
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (binding.viewPager.getCurrentItem() == 1) {
            binding.viewPager.setCurrentItem(0);
        } else {
            App.showExitDialog(this);
        }
    }


    public ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Log.e("MTAG", "onActivityResult :" + result);
                    binding.bottomNavigationView.setSelectedItemId(R.id.navigation_past);
                }
            }
    );
}