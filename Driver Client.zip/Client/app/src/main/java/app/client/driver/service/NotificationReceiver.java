package app.client.driver.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import app.client.driver.UI.SplashActivity;

public class NotificationReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if ("ACTION_ACCEPT".equals(intent.getAction())) {


            if (Driver_Message_Service.ringtone.isPlaying()) {
                Driver_Message_Service.ringtone.stop();
            }
            Driver_Message_Service.notificationManager.cancel(0);


            Intent homeIntent = new Intent(context, SplashActivity.class);
            homeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            context.startActivity(homeIntent);
        }
    }
}