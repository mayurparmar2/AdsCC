package app.client.driver.Model

data class ReceivedCollection(
    val id: String,
    val trip_id: String,
    val amount: Int,
    val payment_type: String,
    val created_at: String,
    val updated_at: String,
    var isUpload: Boolean
) {
    constructor() : this("", "", 0, "", "", "", true)
}