package app.client.driver.Database.Converter

import androidx.room.TypeConverter
import app.client.driver.Model.OtherModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class OtherDataConverter {
    @TypeConverter
    fun fromString(value: String): List<OtherModel> {
        val listType = object : TypeToken<List<OtherModel>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromList(list: List<OtherModel>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}