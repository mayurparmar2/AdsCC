package app.client.driver.UI;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.app.AlertDialog;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;

import java.util.ArrayList;
import java.util.List;

import app.client.driver.Adpater.AddMoneyAdapter;
import app.client.driver.Adpater.AddNoteAdapter;
import app.client.driver.Adpater.AddParkingAdapter;
import app.client.driver.Adpater.AddPoliceAdapter;
import app.client.driver.Adpater.AddReceCollAdapter;
import app.client.driver.Adpater.AddTollAdapter;
import app.client.driver.Adpater.GasAdapter;
import app.client.driver.Adpater.PuncherAdapter;
import app.client.driver.Model.GasDatum;
import app.client.driver.Model.OtherModel;
import app.client.driver.Model.Parking;
import app.client.driver.Model.Police;
import app.client.driver.Model.PuncherDatum;
import app.client.driver.Model.ReceivedCollection;
import app.client.driver.Model.Toll;
import app.client.driver.Model.TripEntity;
import app.client.driver.Model.TripNote;
import app.client.driver.Model.TripsDetails;
import app.client.driver.R;
import app.client.driver.Utils.DriverPreference;
import app.client.driver.UI.Dialog.GasDialog;
import app.client.driver.databinding.ActivityViewPastTripBinding;
import app.client.driver.network.ApiService;
import app.client.driver.network.Respose.TripsDetailsResponse;
import app.client.driver.network.RetrofitClient2;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewPastTripActivity extends BaseActivity {
    ActivityViewPastTripBinding binding;
    private DriverPreference preference;
    private int tripId;
    private ApiService apiService;
    List<GasDatum> gasList;
    List<PuncherDatum> puncherList;
    List<OtherModel> othersList;
    List<Parking> parkingList;
    List<Toll> tollList;
    List<Police> policeList;
    List<ReceivedCollection> collectionList;
    List<TripNote> noteList;
    GasAdapter gasAdapter;
    AddMoneyAdapter othersAdapter;
    private GasDialog gasDialog;
    private AddParkingAdapter parkingAdapter;
    private AddTollAdapter tollAdapter;
    private AddPoliceAdapter policeAdapter;
    private PuncherAdapter puncherAdapter;
    private AddReceCollAdapter collectionAdapter;
    private AddNoteAdapter collectionAdapter2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewPastTripBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        preference = new DriverPreference(this);
        tripId = getIntent().getIntExtra("id", -1);
        apiService = RetrofitClient2.getClient(preference.getAuthToken()).create(ApiService.class);


        binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        getSetData();
    }

    private void getSetData() {
        apiService.showTripDetailsTrip(tripId).enqueue(new Callback<TripsDetailsResponse>() {
            @Override
            public void onResponse(Call<TripsDetailsResponse> call, Response<TripsDetailsResponse> response) {
                if (response.isSuccessful()) {
                    TripsDetailsResponse tripsResponse = response.body();
                    Boolean error = tripsResponse.getError();
                    if (!error) {
                        if (tripsResponse.getData() != null && !tripsResponse.getData().getData().isEmpty()) {
                            TripEntity trip = tripsResponse.getData().getData().get(0);


                            binding.txtDriverName.setText(trip.getDriver_name());
                            binding.txtTripId.setText(trip.getId());
                            binding.txtAdvancePaid.setText(trip.getAdvance_paid());
                            binding.txtCutomerMobile.setText(trip.getCustomer_mobile());
                            binding.txtCutomerName.setText(trip.getCustomer_name());
                            binding.txtPickupLocation.setText(trip.getPickup_location());
                            binding.txtDropLocation.setText(trip.getDrop_location());
                            binding.txtDateTime.setText(trip.getDate_time());
                            binding.txtVehicleName.setText(trip.getVehicle_name());
                            binding.txtTotalCollection.setText(trip.getTotal_collection());

                            gasList = trip.getGasData();
                            puncherList = trip.getPuncherData();
                            policeList = trip.getPoliceChargeData();
                            tollList = trip.getTallTaxData();
                            parkingList = trip.getParkingData();
                            othersList = trip.getOtherData();
                            collectionList = trip.getReceivedCollection();
                            noteList = trip.getTripNotes();


                            gasList = new ArrayList<>();
                            othersList = new ArrayList<>();
                            parkingList = new ArrayList<>();
                            tollList = new ArrayList<>();
                            policeList = new ArrayList<>();
                            puncherList = new ArrayList<>();
                            collectionList = new ArrayList<>();

                            gasList = trip.getGasData();
                            puncherList = trip.getPuncherData();
                            policeList = trip.getPoliceChargeData();
                            tollList = trip.getTallTaxData();
                            parkingList = trip.getParkingData();
                            othersList = trip.getOtherData();
                            collectionList = trip.getReceivedCollection();
                            noteList = trip.getTripNotes();


                            gasAdapter = new GasAdapter(getApplicationContext(), gasList, new GasAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(int position) {

                                }
                            }, new GasAdapter.OnImageClickListener() {
                                @Override
                                public void onItemClick(String url) {
                                    showImageDialog(url);
                                }
                            });
                            binding.rVGas.setAdapter(gasAdapter);

                            puncherAdapter = new PuncherAdapter(getApplicationContext(), puncherList, new PuncherAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(int position) {
                                }
                            }, new PuncherAdapter.OnImageClickListener() {
                                @Override
                                public void onItemClick(String url) {
                                    showImageDialog(url);
                                }
                            });
                            binding.rVPuncher.setAdapter(puncherAdapter);

                            policeAdapter = new AddPoliceAdapter(getApplicationContext(), policeList, new AddPoliceAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(int position) {
                                }
                            });
                            binding.rVPolice.setAdapter(policeAdapter);

                            tollAdapter = new AddTollAdapter(getApplicationContext(), tollList, new AddTollAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(int position) {
                                }
                            });
                            binding.rVToll.setAdapter(tollAdapter);

                            parkingAdapter = new AddParkingAdapter(getApplicationContext(), parkingList, new AddParkingAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(int position) {
                                }
                            });
                            binding.rVParking.setAdapter(parkingAdapter);

                            othersAdapter = new AddMoneyAdapter(getApplicationContext(), othersList, new AddMoneyAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(int position) {
                                }
                            });
                            binding.rVOthers.setAdapter(othersAdapter);


                            collectionAdapter = new AddReceCollAdapter(getApplicationContext(), collectionList, new AddReceCollAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(int position) {
                                }
                            });
                            binding.rVCollection.setAdapter(collectionAdapter);

                            collectionAdapter2 = new AddNoteAdapter(getApplicationContext(), noteList, new AddNoteAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(int position) {
                                }
                            });
                            binding.rvNotes.setAdapter(collectionAdapter2);

                        }
                    } else {

                    }
                }
            }

            @Override
            public void onFailure(Call<TripsDetailsResponse> call, Throwable t) {

            }
        });
    }

    private void showImageDialog(String Url) {


        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_image, null);
        PhotoView imageView = dialogView.findViewById(R.id.dialogImageView);


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView)
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();

        Glide.with(this).load(Url).into(imageView);


    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }
}