package app.client.driver.Database.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import app.client.driver.Model.GasDatum
import app.client.driver.Model.OtherModel
import app.client.driver.Model.Parking
import app.client.driver.Model.Police
import app.client.driver.Model.PuncherDatum
import app.client.driver.Model.ReceivedCollection
import app.client.driver.Model.Toll
import app.client.driver.Model.TripEntity
import app.client.driver.Model.TripNote

@Dao
interface TripDetailDao {
    @Query("SELECT * FROM TripDetail")
    fun getAllTrips(): LiveData<List<TripEntity>>

    @Query("SELECT * FROM TripDetail")
    suspend fun getAllTripsDetail(): List<TripEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(trips: List<TripEntity>)


    @Query("SELECT * FROM TripDetail WHERE id = :id")
    suspend fun getTripDetailById(id: String): TripEntity

    @Query("UPDATE TripDetail SET puncherData = :puncherData WHERE id = :tripId")
    suspend fun updatePuncherData(tripId: String, puncherData: List<PuncherDatum>)

    @Query("UPDATE TripDetail SET gasData = :gasDatum WHERE id = :tripId")
    suspend fun updateGasData(tripId: String, gasDatum: List<GasDatum>)


    @Query("UPDATE TripDetail SET policeChargeData = :policeChargeData WHERE id = :tripId")
    suspend fun updatePoliceData(tripId: String, policeChargeData: List<Police>)


    @Query("UPDATE TripDetail SET policeChargeData = :policeChargeData WHERE id = :tripId")
    fun updatePoliceData2(tripId: String, policeChargeData: List<Police>)


    @Query("UPDATE TripDetail SET parkingData = :parkingData WHERE id = :tripId")
    suspend fun updateParkingData(tripId: String, parkingData: List<Parking>)


    @Query("UPDATE TripDetail SET tallTaxData = :tallTaxData WHERE id = :tripId")
    suspend fun updateTollData(tripId: String, tallTaxData: List<Toll>)

    @Query("UPDATE TripDetail SET otherData = :otherData WHERE id = :tripId")
    suspend fun updateOtherData(tripId: String, otherData: List<OtherModel>)

    @Query("UPDATE TripDetail SET receivedCollection = :receivedCollection WHERE id = :tripId")
    suspend fun updateReceivedCollectionData(
        tripId: String,
        receivedCollection: List<ReceivedCollection>
    )

    @Query("UPDATE TripDetail SET tripNotes = :tripNotes WHERE id = :tripId")
    suspend fun updateTripNoteData(tripId: String, tripNotes: List<TripNote>)

}