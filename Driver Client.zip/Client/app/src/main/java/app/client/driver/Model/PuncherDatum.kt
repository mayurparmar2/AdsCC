package app.client.driver.Model

data class PuncherDatum(
    val id: String,
    val trip_id: String,
    val image: List<String>,
    val amount: Int,
    val payment_type: String,
    val created_at: String,
    val updated_at: String,
    var isUpload: Boolean
) {
    constructor(
        trip_id: String,
        amount: Int,
        payment_type: String,
        image: List<String>,
        created_at: String
    ) : this(
        id = "",
        trip_id = trip_id,
        image = image,
        amount = amount,
        payment_type = payment_type,
        created_at = created_at,
        updated_at = "",
        isUpload = true
    )
}













































