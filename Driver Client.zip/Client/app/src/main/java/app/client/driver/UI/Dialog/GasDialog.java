package app.client.driver.UI.Dialog;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import app.client.driver.R;
import app.client.driver.Utils.Validator;
import app.client.driver.databinding.GasDialogBinding;

public class GasDialog extends Dialog {
    private final String txtTitle;
    private ActivityResultLauncher<Intent> captureImageLauncher;
    private String currentPhotoPath;
    private Activity activity;
    public int REQUEST_PERMISSION_CAMERA = 2121;
    OnItemClickListener listener;
    ImageView imageView = null;
    int tripId;

    public interface OnItemClickListener {
        void onAddClick(int paymentType, int amount, String time);
    }


    public GasDialogBinding binding;
    int payment_type;

    public GasDialog(@NonNull Activity activity, String txtTitle, ActivityResultLauncher<Intent> captureImageLauncher, int tripIs, OnItemClickListener listener) {
        super(new ContextThemeWrapper(activity, R.style.CustomDialogTheme));
        this.activity = activity;
        this.txtTitle = txtTitle;
        this.captureImageLauncher = captureImageLauncher;
        this.listener = listener;
        this.tripId = tripIs;
    }

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        if (getWindow() != null) {
            getWindow().setGravity(17);
            getWindow().setBackgroundDrawableResource(17170445);
        }

        binding = GasDialogBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Calendar calendar = Calendar.getInstance();
        binding.txtTitle.setText(txtTitle);

        Date currentDate = new Date();

        // Format the date and time
        String formattedDate = formatDate(currentDate, "yyyy-MM-dd HH:mm:ss");

        binding.txtTime.setText("Time:" + formattedDate);
        payment_type = 0;
        checkPayment(payment_type);

        binding.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == binding.txtCash.getId()) {
                    payment_type = 0;
                } else {
                    payment_type = 1;
                }
                checkPayment(payment_type);
            }
        });


        binding.img1.setOnClickListener(v -> {
            imageView = binding.img1;
            openCamera();
        });
        binding.img2.setOnClickListener(v -> {
            imageView = binding.img2;
            openCamera();
        });
        binding.img3.setOnClickListener(v -> {
            imageView = binding.img3;
            openCamera();
        });


        binding.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Validator.isEmpty(binding.etMoney)) {
                    binding.etMoney.setError("Please Enter Amount");
                    binding.etMoney.requestFocus();
                    return;
                }
                if (imageView == null) {
                    binding.txtError.setVisibility(View.VISIBLE);
                    binding.txtError.setText("Please view captured image before submit");
                    return;
                }
                listener.onAddClick(payment_type, Integer.parseInt(binding.etMoney.getText().toString()), formattedDate);
            }
        });
    }
    private String formatDate(Date date, String format) {
        SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.getDefault());
        return formatter.format(date);
    }

    private void checkPayment(int paymentType) {


        binding.txtCash.setTextColor(getContext().getColor(R.color.gray2));
        binding.txtOnline.setTextColor(getContext().getColor(R.color.gray2));


        if (paymentType == 0) {
            binding.txtCash.setTextColor(getContext().getColor(R.color.colorPrimary));
            binding.txtCash.setChecked(true);
        } else {
            binding.txtOnline.setTextColor(getContext().getColor(R.color.colorPrimary));
            binding.txtOnline.setChecked(true);
        }
    }

    private void openCamera() {
        if (!hasPermissions(getContext(), ALL_PERMISSIONS_LIST)) {
            ActivityCompat.requestPermissions(activity, ALL_PERMISSIONS_LIST, REQUEST_PERMISSION_CAMERA);
        } else {
            dispatchTakePictureIntent();
        }


    }

    public static final String[] ALL_PERMISSIONS_LIST = getRequiredPermissions().toArray(new String[0]);

    public static List<String> getRequiredPermissions() {
        List<String> permissions = new ArrayList<>();
        permissions.add(Manifest.permission.CAMERA);
        permissions.add(Manifest.permission.CAMERA);
        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        return permissions;
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(context, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    public void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getContext().getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
            }
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(getContext(),
                        this.getContext().getPackageName() + ".provider",
                        photoFile);

                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                captureImageLauncher.launch(takePictureIntent);
            }
        }
    }

    private File createImageFile() throws IOException {


        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getContext().getExternalFilesDir(null);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    public String getCurrentPhotoPath() {
        return currentPhotoPath;
    }

    public void setCapturedImageUrl(Uri url) {
        if (imageView != null) {
            binding.txtError.setVisibility(View.GONE);
            imageView.setImageURI(url);
        }
    }


}

















































































































































































































































