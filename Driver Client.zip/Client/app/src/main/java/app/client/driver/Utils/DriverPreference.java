package app.client.driver.Utils;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

public class DriverPreference {
    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    public DriverPreference(Context context) {
        preferences = context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);
        editor = preferences.edit();
    }

    public boolean isLogin() {
        return preferences.getBoolean("DC_LOGIN", false);
    }

    public void setLogin(boolean login) {
        editor.putBoolean("DC_LOGIN", login);
        editor.commit();
        editor.apply();
    }

    public void setAuthToken(String authToken) {
        editor.putString("DC_AUTHTOKEN", authToken);
        editor.commit();
        editor.apply();
    }

    public String getAuthToken() {
        return preferences.getString("DC_AUTHTOKEN", "");
    }

    public void setDriverId(int id) {
        editor.putInt("DC_DRIVERID", id);
        editor.commit();
        editor.apply();
    }

    public int getDriverId() {
        return preferences.getInt("DC_DRIVERID", 0);
    }

    public void setDriverName(String driverName) {
        editor.putString("DC_DRI_NAME", driverName);
        editor.commit();
        editor.apply();
    }

    public String getDriverName() {
        return preferences.getString("DC_DRI_NAME", "");
    }

    public void setDeviceToken(String deviceToken) {
        editor.putString("DC_DEVICE_TOKEN", deviceToken);
        editor.commit();
        editor.apply();
    }

    public String getDeviceToken() {
        return preferences.getString("DC_DEVICE_TOKEN", "");
    }
}
