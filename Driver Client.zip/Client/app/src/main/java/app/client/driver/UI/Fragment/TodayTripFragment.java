package app.client.driver.UI.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.kaopiz.kprogresshud.KProgressHUD;

import java.util.ArrayList;
import java.util.List;

import app.client.driver.Adpater.TripAdapter;
import app.client.driver.Database.Mvvm.TripViewModel;
import app.client.driver.Model.Trips;
import app.client.driver.UI.HomeActivity;
import app.client.driver.UI.ViewPastTripActivity;
import app.client.driver.UI.ViewTripActivity;
import app.client.driver.Utils.DriverPreference;
import app.client.driver.databinding.ActivityTodayTripBinding;
import app.client.driver.network.ApiService;
import app.client.driver.network.Respose.TripsResponse;
import app.client.driver.network.RetrofitClient2;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TodayTripFragment extends Fragment {
    ActivityTodayTripBinding binding;
    ApiService apiService;
    public static final int REQUEST_CODE = 1;
    TripAdapter todaysTripAdapater;
    List<Trips> list;
    DriverPreference preference;
    TripViewModel tripViewModel;
    KProgressHUD progressHUD;

    public TodayTripFragment(TripViewModel tripViewModel) {
        this.tripViewModel = tripViewModel;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = ActivityTodayTripBinding.inflate(inflater, container, false);
        preference = new DriverPreference(requireActivity());

        progressHUD = KProgressHUD.create(requireActivity())
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please wait")


                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f);
        progressHUD.show();
        apiService = RetrofitClient2.getClient(preference.getAuthToken()).create(ApiService.class);
        list = new ArrayList<>();
        todaysTripAdapater = new TripAdapter(requireActivity(), list, position -> {
            Trips item = list.get(position);

            if (item.getStatus().equals("pending")) {
                Intent intent = new Intent(requireActivity(), ViewTripActivity.class);
                intent.putExtra("id", Integer.parseInt(list.get(position).getId()));
                HomeActivity.getInstance().activityResultLauncher.launch(intent);
            } else {
                Intent intent = new Intent(requireActivity(), ViewPastTripActivity.class);
                intent.putExtra("id", Integer.parseInt(list.get(position).getId()));
                startActivity(intent);
            }

        });
        binding.recycleView.setAdapter(todaysTripAdapater);
        binding.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                showTodaysTrip();
            }
        });
        tripViewModel.getAllTrips().observe(getViewLifecycleOwner(), new Observer<List<Trips>>() {
            @Override
            public void onChanged(List<Trips> trips) {
                binding.swipeContainer.setRefreshing(false);
                if (trips != null && !trips.isEmpty()) {
                    todaysTripAdapater.updateList(trips);
                    tripViewModel.fetchTripDetailFromApi(trips, apiService);
                }
                progressHUD.dismiss();
            }
        });
        showTodaysTrip();
        return binding.getRoot();
    }

    private void showTodaysTrip() {
        binding.swipeContainer.setRefreshing(true);
        Call<TripsResponse> call = apiService.getTodayTripList(preference.getDriverId());
        call.enqueue(new Callback<TripsResponse>() {
            @Override
            public void onResponse(Call<TripsResponse> call, Response<TripsResponse> response) {
                binding.swipeContainer.setRefreshing(false);
                if (response.isSuccessful() && response.body() != null) {
                    TripsResponse tripsResponse = response.body();
                    Boolean error = tripsResponse.getError();
                    if (!error) {
                        if (tripsResponse.getData() != null && !tripsResponse.getData().getData().isEmpty()) {


                            tripViewModel.deleteAllRows();
                            tripViewModel.insertAllTodayslist(response.body().getData().getData());
                            list.addAll(tripsResponse.getData().getData());
                            updateAdapter(tripsResponse.getData().getData());
                            binding.txtNoDataFound.setVisibility(View.GONE);
                            binding.recycleView.setVisibility(View.VISIBLE);
                        } else {
                            binding.txtNoDataFound.setVisibility(View.VISIBLE);
                            binding.recycleView.setVisibility(View.GONE);
                        }
                    }
                } else {


                    Log.e("AddDriver", "TodaysTrip failed");


                }
            }

            @Override
            public void onFailure(Call<TripsResponse> call, Throwable t) {
                binding.swipeContainer.setRefreshing(false);


                Log.e("Login", "TodaysTrip error: " + t.getMessage());


            }
        });

    }

    void updateAdapter(List<Trips> data) {
        if (!data.isEmpty()) {
            todaysTripAdapater.updateList(data);
        } else {
            binding.txtNoDataFound.setVisibility(View.VISIBLE);
            binding.recycleView.setVisibility(View.VISIBLE);
        }
    }


}