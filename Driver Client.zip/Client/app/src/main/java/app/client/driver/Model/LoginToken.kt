package app.client.driver.Model

import com.google.gson.annotations.SerializedName

data class LoginToken(
    @JvmField
    @SerializedName("authToken")
    val authToken: String? = null,
    @JvmField
    @SerializedName("id")
    val driverId: Int = 0,
    @JvmField
    @SerializedName("name")
    val driverName: String? = null
)
