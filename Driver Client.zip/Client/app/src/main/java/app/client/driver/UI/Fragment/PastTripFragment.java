package app.client.driver.UI.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.List;

import app.client.driver.Adpater.PastTripAdapter;
import app.client.driver.Model.Trips;
import app.client.driver.UI.ViewPastTripActivity;
import app.client.driver.Utils.DriverPreference;
import app.client.driver.databinding.ActivityPastTripBinding;
import app.client.driver.network.ApiService;
import app.client.driver.network.Respose.TripsResponse;
import app.client.driver.network.RetrofitClient2;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PastTripFragment extends Fragment {
    ActivityPastTripBinding binding;
    ApiService apiService;
    PastTripAdapter tripAdapter;
    DriverPreference preference;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = ActivityPastTripBinding.inflate(inflater, container, false);
        preference = new DriverPreference(requireActivity());

        apiService = RetrofitClient2.getClient(preference.getAuthToken()).create(ApiService.class);

        List<Trips> list = new ArrayList<>();

        tripAdapter = new PastTripAdapter(requireActivity(), list, position -> {
            Intent intent = new Intent(requireActivity(), ViewPastTripActivity.class);
            intent.putExtra("id", Integer.parseInt(list.get(position).getId()));
            startActivity(intent);
        });
        binding.recycleView.setAdapter(tripAdapter);
        binding.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                showTodaysTrip();
            }
        });

        showTodaysTrip();

        return binding.getRoot();
    }


    private void showTodaysTrip() {
        binding.swipeContainer.setRefreshing(true);
        Call<TripsResponse> call = apiService.getPastTripList(preference.getDriverId());
        call.enqueue(new Callback<TripsResponse>() {
            @Override
            public void onResponse(Call<TripsResponse> call, Response<TripsResponse> response) {
                binding.swipeContainer.setRefreshing(false);
                if (response.isSuccessful()) {
                    TripsResponse tripsResponse = response.body();
                    Boolean error = tripsResponse.getError();
                    if (!error) {
                        if (tripsResponse.getData() != null && !tripsResponse.getData().getData().isEmpty()) {
                            updateAdapter(tripsResponse.getData().getData());
                            binding.txtNoDataFound.setVisibility(View.GONE);
                            binding.recycleView.setVisibility(View.VISIBLE);
                        } else {
                            binding.txtNoDataFound.setVisibility(View.VISIBLE);
                            binding.recycleView.setVisibility(View.GONE);
                        }
                    }
                } else {
                    Log.e("AddDriver", "TodaysTrip failed");
                    Toast.makeText(requireActivity(), "TodaysTrip failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TripsResponse> call, Throwable t) {
                binding.swipeContainer.setRefreshing(false);
                Log.e("Login", "TodaysTrip error: " + t.getMessage());
                Toast.makeText(requireActivity(), "TodaysTrip error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    void updateAdapter(List<Trips> data) {
        if (!data.isEmpty()) {
            tripAdapter.updateList(data);
            binding.txtNoDataFound.setVisibility(View.INVISIBLE);
        }
    }

}