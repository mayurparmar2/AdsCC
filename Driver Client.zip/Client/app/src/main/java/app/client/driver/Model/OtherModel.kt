package app.client.driver.Model

import com.google.gson.annotations.SerializedName

data class OtherModel(
    val id: String,
    val trip_id: String,
    val amount: Int,
    val created_at: String,
    val updated_at: String,
    var isUpload: Boolean
) {
    constructor() : this("", "", 0, "", "", true)
}




























































