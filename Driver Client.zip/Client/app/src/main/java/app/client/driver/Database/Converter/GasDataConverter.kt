package app.client.driver.Database.Converter

import androidx.room.TypeConverter
import app.client.driver.Model.GasDatum
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class GasDataConverter {
    @TypeConverter
    fun fromString(value: String): List<GasDatum> {
        val listType = object : TypeToken<List<GasDatum>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromList(list: List<GasDatum>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}