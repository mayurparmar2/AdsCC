package app.client.driver.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import app.client.driver.Model.OtherModel;
import app.client.driver.Utils.Utils;
import app.client.driver.databinding.ItemTextBinding;
import app.client.driver.databinding.ItemTextBinding;


public class AddMoneyAdapter extends RecyclerView.Adapter<AddMoneyAdapter.ViewHolder> {
    private final String TAG = AddMoneyAdapter.class.getSimpleName();
    private Context context;
    private List<OtherModel> list;
    private OnItemClickListener onItemClickListener;

    public void updateList(List<OtherModel> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();

    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public AddMoneyAdapter(Context context, List<OtherModel> list, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemTextBinding binding = ItemTextBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        holder.binding.textAmount.setText(list.get(position).getAmount() + "");
        holder.binding.textDateAndTime.setText(Utils.convertDateTimeFormat(list.get(position).getCreated_at()));
        holder.itemView.setOnClickListener(v -> {
            onItemClickListener.onItemClick(position);
        });
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemTextBinding binding;

        public ViewHolder(ItemTextBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}