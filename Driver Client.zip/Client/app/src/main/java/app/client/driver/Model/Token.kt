package app.client.driver.Model

import com.google.gson.annotations.SerializedName

data class Token(
    @JvmField
    @SerializedName("message")
    val message: String? = null,

    @JvmField
    @SerializedName("success")
    val success: Boolean? = null,

    @SerializedName("data")
    val data: Any? = null,

    @SerializedName("status")
    val status: Int? = null
)
