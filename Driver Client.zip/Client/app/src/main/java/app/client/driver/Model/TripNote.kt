package app.client.driver.Model

data class TripNote(
    val id: String,
    val trip_id: String,
    val notes: String,
    val created_at: String,
    val updated_at: String,
    var isUpload: Boolean
) {
    constructor() : this("", "", "", "", "", true)
}