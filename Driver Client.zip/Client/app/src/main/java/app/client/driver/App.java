package app.client.driver;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import com.google.firebase.FirebaseApp;

import app.client.driver.Utils.DriverPreference;

public class App extends Application {
    private final String TAG = "App";
    public static App app;

    public static App getApp() {
        return app;
    }

    public DriverPreference preference;

    @Override
    public void onCreate() {
        super.onCreate();
        app = this;
        preference = new DriverPreference(this);
        FirebaseApp.initializeApp(this);

    }

    public DriverPreference getPreference() {
        preference = new DriverPreference(app);
        return preference;
    }


    @SuppressLint("ResourceType")
    public static void showExitDialog(final Activity activity) {
        final Dialog customDialog = new Dialog(activity);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (customDialog.getWindow() != null) {
            customDialog.getWindow().setGravity(17);
            customDialog.getWindow().setBackgroundDrawableResource(17170445);
        }
        customDialog.setContentView(R.layout.dialog_exit);
        customDialog.setCanceledOnTouchOutside(false);
        customDialog.setCancelable(false);
        customDialog.findViewById(R.id.btnNo).setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                customDialog.dismiss();
            }
        });
        customDialog.findViewById(R.id.btnExit).setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                customDialog.dismiss();
                activity.finishAffinity();
            }
        });
        customDialog.show();
    }
}
