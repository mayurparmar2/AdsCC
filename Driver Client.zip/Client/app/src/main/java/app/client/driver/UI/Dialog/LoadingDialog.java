package app.client.driver.UI.Dialog;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RadioGroup;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import app.client.driver.R;
import app.client.driver.Utils.Validator;
import app.client.driver.databinding.GasDialogBinding;
import app.client.driver.databinding.LoadingDialogBinding;

public class LoadingDialog extends Dialog {
    private final String txtTitle;

    private Activity activity;
    public LoadingDialogBinding binding;

    public LoadingDialog(@NonNull Activity activity, String txtTitle) {
        super(new ContextThemeWrapper(activity, R.style.CustomDialogTheme));
        this.activity = activity;
        this.txtTitle = txtTitle;
    }

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(false);
        if (getWindow() != null) {
            getWindow().setGravity(17);
            getWindow().setBackgroundDrawableResource(17170445);
        }
        binding = LoadingDialogBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.txtTitle.setText(txtTitle);
    }

}
