package app.client.driver.Model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class TripsDetails(
    @SerializedName("id")
    @Expose
    var id: String? = null,

    @SerializedName("driver_id")
    @Expose
    var driverId: String? = null,

    @SerializedName("vendor_name")
    @Expose
    var vendorName: String? = null,

    @SerializedName("customer_name")
    @Expose
    var customerName: String? = null,

    @SerializedName("customer_mobile")
    @Expose
    var customerMobile: String? = null,

    @SerializedName("pickup_location")
    @Expose
    var pickupLocation: String? = null,

    @SerializedName("drop_location")
    @Expose
    var dropLocation: String? = null,

    @SerializedName("date_time")
    @Expose
    var dateTime: String? = null,

    @SerializedName("vehicle_name")
    @Expose
    var vehicleName: String? = null,

    @SerializedName("total_collection")
    @Expose
    var totalCollection: String? = null,

    @SerializedName("advance_paid")
    @Expose
    var advancePaid: String? = null,

    @SerializedName("commission")
    @Expose
    var commission: String? = null,

    @SerializedName("status")
    @Expose
    var status: String? = null,

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null,

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null,

    @SerializedName("driver_name")
    @Expose
    var driverName: String? = null,

    @SerializedName("driver_phone")
    @Expose
    var driverPhone: String? = null,

    @SerializedName("totalGasAmount")
    @Expose
    var totalGasAmount: Int? = null,

    @SerializedName("totalPuncherAmount")
    @Expose
    var totalPuncherAmount: Int? = null,

    @SerializedName("totalParkingAmount")
    @Expose
    var totalParkingAmount: Int? = null,

    @SerializedName("totalPoliceChargeAmount")
    @Expose
    var totalPoliceChargeAmount: Int? = null,

    @SerializedName("totalTallTaxAmount")
    @Expose
    var totalTallTaxAmount: Int? = null,

    @SerializedName("totalOtherAmount")
    @Expose
    var totalOtherAmount: Int? = null,

    @SerializedName("gasData")
    @Expose
    var gasData: List<GasDatum>? = null,

    @SerializedName("puncherData")
    @Expose
    var puncherData: List<GasDatum>? = null,

    @SerializedName("parkingData")
    @Expose
    var parkingData: List<OtherModel>? = null,

    @SerializedName("policeChargeData")
    @Expose
    var policeChargeData: List<Police>? = null,

    @SerializedName("tallTaxData")
    @Expose
    var tallTaxData: List<Toll>? = null,

    @SerializedName("otherData")
    @Expose
    var otherData: List<OtherModel>? = null,

    @SerializedName("receivedCollection")
    @Expose
    var receivedCollection: List<ReceivedCollection>? = null,

    @SerializedName("tripNotes")
    @Expose
    var noteList: List<TripNote>? = null
)
