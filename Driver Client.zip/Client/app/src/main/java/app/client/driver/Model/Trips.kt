package app.client.driver.Model

import androidx.annotation.NonNull
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


@Entity(tableName = "Trips")
data class Trips(
    @PrimaryKey
    @SerializedName("id")
    @Expose
    @NonNull
    var id: String,

    @SerializedName("driver_id")
    @Expose
    var driverId: String,

    @SerializedName("vendor_name")
    @Expose
    var vendorName: String,

    @SerializedName("customer_name")
    @Expose
    var customerName: String,

    @SerializedName("customer_mobile")
    @Expose
    var customerMobile: String,

    @SerializedName("pickup_location")
    @Expose
    var pickupLocation: String,

    @SerializedName("drop_location")
    @Expose
    var dropLocation: String,

    @SerializedName("date_time")
    @Expose
    var dateTime: String,

    @SerializedName("vehicle_name")
    @Expose
    var vehicleName: String,

    @SerializedName("total_collection")
    @Expose
    var totalCollection: String,

    @SerializedName("advance_paid")
    @Expose
    var advancePaid: String,

    @SerializedName("commission")
    @Expose
    var commission: String,

    @SerializedName("status")
    @Expose
    var status: String,

    @SerializedName("created_at")
    @Expose
    var createdAt: String,

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String
) {
    constructor(
        driverId: String,
        vendorName: String,
        customerName: String,
        customerMobile: String,
        pickupLocation: String,
        dropLocation: String,
        dateTime: String,
        vehicleName: String,
        totalCollection: String,
        advancePaid: String,
        commission: String,
        status: String,
        createdAt: String,
        updatedAt: String
    ) : this(
        id = "",

        driverId = driverId,
        vendorName = vendorName,
        customerName = customerName,
        customerMobile = customerMobile,
        pickupLocation = pickupLocation,
        dropLocation = dropLocation,
        dateTime = dateTime,
        vehicleName = vehicleName,
        totalCollection = totalCollection,
        advancePaid = advancePaid,
        commission = commission,
        status = status,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}













































































