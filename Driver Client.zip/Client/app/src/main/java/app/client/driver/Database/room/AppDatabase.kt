package app.client.driver.Database.room

import android.content.Context
import androidx.databinding.adapters.Converters
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import app.client.driver.Database.Converter.GasDataConverter
import app.client.driver.Database.Converter.ListConverters
import app.client.driver.Database.Converter.OtherDataConverter
import app.client.driver.Database.Converter.ParkingDataConverter
import app.client.driver.Database.Converter.PoliceChargeDataConverter
import app.client.driver.Database.Converter.PuncherDataConverter
import app.client.driver.Database.Converter.ReceivedCollectionConverter
import app.client.driver.Database.Converter.TollConverter
import app.client.driver.Database.Converter.TripNoteConverter
import app.client.driver.Model.TripEntity
import app.client.driver.Model.Trips

@Database(entities = [Trips::class, TripEntity::class], version = 1, exportSchema = false)
@TypeConverters(
    GasDataConverter::class,
    PuncherDataConverter::class,
    ParkingDataConverter::class,
    PoliceChargeDataConverter::class,
    OtherDataConverter::class,
    ReceivedCollectionConverter::class,
    TripNoteConverter::class,
    TollConverter::class,
    ListConverters::class
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tripDao(): TripDao
    abstract fun tripDetailDao(): TripDetailDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "trip_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

