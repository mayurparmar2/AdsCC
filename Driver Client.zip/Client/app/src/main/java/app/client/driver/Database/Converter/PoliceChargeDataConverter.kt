package app.client.driver.Database.Converter

import androidx.room.TypeConverter
import app.client.driver.Model.Police
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PoliceChargeDataConverter {
    @TypeConverter
    fun fromString(value: String): List<Police> {
        val listType = object : TypeToken<List<Police>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromList(list: List<Police>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}