package app.client.driver.Utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import app.client.driver.R;

public class ImageUtil {

    @SuppressLint("MissingPermission")
    @RequiresApi(api = Build.VERSION_CODES.P)
    public static File addTimestampAndLocationToImage(Context context, String inputFilePath, String outputFileName, String location) {


        Bitmap originalBitmap = BitmapFactory.decodeFile(inputFilePath);

        if (originalBitmap == null) {
            throw new IllegalArgumentException("Invalid image file path");
        }


        Bitmap mutableBitmap = originalBitmap.copy(Bitmap.Config.ARGB_8888, true);


        final float scale = context.getResources().getDisplayMetrics().density;
        int margin = (int) (40 * scale + 0.5f);


        Canvas canvas = new Canvas(mutableBitmap);
        Paint paint = new Paint();
        paint.setColor(context.getResources().getColor(R.color.colorPrimary));
        paint.setTextSize(50);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setAntiAlias(true);

        Date currentDate = new Date();


        SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm a", Locale.getDefault());
        String formattedTime = timeFormat.format(currentDate);


        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM-yyyy", Locale.getDefault());
        String formattedDate = dateFormat.format(currentDate);


        float textHeight = paint.getFontMetrics().bottom - paint.getFontMetrics().top;
        drawTextWithBackground(canvas, paint, formattedDate, margin, (mutableBitmap.getHeight() - textHeight) / 2);


        float textWidth = paint.measureText(formattedTime);
        drawTextWithBackground(canvas, paint, formattedTime, mutableBitmap.getWidth() - textWidth - margin, (mutableBitmap.getHeight() - textHeight) / 2);


        drawMultilineTextWithBackground(canvas, paint, location, margin, mutableBitmap.getHeight() - margin, mutableBitmap.getWidth() - 2 * margin);


        File outputFile = new File(context.getExternalFilesDir(null), outputFileName + ".jpg");
        try (FileOutputStream out = new FileOutputStream(outputFile)) {
            mutableBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return outputFile;
    }

    private static void drawMultilineTextWithBackground(Canvas canvas, Paint paint, String text, float x, float y, float maxWidth) {
        Paint backgroundPaint = new Paint();
        backgroundPaint.setColor(Color.WHITE);

        TextPaint textPaint = new TextPaint(paint);
        StaticLayout staticLayout = StaticLayout.Builder.obtain(text, 0, text.length(), textPaint, (int) maxWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(1.0f, 1.0f)
                .setIncludePad(false)
                .build();

        float textHeight = staticLayout.getHeight();


        canvas.drawRect(x - 10, y - textHeight - 10, x + maxWidth + 10, y + 10, backgroundPaint);

        canvas.save();
        canvas.translate(x, y - textHeight);
        staticLayout.draw(canvas);
        canvas.restore();
    }

    private static void drawTextWithBackground(Canvas canvas, Paint paint, String text, float x, float y) {
        Paint backgroundPaint = new Paint();
        backgroundPaint.setColor(Color.WHITE);

        float textWidth = paint.measureText(text);
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        float textHeight = fontMetrics.bottom - fontMetrics.top;


        canvas.drawRect(x - 10, y + fontMetrics.top - 10, x + textWidth + 10, y + fontMetrics.bottom + 10, backgroundPaint);


        canvas.drawText(text, x, y, paint);
    }


}
