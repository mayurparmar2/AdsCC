package app.client.driver.network

import app.client.driver.Model.Token
import app.client.driver.network.Respose.AddResponse
import app.client.driver.network.Respose.LoginResponse
import app.client.driver.network.Respose.TripsDetailsResponse
import app.client.driver.network.Respose.TripsResponse
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Query

interface ApiService {
    @FormUrlEncoded
    @POST("Driver/Login")
    fun login(
        @Field("phone") phone: String?,
        @Field("password") password: String?
    ): Call<LoginResponse?>?


    @GET("Driver/Trip/TodayTripList")
    fun getTodayTripList(@Query("id") id: Int): Call<TripsResponse?>?

    @GET("Driver/Trip/PastTripList")
    fun getPastTripList(@Query("id") id: Int): Call<TripsResponse?>?

    @GET("Driver/Trip/getTripDetails")
    fun showTripDetailsTrip(@Query("id") trip_id: Int): Call<TripsDetailsResponse>


    @Multipart
    @POST("Driver/Trip/addGas")
    fun addGas(
        @Part("amount") amount: Int,
        @Part("trip_id") tripId: Int,
        @Part("payment_type") paymentType: Int,
        @Part image: Array<okhttp3.MultipartBody.Part>,
        @Part("created_at") dateTime: String
    ): Call<AddResponse>

    @Multipart
    @POST("Driver/Trip/AddPuncher")
    fun addPuncher(
        @Part("amount") amount: Int,
        @Part("trip_id") tripId: Int,
        @Part("payment_type") paymentType: Int,
        @Part image: Array<okhttp3.MultipartBody.Part>,
        @Field("created_at") dateTime: String
    ): Call<AddResponse>


    @FormUrlEncoded
    @POST("Driver/Trip/AddPoliceCharge")
    fun addPolice(
        @Field("amount") amount: String?,
        @Field("trip_id") trip_id: String?,
        @Field("location") location: String?,
        @Field("created_at") dateTime: String?
    ): Call<AddResponse>

    @FormUrlEncoded
    @POST("Driver/Trip/AddPoliceCharge")
    fun addPolice2(
        @Field("amount") amount: String?,
        @Field("trip_id") trip_id: String?,
        @Field("location") location: String?,
        @Field("created_at") dateTime: String?
    ): Call<AddResponse>


    @FormUrlEncoded
    @POST("Driver/Trip/AddOtherData")
    fun addOthers(
        @Field("amount") amount: String?,
        @Field("trip_id") trip_id: String?,
        @Field("created_at") dateTime: String?
    ): Call<AddResponse>

    @FormUrlEncoded
    @POST("Driver/Trip/addTripNotes")
    fun addNote(
        @Field("trip_id") id: Int,
        @Field("notes") note: String?,
        @Field("created_at") dateTime: String?
    ): Call<AddResponse>

    @FormUrlEncoded
    @POST("Driver/Trip/AddTollTax")
    fun addToll(
        @Field("amount") amount: String?,
        @Field("trip_id") trip_id: String?,
        @Field("created_at") dateTime: String?
    ): Call<AddResponse>

    @FormUrlEncoded
    @POST("Driver/Trip/AddParking")
    fun addParking(
        @Field("amount") amount: String?,
        @Field("trip_id") trip_id: String?,
        @Field("created_at") dateTime: String?
    ): Call<AddResponse>

    @GET("Driver/Trip/MarkTripComplete")
    fun MarkTripComplete(@Query("id") id: Int): Call<AddResponse>

    @FormUrlEncoded
    @POST("Driver/Trip/AddReceivedCollection")
    fun addCollection(
        @Field("advance_paid") amount: String?,
        @Field("id") trip_id: String?,
        @Field("payment_type") paymentType: String?,
        @Field("created_at") dateTime: String?
    ): Call<AddResponse>

    @FormUrlEncoded
    @POST("Driver/Trip/updateDeviceToken")
    fun updateDeviceToken(
        @Field("device_token") amount: String?
    ): Call<Token?>?
}
