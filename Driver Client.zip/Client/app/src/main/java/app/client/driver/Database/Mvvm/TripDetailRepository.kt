package app.client.driver.Database.Mvvm

import android.app.Application
import android.util.Log
import androidx.lifecycle.LiveData
import app.client.driver.Database.room.AppDatabase
import app.client.driver.Database.room.TripDetailDao
import app.client.driver.Model.GasDatum
import app.client.driver.Model.OtherModel
import app.client.driver.Model.Parking
import app.client.driver.Model.Police
import app.client.driver.Model.PuncherDatum
import app.client.driver.Model.ReceivedCollection
import app.client.driver.Model.Toll
import app.client.driver.Model.TripEntity
import app.client.driver.Model.TripNote
import app.client.driver.Model.Trips
import app.client.driver.network.ApiService
import app.client.driver.network.Respose.AddResponse
import app.client.driver.network.Respose.TripsDetailsResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import java.io.File
import retrofit2.Response

class TripDetailRepository(application: Application) {
    private val tripDetailDao: TripDetailDao
    val allTripsDetail: LiveData<List<TripEntity>>

    init {
        val db = AppDatabase.getDatabase(application)
        tripDetailDao = db.tripDetailDao()
        allTripsDetail = tripDetailDao.getAllTrips()
    }

    suspend fun getTripsDetails(driver_id: String): TripEntity {
        return tripDetailDao.getTripDetailById(driver_id)
    }

    fun insertAll(trips: List<TripEntity>) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDetailDao.insertAll(trips)
        }
    }

    suspend fun fetchTripDetailFromApi(ids: List<Trips>, apiService: ApiService) {
        if (!ids.isEmpty()) {
            withContext(Dispatchers.IO) {
                try {
                    coroutineScope {
                        ids.map { tripsModel ->
                            async {
                                callTripDetailFromApifetch(tripsModel.id.toInt(), apiService)
                            }
                        }.awaitAll()
                    }


                } catch (e: Exception) {
                    Log.e("TAG", "fetchTripsFromApi : " + e.message)


                }
            }
        }
    }


    suspend fun updatePuncherData(tripId: String, puncherData: List<PuncherDatum>) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDetailDao.updatePuncherData(tripId, puncherData)
        }
    }

    suspend fun updateGasData(tripId: String, puncherData: List<GasDatum>) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDetailDao.updateGasData(tripId, puncherData)
        }
    }

    suspend fun updatePoliceData(tripId: String, puncherData: List<Police>) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDetailDao.updatePoliceData(tripId, puncherData)
        }
    }

    suspend fun updateTripNoteData(tripId: String, puncherData: List<TripNote>) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDetailDao.updateTripNoteData(tripId, puncherData)
        }
    }

    suspend fun updateParkingData(tripId: String, puncherData: List<Parking>) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDetailDao.updateParkingData(tripId, puncherData)
        }
    }

    suspend fun updateTollData(tripId: String, puncherData: List<Toll>) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDetailDao.updateTollData(tripId, puncherData)
        }
    }

    suspend fun updateOtherData(tripId: String, puncherData: List<OtherModel>) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDetailDao.updateOtherData(tripId, puncherData)
        }
    }

    suspend fun updateReceivedCollectionData(
        tripId: String,
        puncherData: List<ReceivedCollection>
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDetailDao.updateReceivedCollectionData(tripId, puncherData)
        }
    }


    suspend fun callApiOnlineRun(tripEntity: TripEntity, apiService: ApiService): Boolean {
        var isComp: Boolean = true
        withContext(Dispatchers.Default) {
            try {


                CoroutineScope(Dispatchers.Default).async {
                    uploadGasData(tripEntity.gasData.toMutableList(), apiService)
                    uploadPuncherData(tripEntity.puncherData.toMutableList(), apiService)
                    uploadPoliceData(tripEntity.policeChargeData.toMutableList(), apiService)
                    uploadNoteData(tripEntity.tripNotes.toMutableList(), apiService)
                    uploadTallTaxData(tripEntity.tallTaxData.toMutableList(), apiService)
                    uploadParkingData(tripEntity.parkingData.toMutableList(), apiService)
                    uploadOtherData(tripEntity.otherData.toMutableList(), apiService)
                    uploadReceivedCollData(
                        tripEntity.receivedCollection.toMutableList(),
                        apiService
                    )
                }.await()





                isComp = true
            } catch (e: Exception) {
                Log.e("TAG", "callApiOnlineRun -----> : " + e.message)
                isComp = false
            }
        }
        return isComp
    }

    suspend fun uploadNoteData(
        notelist: MutableList<TripNote>,
        apiService: ApiService
    ) {
        val successfullyInserted = mutableListOf<TripNote>()
        var tripsId = 0
        notelist.forEachIndexed { index, note ->
            tripsId = note.trip_id.toInt()
            if (!note.isUpload) {
                try {
                    apiService.addNote(
                        note.trip_id.toInt(),
                        note.notes,
                        note.created_at
                    ).enqueue(object : retrofit2.Callback<AddResponse> {
                        override fun onResponse(
                            call: Call<AddResponse>,
                            response: Response<AddResponse>
                        ) {
                            if (response.isSuccessful) {
                                val addResponse = response.body()
                                if (addResponse?.error == false) {
                                    note.isUpload = true
                                    successfullyInserted.add(note)
                                    Log.e(
                                        "uploadPoliceData",
                                        "successfullyInsertedPolice msg: " + addResponse.msg
                                    )
                                } else {
                                    Log.e(
                                        "uploadPoliceData",
                                        "failedPolice 1 msg: " + addResponse?.msg
                                    )
                                }
                            } else {
                                Log.e("uploadPoliceData", "failedPolice 2 msg: ")

                            }
                        }

                        override fun onFailure(call: Call<AddResponse>, t: Throwable) {
                            Log.e("uploadPoliceData", "failedPolice 2 msg: " + t.message)
                        }
                    })
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("uploadPoliceData", "failedPolice 2 msg: " + e.message)
                }
            }
        }
        tripDetailDao.updateTripNoteData(tripsId.toString(), successfullyInserted)
    }

    private suspend fun uploadReceivedCollData(
        receivedCollList: MutableList<ReceivedCollection>,
        apiService: ApiService
    ) {

        val successfullyInserted = mutableListOf<ReceivedCollection>()
        var tripsId = 0
        receivedCollList.forEachIndexed { index, collection ->
            tripsId = collection.trip_id.toInt()
            if (!collection.isUpload) {
                try {
                    apiService.addCollection(
                        collection.amount.toString(),
                        collection.trip_id,
                        collection.payment_type,
                        collection.created_at
                    ).enqueue(object : retrofit2.Callback<AddResponse> {
                        override fun onResponse(
                            call: Call<AddResponse>,
                            response: Response<AddResponse>
                        ) {
                            if (response.isSuccessful) {
                                val addResponse = response.body()
                                if (addResponse?.error == false) {
                                    collection.isUpload = true
                                    successfullyInserted.add(collection)
                                    Log.e(
                                        "uploadReceivedCollData",
                                        "successfullyInserted msg: " + addResponse.msg
                                    )
                                } else {
                                    Log.e(
                                        "uploadReceivedCollData",
                                        "failed 1 msg: " + addResponse?.msg
                                    )
                                }
                            } else {
                                Log.e("uploadReceivedCollData", "failed 2 msg: ")

                            }
                        }

                        override fun onFailure(call: Call<AddResponse>, t: Throwable) {
                            Log.e("uploadReceivedCollData", "failed 2 msg: " + t.message)
                        }
                    })
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("uploadReceivedCollData", "failedPolice 2 msg: " + e.message)
                }
            }
        }
        tripDetailDao.updateReceivedCollectionData(tripsId.toString(), successfullyInserted)
    }

    private suspend fun uploadOtherData(
        otherList: MutableList<OtherModel>,
        apiService: ApiService
    ) {
        val successfullyInserted = mutableListOf<OtherModel>()
        var tripsId = 0
        otherList.forEachIndexed { index, otherModel ->
            tripsId = otherModel.trip_id.toInt()
            if (!otherModel.isUpload) {
                try {
                    apiService.addOthers(
                        otherModel.amount.toString(),
                        otherModel.trip_id,
                        otherModel.created_at
                    ).enqueue(object : retrofit2.Callback<AddResponse> {
                        override fun onResponse(
                            call: Call<AddResponse>,
                            response: Response<AddResponse>
                        ) {
                            if (response.isSuccessful) {
                                val addResponse = response.body()
                                if (addResponse?.error == false) {
                                    otherModel.isUpload = true
                                    successfullyInserted.add(otherModel)
                                    Log.e(
                                        "uploadOtherData",
                                        "successfullyInserted msg: " + addResponse.msg
                                    )
                                } else {
                                    Log.e(
                                        "uploadOtherData",
                                        "failed 1 msg: " + addResponse?.msg
                                    )
                                }
                            } else {
                                Log.e("uploadOtherData", "failed 2 msg: ")

                            }
                        }

                        override fun onFailure(call: Call<AddResponse>, t: Throwable) {
                            Log.e("uploadOtherData", "failed 2 msg: " + t.message)
                        }
                    })
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("uploadOtherData", "failedPolice 2 msg: " + e.message)
                }
            }
        }
        tripDetailDao.updateOtherData(tripsId.toString(), successfullyInserted)
    }

    private suspend fun uploadParkingData(
        parkingList: MutableList<Parking>,
        apiService: ApiService
    ) {
        val successfullyInserted = mutableListOf<Parking>()
        var tripsId = 0
        parkingList.forEachIndexed { index, parking ->
            tripsId = parking.trip_id.toInt()
            if (!parking.isUpload) {
                try {
                    apiService.addParking(
                        parking.amount.toString(),
                        parking.trip_id,
                        parking.created_at
                    ).enqueue(object : retrofit2.Callback<AddResponse> {
                        override fun onResponse(
                            call: Call<AddResponse>,
                            response: Response<AddResponse>
                        ) {
                            if (response.isSuccessful) {
                                val addResponse = response.body()
                                if (addResponse?.error == false) {
                                    parking.isUpload = true
                                    successfullyInserted.add(parking)
                                    Log.e(
                                        "uploadParkingData",
                                        "successfullyInserted msg: " + addResponse.msg
                                    )
                                } else {
                                    Log.e(
                                        "uploadParkingData",
                                        "failed 1 msg: " + addResponse?.msg
                                    )
                                }
                            } else {
                                Log.e("uploadParkingData", "failed 2 msg: ")

                            }
                        }

                        override fun onFailure(call: Call<AddResponse>, t: Throwable) {
                            Log.e("uploadParkingData", "failed 2 msg: " + t.message)
                        }
                    })
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("uploadParkingData", "failedPolice 2 msg: " + e.message)
                }
            }
        }
        tripDetailDao.updateParkingData(tripsId.toString(), successfullyInserted)
    }

    private suspend fun uploadTallTaxData(
        tallTaxList: MutableList<Toll>,
        apiService: ApiService
    ) {
        val successfullyInserted = mutableListOf<Toll>()
        var tripsId = 0
        tallTaxList.forEachIndexed { index, toll ->
            tripsId = toll.trip_id.toInt()
            if (!toll.isUpload) {
                try {
                    apiService.addToll(
                        toll.amount.toString(),
                        toll.trip_id,
                        toll.created_at
                    ).enqueue(object : retrofit2.Callback<AddResponse> {
                        override fun onResponse(
                            call: Call<AddResponse>,
                            response: Response<AddResponse>
                        ) {
                            if (response.isSuccessful) {
                                val addResponse = response.body()
                                if (addResponse?.error == false) {
                                    toll.isUpload = true
                                    successfullyInserted.add(toll)
                                    Log.e(
                                        "uploadPoliceData",
                                        "successfullyInsertedPolice msg: " + addResponse.msg
                                    )
                                } else {
                                    Log.e(
                                        "uploadPoliceData",
                                        "failedPolice 1 msg: " + addResponse?.msg
                                    )
                                }
                            } else {
                                Log.e("uploadPoliceData", "failedPolice 2 msg: ")

                            }
                        }

                        override fun onFailure(call: Call<AddResponse>, t: Throwable) {
                            Log.e("uploadPoliceData", "failedPolice 2 msg: " + t.message)
                        }
                    })
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("uploadPoliceData", "failedPolice 2 msg: " + e.message)
                }
            }
        }
        tripDetailDao.updateTollData(tripsId.toString(), successfullyInserted)
    }


    private suspend fun uploadPuncherData(
        puncherData: MutableList<PuncherDatum>,
        apiService: ApiService
    ) {
        val successfullyInserted = mutableListOf<PuncherDatum>()
        var tripsId = 0
        puncherData.forEachIndexed { index, collection ->
            tripsId = collection.trip_id.toInt()
            if (!collection.isUpload) {
                try {
                    val fileList = collection.image.map { File(it) }
                    val parts: Array<MultipartBody.Part> = prepareFilePart("image[]", fileList)

                    apiService.addPuncher(
                        collection.amount,
                        collection.trip_id.toInt(),
                        collection.payment_type.toInt(),
                        parts,
                        collection.created_at
                    ).enqueue(object : retrofit2.Callback<AddResponse> {
                        override fun onResponse(
                            call: Call<AddResponse>,
                            response: Response<AddResponse>
                        ) {
                            if (response.isSuccessful) {
                                val addResponse = response.body()
                                if (addResponse?.error == false) {
                                    collection.isUpload = true
                                    successfullyInserted.add(collection)
                                    Log.e(
                                        "uploadPuncherData",
                                        "successfullyInserted msg: " + addResponse.msg
                                    )
                                } else {
                                    Log.e(
                                        "uploadPuncherData",
                                        "failed 1 msg: " + addResponse?.msg
                                    )
                                }
                            } else {
                                Log.e("uploadPuncherData", "failed 2 msg: ")

                            }
                        }

                        override fun onFailure(call: Call<AddResponse>, t: Throwable) {
                            Log.e("uploadPuncherData", "failed 2 msg: " + t.message)
                        }
                    })
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("uploadPuncherData", "failedPolice 2 msg: " + e.message)
                }
            }
        }
        tripDetailDao.updatePuncherData(tripsId.toString(), successfullyInserted)


    }

    suspend fun uploadGasData(gasDataList: MutableList<GasDatum>, apiService: ApiService) {
        val successfullyInserted = mutableListOf<GasDatum>()
        var tripsId = 0
        gasDataList.forEachIndexed { index, gasDatum ->
            if (!gasDatum.isUpload) {
                tripsId = gasDatum.trip_id.toInt()
                try {
                    val fileList = gasDatum.image.map { File(it) }
                    val parts: Array<MultipartBody.Part> = prepareFilePart("image[]", fileList)
                    apiService.addGas(
                        gasDatum.amount,
                        gasDatum.trip_id.toInt(),
                        gasDatum.payment_type.toInt(),
                        parts,
                        gasDatum.created_at
                    ).enqueue(object : retrofit2.Callback<AddResponse> {
                        override fun onResponse(
                            call: Call<AddResponse>,
                            response: Response<AddResponse>
                        ) {
                            if (response.isSuccessful) {
                                val addResponse = response.body()
                                if (addResponse?.error == false) {
                                    gasDatum.isUpload = true
                                    successfullyInserted.add(gasDatum)
                                    Log.e(
                                        "uploadGasData",
                                        "successfullyInserted msg: " + addResponse.msg
                                    )
                                } else {
                                    Log.e(
                                        "uploadGasData",
                                        "failed 1 msg: " + addResponse?.msg
                                    )
                                }
                            } else {
                                Log.e("uploadGasData", "failed 2 msg: ")

                            }
                        }

                        override fun onFailure(call: Call<AddResponse>, t: Throwable) {
                            Log.e("uploadGasData", "failed 2 msg: " + t.message)
                        }
                    })
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("uploadGasData", "failedPolice 2 msg: " + e.message)
                }
            }
        }
        tripDetailDao.updateGasData(tripsId.toString(), successfullyInserted)


    }


    suspend fun uploadPoliceData(
        policeList: MutableList<Police>,
        apiService: ApiService
    ) {
        val successfullyInsertedPolice = mutableListOf<Police>()
        var tripsId = 0
        policeList.forEachIndexed { index, police ->
            tripsId = police.trip_id.toInt()
            if (!police.isUpload) {
                try {
                    val response: Call<AddResponse> = apiService.addPolice2(
                        police.amount.toString(),
                        police.trip_id.toString(),
                        police.location,
                        police.created_at
                    )
                    response.enqueue(object : retrofit2.Callback<AddResponse> {
                        override fun onResponse(
                            call: Call<AddResponse>,
                            response: Response<AddResponse>
                        ) {
                            if (response.isSuccessful) {
                                val addResponse = response.body()
                                if (addResponse?.error == false) {
                                    police.isUpload = true
                                    successfullyInsertedPolice.add(police)
                                    Log.e(
                                        "uploadPoliceData",
                                        "successfullyInsertedPolice msg: " + addResponse?.msg
                                    )
                                } else {
                                    Log.e(
                                        "uploadPoliceData",
                                        "failedPolice 1 msg: " + addResponse?.msg
                                    )
                                }
                            } else {
                                Log.e("uploadPoliceData", "failedPolice 2 msg: ")

                            }
                        }

                        override fun onFailure(call: Call<AddResponse>, t: Throwable) {
                            Log.e("uploadPoliceData", "failedPolice 2 msg: " + t.message)
                        }
                    })
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("uploadPoliceData", "failedPolice 2 msg: " + e.message)
                }
            }
        }
        tripDetailDao.updatePoliceData(tripsId.toString(), successfullyInsertedPolice)
    }


    fun callTripDetailFromApifetch(id: Int, apiService: ApiService) {
        apiService.showTripDetailsTrip(id).enqueue(object : Callback<TripsDetailsResponse> {
            override fun onResponse(
                call: Call<TripsDetailsResponse>,
                response: Response<TripsDetailsResponse>
            ) {
                Log.e("TAG", "TripDetailRepository onResponse: $id")
                val trips = response.body()!!.data.data
                trips?.let {
                    insertAll(trips)

                }
            }

            override fun onFailure(call: Call<TripsDetailsResponse>, t: Throwable) {
                Log.e("TAG", "onFailure: " + t.message)
            }
        })
    }

    fun prepareFilePart(partName: String, files: List<File>): Array<MultipartBody.Part> {
        return files.map { file ->
            val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), file)
            MultipartBody.Part.createFormData(partName, file.name, requestFile)
        }.toTypedArray()
    }

    suspend fun getallTripsDetail(): List<TripEntity> {
        return withContext(Dispatchers.IO) {
            val tripDetail = tripDetailDao.getAllTripsDetail()
            tripDetail
        }
    }
}

