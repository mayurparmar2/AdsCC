package app.client.driver.Database.Mvvm

import android.app.Application
import androidx.lifecycle.LiveData
import app.client.driver.Database.room.AppDatabase
import app.client.driver.Database.room.TripDao
import app.client.driver.Model.TripEntity
import app.client.driver.Model.Trips
import app.client.driver.databinding.ActivityTodayTripBinding
import app.client.driver.network.ApiService
import app.client.driver.network.Respose.TripsResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TodaysTripRepository(application: Application) {
    private val tripDao: TripDao
    val allTrips: LiveData<List<Trips>>

    init {
        val db = AppDatabase.getDatabase(application)
        tripDao = db.tripDao()
        allTrips = tripDao.getAllTrips()
    }


    fun insertAll(trips: List<Trips>) {
        CoroutineScope(Dispatchers.IO).launch {
            tripDao.insertAll(trips)
        }
    }

    suspend fun deleteAllRows() {
        tripDao.deleteAll()
    }

    suspend fun getAllTodaysTrips(): List<Trips> {
        return withContext(Dispatchers.IO) {
            val tripDetail = tripDao.getAllTodaysTrips()
            tripDetail
        }
    }


}
