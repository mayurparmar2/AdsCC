package app.client.driver.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import app.client.driver.Model.OtherModel;
import app.client.driver.Model.Police;
import app.client.driver.Utils.Utils;
import app.client.driver.databinding.ItemPoliceBinding;
import app.client.driver.databinding.ItemTextBinding;


public class AddPoliceAdapter extends RecyclerView.Adapter<AddPoliceAdapter.ViewHolder> {
    private final String TAG = AddPoliceAdapter.class.getSimpleName();
    private Context context;
    private List<Police> list;
    private OnItemClickListener onItemClickListener;

    public void updateList(List<Police> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();

    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public AddPoliceAdapter(Context context, List<Police> list, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemPoliceBinding binding = ItemPoliceBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.binding.textAmount.setText(list.get(position).getAmount() + "");
        holder.binding.textDateAndTime.setText(Utils.convertDateTimeFormat(list.get(position).getCreated_at()));
        holder.binding.address.setText("Address : " + list.get(position).getLocation());
        holder.itemView.setOnClickListener(v -> {
            onItemClickListener.onItemClick(position);
        });
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemPoliceBinding binding;

        public ViewHolder(ItemPoliceBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}