package app.client.driver.UI;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.kaopiz.kprogresshud.KProgressHUD;

import java.util.ArrayList;
import java.util.List;

import app.client.driver.Database.Mvvm.TripViewModel;
import app.client.driver.Database.TripViewModelFactory;
import app.client.driver.Model.TripEntity;
import app.client.driver.UI.Dialog.LoadingDialog;
import app.client.driver.Utils.DriverPreference;
import app.client.driver.Utils.Utils;
import app.client.driver.network.ApiService;
import app.client.driver.network.Respose.AddResponse;
import app.client.driver.network.RetrofitClient2;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import retrofit2.Call;

public class BaseActivity extends AppCompatActivity {

    private static List<Activity> activities = new ArrayList<>();
    TripViewModel tripViewModel;
    LoadingDialog progressHUD;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activities.add(this);

        progressHUD = new LoadingDialog(this, "Loading...");


        tripViewModel = new ViewModelProvider(this, new TripViewModelFactory(getApplication())).get(TripViewModel.class);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        activities.remove(this);
    }

    public static void finishAllActivities() {
        for (Activity activity : activities) {
            activity.finish();
        }
        activities.clear();
    }


    @Override
    protected void onResume() {
        super.onResume();
        tripViewModel.getallTripsDetail(list -> {
            if (Utils.isInternetAvailable(BaseActivity.this)) {
                if (list != null && !list.isEmpty()) {
                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).getStatus().equals("pending")) {
                            callApiOnline(list.get(i));
                        }
                    }
                }
            }
            return null;
        });


    }

    private void callApiOnline(TripEntity tripEntity) {
        progressHUD.show();
        ApiService apiService = RetrofitClient2.getClient(new DriverPreference(this).getAuthToken()).create(ApiService.class);
        tripViewModel.callApiOnline(tripEntity, apiService, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean) {
                if (aBoolean) {
                    progressHUD.dismiss();
                } else {
                    progressHUD.dismiss();
                    Toast.makeText(BaseActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                return null;
            }
        });
    }
}