package app.client.driver.Database.Mvvm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import app.client.driver.Model.GasDatum
import app.client.driver.Model.OtherModel
import app.client.driver.Model.Parking
import app.client.driver.Model.Police
import app.client.driver.Model.PuncherDatum
import app.client.driver.Model.ReceivedCollection
import app.client.driver.Model.Toll
import app.client.driver.Model.TripEntity
import app.client.driver.Model.TripNote
import app.client.driver.Model.Trips
import app.client.driver.network.ApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class TripViewModel(application: Application) : AndroidViewModel(application) {
    val todaysTripRepository: TodaysTripRepository = TodaysTripRepository(application)
    val tripDetailRepository: TripDetailRepository = TripDetailRepository(application)
    val allTrips: LiveData<List<Trips>> = todaysTripRepository.allTrips
    val allTripsDetail: LiveData<List<TripEntity>> = tripDetailRepository.allTripsDetail


    fun insertAllTodayslist(Data: List<Trips>) {
        viewModelScope.launch {
            todaysTripRepository.insertAll(Data)
        }
    }


    fun fetchTripDetailFromApi(ids: List<Trips>, apiService: ApiService) {
        viewModelScope.launch {
            tripDetailRepository.fetchTripDetailFromApi(ids, apiService)
        }
    }

    fun deleteAllRows() = viewModelScope.launch {
        todaysTripRepository.deleteAllRows()
    }

    fun getAllTodaysTrips(callback: (List<Trips>) -> Unit) {
        viewModelScope.launch {
            val tripDetail = todaysTripRepository.getAllTodaysTrips()
            callback(tripDetail)
        }
    }


    fun getallTripsDetail(callback: (List<TripEntity>?) -> Unit) {
        viewModelScope.launch {
            val tripDetail = tripDetailRepository.getallTripsDetail()
            callback(tripDetail)
        }
    }

    fun getTripsDetails(id: String, callback: (TripEntity?) -> Unit) {
        viewModelScope.launch {
            val tripDetail = getTripDetailById(id)
            callback(tripDetail)
        }
    }

    suspend fun getTripDetailById(id: String): TripEntity? {
        return withContext(Dispatchers.IO) {
            val tripDetail = tripDetailRepository.getTripsDetails(id)
            tripDetail
        }
    }


    fun updatePuncherData(tripId: String, puncherData: List<PuncherDatum>) {
        viewModelScope.launch {
            tripDetailRepository.updatePuncherData(tripId, puncherData)
        }
    }

    fun updateGasData(tripId: String, puncherData: List<GasDatum>) {
        viewModelScope.launch {
            tripDetailRepository.updateGasData(tripId, puncherData)
        }
    }

    fun updatePoliceData(tripId: String, puncherData: List<Police>) {
        viewModelScope.launch {
            tripDetailRepository.updatePoliceData(tripId, puncherData)
        }
    }

    fun updateTripNoteData(tripId: String, puncherData: List<TripNote>) {
        viewModelScope.launch {
            tripDetailRepository.updateTripNoteData(tripId, puncherData)
        }
    }

    fun updateParkingData(tripId: String, puncherData: List<Parking>) {
        viewModelScope.launch {
            tripDetailRepository.updateParkingData(tripId, puncherData)
        }
    }

    fun updateTollData(tripId: String, puncherData: List<Toll>) {
        viewModelScope.launch {
            tripDetailRepository.updateTollData(tripId, puncherData)
        }
    }

    fun updateOtherData(tripId: String, puncherData: List<OtherModel>) {
        viewModelScope.launch {
            tripDetailRepository.updateOtherData(tripId, puncherData)
        }
    }

    fun updateReceivedCollectionData(tripId: String, puncherData: List<ReceivedCollection>) {
        viewModelScope.launch {
            tripDetailRepository.updateReceivedCollectionData(tripId, puncherData)
        }
    }

    fun callApiOnline(tripEntity: TripEntity, apiService: ApiService, callback: (Boolean) -> Unit) {
        viewModelScope.launch {
            val task: Boolean = tripDetailRepository.callApiOnlineRun(tripEntity, apiService)
            callback(task)
        }
    }


}
