package app.client.driver.network.Respose;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import app.client.driver.Model.TripEntity;
import app.client.driver.Model.TripsDetails;

public class DataDetails {
    @SerializedName("data")
    @Expose
    private List<TripEntity> data;

    public List<TripEntity> getData() {
        return data;
    }

    public void setData(List<TripEntity> data) {
        this.data = data;
    }
}