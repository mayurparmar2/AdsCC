package app.client.driver.Adpater;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import app.client.driver.Model.GasDatum;
import app.client.driver.Utils.Utils;
import app.client.driver.databinding.ItemTextBinding;
import app.client.driver.databinding.ItemTextWithImageBinding;


public class GasAdapter extends RecyclerView.Adapter<GasAdapter.ViewHolder> {
    private final String TAG = GasAdapter.class.getSimpleName();
    private Context context;
    private List<GasDatum> list;
    private OnItemClickListener onItemClickListener;
    private OnImageClickListener onImageClickListener;

    public void updateList(List<GasDatum> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();

    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public interface OnImageClickListener {
        void onItemClick(String url);
    }

    public GasAdapter(Context context, List<GasDatum> list, OnItemClickListener onItemClickListener, OnImageClickListener onImageClickListener) {
        this.context = context;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
        this.onImageClickListener = onImageClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemTextWithImageBinding binding = ItemTextWithImageBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        GasDatum item = list.get(position);
        holder.binding.amount.setText(item.getAmount() + "");
        if (item.getPayment_type().equals("1")) {
            holder.binding.paymentType.setText("Online:");
        } else {
            holder.binding.paymentType.setText("Cash:");
        }
        try {
            holder.binding.time.setText(Utils.convertDateTimeFormat(item.getCreated_at()));
        } catch (Exception e) {
            e.printStackTrace();
        }

        holder.itemView.setOnClickListener(v -> {
            onItemClickListener.onItemClick(position);
        });

        for (int i = 0; i < item.getImage().size(); i++) {
            if (i == 0) {
                Glide.with(context).load(item.getImage().get(i)).into(holder.binding.img1);
                holder.binding.img1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onImageClickListener.onItemClick(item.getImage().get(0));
                    }
                });
            } else if (i == 1) {
                Glide.with(context).load(item.getImage().get(i)).into(holder.binding.img2);
                holder.binding.img2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onImageClickListener.onItemClick(item.getImage().get(1));
                    }
                });

            } else {
                Glide.with(context).load(item.getImage().get(i)).into(holder.binding.img3);
                holder.binding.img3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onImageClickListener.onItemClick(item.getImage().get(2));
                    }
                });
            }
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemTextWithImageBinding binding;

        public ViewHolder(ItemTextWithImageBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}