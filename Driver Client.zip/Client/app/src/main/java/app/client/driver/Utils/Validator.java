package app.client.driver.Utils;

import android.util.Patterns;
import android.widget.EditText;
import android.widget.Spinner;

public class Validator {
    public static boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }

    public static boolean isValidEmail(EditText editText) {
        CharSequence email = editText.getText().toString().trim();
        return (!isEmpty(editText) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    public static boolean isValidPassword(EditText editText, int minLength) {
        return editText.getText().toString().trim().length() >= minLength;
    }

    public static boolean isStrongPassword(EditText editText, int minLength) {
        String password = editText.getText().toString().trim();
        return password.length() >= minLength &&
                password.matches(".*[A-Z].*") &&

                password.matches(".*[a-z].*") &&

                password.matches(".*\\d.*");

    }

    public static boolean isValidSelection(Spinner spinner) {
        return spinner.getSelectedItemPosition() != 0;

    }

}
