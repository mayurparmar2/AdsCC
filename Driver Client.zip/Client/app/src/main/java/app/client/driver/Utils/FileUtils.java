package app.client.driver.Utils;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class FileUtils {

    public static MultipartBody.Part[] prepareFileParts(String partName, File[] files) {
        MultipartBody.Part[] fileParts = new MultipartBody.Part[files.length];
        for (int i = 0; i < files.length; i++) {
            File file = files[i];
            RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"), file);
            fileParts[i] = MultipartBody.Part.createFormData(partName, file.getName(), requestBody);
        }
        return fileParts;
    }
}