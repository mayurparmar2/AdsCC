package app.client.driver.Model

data class Parking(
    val id: String,
    val trip_id: String,
    val amount: Int,
    val created_at: String,
    val updated_at: String,
    var isUpload: Boolean
) {
    constructor() : this("", "", 0, "", "", true)
}
