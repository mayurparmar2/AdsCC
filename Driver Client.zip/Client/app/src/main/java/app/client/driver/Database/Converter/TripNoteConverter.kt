package app.client.driver.Database.Converter

import androidx.room.TypeConverter
import app.client.driver.Model.TripNote
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class TripNoteConverter {
    @TypeConverter
    fun fromString(value: String): List<TripNote> {
        val listType = object : TypeToken<List<TripNote>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromList(list: List<TripNote>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}