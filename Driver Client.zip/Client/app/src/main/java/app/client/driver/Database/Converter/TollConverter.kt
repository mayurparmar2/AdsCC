package app.client.driver.Database.Converter

import androidx.room.TypeConverter
import app.client.driver.Model.Toll
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class TollConverter {
    @TypeConverter
    fun fromString(value: String): List<Toll> {
        val listType = object : TypeToken<List<Toll>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromList(list: List<Toll>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}