package app.client.driver.Model

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import app.client.driver.Database.Converter.GasDataConverter
import app.client.driver.Database.Converter.OtherDataConverter
import app.client.driver.Database.Converter.ParkingDataConverter
import app.client.driver.Database.Converter.PoliceChargeDataConverter
import app.client.driver.Database.Converter.PuncherDataConverter
import app.client.driver.Database.Converter.ReceivedCollectionConverter
import app.client.driver.Database.Converter.TollConverter
import app.client.driver.Database.Converter.TripNoteConverter

@Entity(tableName = "TripDetail")
data class TripEntity(
    @PrimaryKey val id: String,
    val driver_id: String,
    val vendor_name: String,
    val customer_name: String,
    val customer_mobile: String,
    val pickup_location: String,
    val drop_location: String,
    val date_time: String,
    val vehicle_name: String,
    val total_collection: String,
    val advance_paid: String,
    val commission: String,
    val status: String,
    val created_at: String,
    val updated_at: String,
    val trip_id: String,
    val driver_name: String,
    val driver_phone: String,
    val totalGasAmount: Int,
    val totalPuncherAmount: Int,
    val totalParkingAmount: Int,
    val totalPoliceChargeAmount: Int,
    val totalTallTaxAmount: Int,
    val totalOtherAmount: Int,
    @TypeConverters(GasDataConverter::class) val gasData: List<GasDatum>,
    @TypeConverters(PuncherDataConverter::class) val puncherData: List<PuncherDatum>,
    @TypeConverters(ParkingDataConverter::class) val parkingData: List<Parking>,
    @TypeConverters(PoliceChargeDataConverter::class) val policeChargeData: List<Police>,
    @TypeConverters(TollConverter::class) val tallTaxData: List<Toll>,
    @TypeConverters(OtherDataConverter::class) val otherData: List<OtherModel>,
    @TypeConverters(ReceivedCollectionConverter::class) val receivedCollection: List<ReceivedCollection>,
    @TypeConverters(TripNoteConverter::class) val tripNotes: List<TripNote>,
    val totalPL: Int
)
