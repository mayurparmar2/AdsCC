package app.client.driver.UI;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import app.client.driver.Utils.DriverPreference;
import app.client.driver.Utils.Utils;
import app.client.driver.databinding.ActivitySettingBinding;

public class SettingActivity extends BaseActivity {
    ActivitySettingBinding binding;
    DriverPreference preference;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        preference = new DriverPreference(this);
        binding.driverName.setText(preference.getDriverName());
        binding.settingLogout.setOnClickListener(v -> {
            binding.progress.setVisibility(View.VISIBLE);
            preference.setAuthToken("");
            preference.setLogin(false);
            preference.setDriverName("");
            preference.setDeviceToken("");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    binding.progress.setVisibility(View.GONE);
                    BaseActivity.finishAllActivities();
                    Utils.restartApp(getApplicationContext());
                }
            }, 1500);
        });
        binding.icBack.setOnClickListener(v -> {
            onBackPressed();
        });
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }
}