package app.client.driver.UI;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import app.client.driver.Utils.DriverPreference;
import app.client.driver.Utils.Utils;
import app.client.driver.databinding.ActivitySplashBinding;

public class SplashActivity extends BaseActivity {
    ActivitySplashBinding binding;
    DriverPreference preference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        preference = new DriverPreference(this);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (task.isSuccessful()) {
                            if (task.getResult() != null) {
                                preference.setDeviceToken(task.getResult());
                                Log.d("DEVICETOKEN", task.getResult());
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (preference.isLogin()) {
                                            startActivity(new Intent(SplashActivity.this, HomeActivity.class));
                                            finish();
                                        } else {
                                            startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                                            finish();
                                        }
                                    }
                                }, 1000);

                            } else {
                                if (preference.isLogin()) {
                                    startActivity(new Intent(SplashActivity.this, HomeActivity.class));
                                    finish();
                                } else {
                                    startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                                    finish();
                                }
                            }
                        } else {
                            if (preference.isLogin()) {
                                startActivity(new Intent(SplashActivity.this, HomeActivity.class));
                                finish();
                            } else {
                                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                                finish();
                            }
                        }
                    }
                });
            }
        }, 2000);

    }
}