package app.client.driver.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import app.client.driver.Model.Trips;
import app.client.driver.R;
import app.client.driver.databinding.ItemTripBinding;

public class PastTripAdapter extends RecyclerView.Adapter<PastTripAdapter.ViewHolder> {
    private final String TAG = PastTripAdapter.class.getSimpleName();
    private Context context;
    private List<Trips> list;
    private OnItemClickListener onItemClickListener;


    public void updateList(List<Trips> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();

    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public PastTripAdapter(Context context, List<Trips> list, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemTripBinding binding = ItemTripBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ItemTripBinding binding = holder.binding;
        Trips item = list.get(position);

        binding.txtName.setText(item.getCustomerName());
        binding.txtPickup.setText(item.getPickupLocation());
        binding.txtDrop.setText(item.getDropLocation());
        String[] parts = item.getDateTime().split(" ", 2);


        String datePart = parts[0];
        String timePart = parts[1];
        binding.txtDate.setText(datePart);
        binding.txtTime.setText(timePart);
        binding.txtStatus.setText(item.getStatus());
        if (item.getStatus().equals("pending")) {
            binding.txtStatus.setTextColor(context.getColor(R.color.red));
        } else {
            binding.txtStatus.setTextColor(context.getColor(R.color.colorPrimary));
        }

        holder.itemView.setOnClickListener(v -> {
            onItemClickListener.onItemClick(position);
        });


    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemTripBinding binding;

        public ViewHolder(ItemTripBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;

        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}