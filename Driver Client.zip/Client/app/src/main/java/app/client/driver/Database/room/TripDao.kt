package app.client.driver.Database.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import app.client.driver.Model.TripEntity
import app.client.driver.Model.Trips

@Dao
interface TripDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(trip: Trips)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(trips: List<Trips>)

    @Query("SELECT * FROM trips")
    fun getAllTrips(): LiveData<List<Trips>>

    @Query("DELETE FROM trips")
    suspend fun deleteAll()

    @Query("SELECT * FROM trips")
    suspend fun getAllTodaysTrips(): List<Trips>
}
