package app.client.driver.UI;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.CancellationToken;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnTokenCanceledListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import app.client.driver.Adpater.AddMoneyAdapter;
import app.client.driver.Adpater.AddNoteAdapter;
import app.client.driver.Adpater.AddParkingAdapter;
import app.client.driver.Adpater.AddPoliceAdapter;
import app.client.driver.Adpater.AddReceCollAdapter;
import app.client.driver.Adpater.AddTollAdapter;
import app.client.driver.Adpater.GasAdapter;
import app.client.driver.Adpater.PuncherAdapter;
import app.client.driver.Database.Mvvm.TripDetailRepository;
import app.client.driver.Database.Mvvm.TripViewModel;
import app.client.driver.Database.TripViewModelFactory;
import app.client.driver.Model.GasDatum;
import app.client.driver.Model.OtherModel;
import app.client.driver.Model.Parking;
import app.client.driver.Model.Police;
import app.client.driver.Model.PuncherDatum;
import app.client.driver.Model.ReceivedCollection;
import app.client.driver.Model.Toll;
import app.client.driver.Model.TripEntity;
import app.client.driver.Model.TripNote;
import app.client.driver.R;
import app.client.driver.UI.Dialog.CommonDialog;
import app.client.driver.Utils.DriverPreference;
import app.client.driver.UI.Dialog.GasDialog;
import app.client.driver.UI.Dialog.PoliceDialog;
import app.client.driver.UI.Dialog.ReceiveCollectionDialog;
import app.client.driver.Utils.ImageUtil;
import app.client.driver.Utils.Utils;
import app.client.driver.databinding.ActivityViewTripBinding;
import app.client.driver.network.ApiService;
import app.client.driver.network.Respose.AddResponse;
import app.client.driver.network.Respose.TripsDetailsResponse;
import app.client.driver.network.RetrofitClient2;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewTripActivity extends BaseActivity implements View.OnClickListener {
    TripEntity TampTripEntity;
    ActivityViewTripBinding binding;
    ApiService apiService;
    List<GasDatum> gasList;
    List<PuncherDatum> puncherList;
    List<OtherModel> othersList;
    List<Parking> parkingList;
    List<Toll> tollList;
    List<Police> policeList;
    List<ReceivedCollection> collectionList;
    List<TripNote> noteList;
    GasAdapter gasAdapter;
    AddMoneyAdapter othersAdapter;
    private GasDialog gasDialog;
    private AddParkingAdapter parkingAdapter;
    private AddTollAdapter tollAdapter;
    private AddPoliceAdapter policeAdapter;
    private PuncherAdapter puncherAdapter;
    private int tripId;
    private AddMoneyAdapter collectionAdapter;
    private AddReceCollAdapter addCollectionAdapter;
    private AddNoteAdapter collectionAdapter2;
    private DriverPreference preference;

    TripViewModel tripViewModel;
    KProgressHUD progressHUD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewTripBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        progressHUD = KProgressHUD.create(this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please wait")


                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f);

        tripId = getIntent().getIntExtra("id", -1);
        tripViewModel = new ViewModelProvider(this, new TripViewModelFactory(getApplication())).get(TripViewModel.class);

        preference = new DriverPreference(this);
        apiService = RetrofitClient2.getClient(preference.getAuthToken()).create(ApiService.class);

        binding.btnPuncher.setOnClickListener(this);
        binding.btnGas.setOnClickListener(this);
        binding.btnOthers.setOnClickListener(this);
        binding.btnToll.setOnClickListener(this);
        binding.btnPolice.setOnClickListener(this);
        binding.btnParking.setOnClickListener(this);
        binding.btnCollection.setOnClickListener(this);
        binding.btnNote.setOnClickListener(this);
        binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        initData();
    }

    private void updateList(TripEntity trip) {

        progressHUD.dismiss();


        binding.txtTitleName.setText(trip.getDriver_name());
        binding.txtTripId.setText(trip.getId());
        binding.txtAdvancePaid.setText(trip.getAdvance_paid());
        binding.txtCutomerMobile.setText(trip.getCustomer_mobile());
        binding.txtCutomerName.setText(trip.getCustomer_name());
        binding.txtPickupLocation.setText(trip.getPickup_location());
        binding.txtDropLocation.setText(trip.getDrop_location());
        binding.txtDateTime.setText(trip.getDate_time());
        binding.txtVehicleName.setText(trip.getVehicle_name());
        binding.txtTotalCollection.setText(trip.getTotal_collection());

        gasList = trip.getGasData();
        puncherList = trip.getPuncherData();
        policeList = trip.getPoliceChargeData();
        tollList = trip.getTallTaxData();
        parkingList = trip.getParkingData();
        othersList = trip.getOtherData();
        collectionList = trip.getReceivedCollection();
        noteList = trip.getTripNotes();

        gasAdapter = new GasAdapter(getApplicationContext(), gasList, new GasAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
            }
        }, new GasAdapter.OnImageClickListener() {
            @Override
            public void onItemClick(String url) {
                showImageDialog(url);
            }
        });
        binding.rVGas.setAdapter(gasAdapter);

        puncherAdapter = new PuncherAdapter(getApplicationContext(), puncherList, new PuncherAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
            }
        }, new PuncherAdapter.OnImageClickListener() {
            @Override
            public void onItemClick(String url) {
                showImageDialog(url);
            }
        });
        binding.rVPuncher.setAdapter(puncherAdapter);


        policeAdapter = new AddPoliceAdapter(getApplicationContext(), policeList, new AddPoliceAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
            }
        });
        binding.rVPolice.setAdapter(policeAdapter);

        tollAdapter = new AddTollAdapter(getApplicationContext(), tollList, new AddTollAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
            }
        });
        binding.rVToll.setAdapter(tollAdapter);

        parkingAdapter = new AddParkingAdapter(getApplicationContext(), parkingList, new AddParkingAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {


            }
        });
        binding.rVParking.setAdapter(parkingAdapter);

        othersAdapter = new AddMoneyAdapter(getApplicationContext(), othersList, new AddMoneyAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
            }
        });
        binding.rVOthers.setAdapter(othersAdapter);


        addCollectionAdapter = new AddReceCollAdapter(getApplicationContext(), collectionList, new AddReceCollAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
            }
        });
        binding.rVCollection.setAdapter(addCollectionAdapter);

        collectionAdapter2 = new AddNoteAdapter(getApplicationContext(), noteList, new AddNoteAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
            }
        });
        binding.rvNotes.setAdapter(collectionAdapter2);
    }


    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        finish();
    }

    private LocationManager locationManager;
    private Geocoder geocoder;
    public String locationLL = "";

    @SuppressLint("MissingPermission")
    private void initData() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(getApplicationContext());
        geocoder = new Geocoder(this, Locale.getDefault());
        if (tripId != -1) {
            gasList = new ArrayList<>();
            othersList = new ArrayList<>();
            parkingList = new ArrayList<>();
            tollList = new ArrayList<>();
            policeList = new ArrayList<>();
            puncherList = new ArrayList<>();
            collectionList = new ArrayList<>();
            tripViewModel.getAllTripsDetail().observe(this, new Observer<List<TripEntity>>() {
                @Override
                public void onChanged(List<TripEntity> list) {
                    if (list != null && !list.isEmpty()) {
                        for (int i = 0; i < list.size(); i++) {
                            if (list.get(i).getTrip_id().equals(String.valueOf(tripId))) {
                                TampTripEntity = list.get(i);
                                updateList(TampTripEntity);
                                Log.e("MTAG", "onChanged : ");
                            }
                        }
                    }
                }
            });

            showTripDetailsTrip();
            binding.btnCreate.setOnClickListener(v -> {
                if (Utils.isInternetAvailable(ViewTripActivity.this)) {
                    MarkTripComplete();
                } else {
                    Toast.makeText(getApplicationContext(), "Internet is not available", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(getApplicationContext(), "Data not found", Toast.LENGTH_SHORT).show();
            binding.textMain.setVisibility(View.INVISIBLE);
        }
    }

    private void MarkTripComplete() {
        progressHUD.show();
        Call<AddResponse> call = apiService.MarkTripComplete(tripId);
        call.enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                progressHUD.dismiss();
                if (response.isSuccessful()) {
                    AddResponse tripsResponse = response.body();
                    Boolean error = tripsResponse.getError();
                    if (!error) {
                        Toast.makeText(getApplicationContext(), tripsResponse.getMsg(), Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK);
                        finish();
                    }
                } else {


                    Log.e("AddDriver", "Today's Trip failed");
                    Toast.makeText(getApplicationContext(), "TodaysTrip failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {
                progressHUD.dismiss();
                Log.e("Login", "TodaysTrip error: " + t.getMessage());
                Toast.makeText(getApplicationContext(), "TodaysTrip error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showTripDetailsTrip() {
        progressHUD.show();
        if (!Utils.isInternetAvailable(this)) {
            Log.e("MTAG", "showTripDetailsTrip tripId: " + tripId);


            Log.e("MTAG", "showTripDetailsTrip tripViewModel:" + tripViewModel);

            try {
                tripViewModel.getTripsDetails(String.valueOf(tripId), tripEntity -> {
                    if (tripEntity != null) {
                        updateList(tripEntity);
                        progressHUD.dismiss();
                    } else {
                        progressHUD.dismiss();
                    }
                    return null;
                });
            } catch (Exception e) {
                progressHUD.dismiss();
                e.printStackTrace();
                Log.e("MTAG", "showTripDetailsTrip" + e);
            }
        } else {
            Call<TripsDetailsResponse> call = apiService.showTripDetailsTrip(tripId);
            call.enqueue(new Callback<TripsDetailsResponse>() {
                @Override
                public void onResponse(Call<TripsDetailsResponse> call, Response<TripsDetailsResponse> response) {
                    if (response.isSuccessful()) {
                        TripsDetailsResponse tripsResponse = response.body();

                        Log.e("MTAG", "onResponse :: ->" +new Gson().toJson(tripsResponse));


                        Boolean error = tripsResponse.getError();
                        if (!error) {
                            if (tripsResponse.getData() != null && !tripsResponse.getData().getData().isEmpty()) {
                                TripDetailRepository tripDetailRepository = tripViewModel.getTripDetailRepository();


                                tripDetailRepository.insertAll(response.body().getData().getData());
                                if (tripsResponse.getData().getData() != null && !tripsResponse.getData().getData().isEmpty()) {
                                    updateList(tripsResponse.getData().getData().get(0));
                                }
                            }
                        }
                    } else {
                        Log.e("AddDriver", "TodaysTrip failed");
                        Toast.makeText(getApplicationContext(), "TodaysTrip failed", Toast.LENGTH_SHORT).show();
                    }
                    try {
                        progressHUD.dismiss();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call<TripsDetailsResponse> call, Throwable t) {
                    progressHUD.dismiss();


                    Log.e("Login", "TodaysTrip error: " + t.getMessage());
                    Toast.makeText(getApplicationContext(), "TodaysTrip error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }


    }

    private void showImageDialog(String Url) {


        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_image, null);
        PhotoView imageView = dialogView.findViewById(R.id.dialogImageView);


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView)
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();

        Glide.with(this).load(Url).into(imageView);


    }

    ArrayList<File> fileArrayList = new ArrayList<>();

    private MultipartBody.Part[] prepareFilePart(String partName, ArrayList<File> files) {
        MultipartBody.Part[] parts = new MultipartBody.Part[files.size()];
        for (int i = 0; i < files.size(); i++) {
            File file = files.get(i);
            RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
            parts[i] = MultipartBody.Part.createFormData(partName, file.getName(), requestFile);
        }
        return parts;
    }

    private FusedLocationProviderClient fusedLocationClient;
    @SuppressLint("MissingPermission")
    ActivityResultLauncher<Intent> captureImageLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    if (gasDialog != null) {
                        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                        geocoder = new Geocoder(this, Locale.getDefault());
                        getLocation();
                        File file = new File(gasDialog.getCurrentPhotoPath());
                        new Handler().postDelayed(new Runnable() {
                            @RequiresApi(api = Build.VERSION_CODES.P)
                            @Override
                            public void run() {
                                File file2 = new File(ImageUtil.addTimestampAndLocationToImage(ViewTripActivity.this, file.getPath(), file.getName(), locationLL).getPath());
                                fileArrayList.add(file2);
                                Uri imageUri = Uri.fromFile(file2);
                                gasDialog.setCapturedImageUrl(imageUri);
                            }
                        }, 200);

                    }
                }
            });

    @SuppressLint("MissingPermission")
    private void getLocation() {
        if (checkPermissions()) {

            if (isLocationEnabled()) {
                fusedLocationClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        Location location = task.getResult();
                        if (location == null) {
                            requestNewLocationData();
                        } else {
                            try {
                                List<Address> addresses = geocoder.getFromLocation(
                                        location.getLatitude(),
                                        location.getLongitude(),
                                        1);

                                if (addresses != null && addresses.size() > 0) {
                                    Address address = addresses.get(0);
                                    String addressString = address.getAddressLine(0);

                                    Log.e("Address", addressString);

                                    locationLL = addressString;


                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                                Log.e("TAG", "onComplete: " + e.getMessage());

                            }

                        }
                    }
                });
            } else {
                Toast.makeText(this, "Please turn on" + " your location...", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        } else {


            requestPermissions();
        }


    }

    Dialog commonDialog;
    Dialog policeDialog;
    Dialog receiveCollectionDialog;

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnGas) {
            gasDialog = new GasDialog(this, "Add Gas", captureImageLauncher, tripId, new GasDialog.OnItemClickListener() {
                @Override
                public void onAddClick(int paymentType, int amount, String time) {
                    MultipartBody.Part[] imageParts = prepareFilePart("image[]", fileArrayList);
                    if (!Utils.isInternetAvailable(ViewTripActivity.this)) {
                        if (TampTripEntity != null) {
                            if (fileArrayList.isEmpty()) {
                                gasDialog.binding.txtError.setVisibility(View.VISIBLE);
                                gasDialog.binding.txtError.setText("Please view captured image before submit");
                                Toast.makeText(ViewTripActivity.this, "Please Add Some Image", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            List<String> imgList = new ArrayList<>();
                            for (int i = 0; i < fileArrayList.size(); i++) {
                                imgList.add(fileArrayList.get(i).getPath());
                            }
                            List<GasDatum> list = TampTripEntity.getGasData();
                            GasDatum gasDatum = new GasDatum(String.valueOf(tripId), amount, String.valueOf(paymentType), imgList, time);
                            gasDatum.setUpload(false);
                            list.add(gasDatum);
                            tripViewModel.updateGasData(String.valueOf(tripId), list);
                            gasDialog.dismiss();
                        }
                        fileArrayList = new ArrayList<>();
                    } else {
                        progressHUD.show();
                        Log.e("AddGas", "Add Puncher Time: " + time);
                        Call<AddResponse> call = apiService.addGas(amount, tripId, paymentType, imageParts, time);
                        call.enqueue(new Callback<AddResponse>() {
                            @Override
                            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                                gasDialog.dismiss();
                                progressHUD.dismiss();
                                if (response.isSuccessful()) {
                                    AddResponse loginResponse = response.body();
                                    Log.e("addGas", "Add Puncher isSuccessful: " + new Gson().toJson(loginResponse));


                                    Boolean error = loginResponse.getError();
                                    if (!error) {
                                        fileArrayList = new ArrayList<>();
                                        Toast.makeText(getApplicationContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                                        initData();
                                    }
                                } else {
                                    Log.e("AddGas", "Add Gas failed: " + response.code());
                                    Log.e("AddGas", "Add Gas failed: " + response);
                                    fileArrayList = new ArrayList<>();
                                    Toast.makeText(getApplicationContext(), "Add Gas failed", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<AddResponse> call, Throwable t) {
                                gasDialog.dismiss();
                                progressHUD.dismiss();
                                fileArrayList = new ArrayList<>();
                                Log.e("Gas", "Add Gas error: " + t.getMessage());
                                Toast.makeText(getApplicationContext(), "Add Gas error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            });
            gasDialog.show();
        } else if (v.getId() == R.id.btnPuncher) {
            gasDialog = new GasDialog(this, "Add Puncher", captureImageLauncher, tripId, new GasDialog.OnItemClickListener() {
                @Override
                public void onAddClick(int paymentType, int amount, String time) {
                    MultipartBody.Part[] imageParts = prepareFilePart("image[]", fileArrayList);
                    if (!Utils.isInternetAvailable(ViewTripActivity.this)) {
                        if (TampTripEntity != null) {
                            if (fileArrayList.isEmpty()) {
                                gasDialog.binding.txtError.setVisibility(View.VISIBLE);
                                gasDialog.binding.txtError.setText("Please view captured image before submit");
                                Toast.makeText(ViewTripActivity.this, "Please Add Some Image", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            List<String> imgList = new ArrayList<>();
                            for (int i = 0; i < fileArrayList.size(); i++) {
                                imgList.add(fileArrayList.get(i).getPath());
                            }
                            List<PuncherDatum> list = TampTripEntity.getPuncherData();

                            PuncherDatum puncherDatum = new PuncherDatum(String.valueOf(tripId), amount, String.valueOf(paymentType), imgList, time);
                            puncherDatum.setUpload(false);
                            list.add(puncherDatum);
                            tripViewModel.updatePuncherData(String.valueOf(tripId), list);
                            gasDialog.dismiss();
                        }
                        fileArrayList = new ArrayList<>();
                    } else {
                        progressHUD.show();
                        Log.e("AddGas", "Add Puncher Time: " + time);
                        apiService.addPuncher(amount, tripId, paymentType, imageParts, time).enqueue(new Callback<AddResponse>() {
                            @Override
                            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                                gasDialog.dismiss();
                                progressHUD.dismiss();
                                if (response.isSuccessful()) {
                                    AddResponse loginResponse = response.body();

                                    Log.e("addPuncher", "Add addPuncher isSuccessful: " + new Gson().toJson(loginResponse));
                                    Boolean error = loginResponse.getError();
                                    if (!error) {
                                        fileArrayList = new ArrayList<>();
                                        Toast.makeText(getApplicationContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                                        initData();
                                    }
                                } else {
                                    Log.e("AddGas", "Add Puncher failed: " + response.code());
                                    Log.e("AddGas", "Add Puncher failed: " + response);
                                    fileArrayList = new ArrayList<>();
                                    Toast.makeText(getApplicationContext(), "Add Puncher failed", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<AddResponse> call, Throwable t) {
                                gasDialog.dismiss();
                                progressHUD.dismiss();
                                fileArrayList = new ArrayList<>();
                                Log.e("Puncher", "Add Puncher error: " + t.getMessage());
                                Toast.makeText(getApplicationContext(), "Add Puncher error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }


                }
            });
            gasDialog.show();
        } else if (v.getId() == R.id.btnPolice) {
            policeDialog = new PoliceDialog(this, "Add Police", new PoliceDialog.OnItemClickListener() {
                @Override
                public void onAddClick(String amount, String location) {
                    if (!Utils.isInternetAvailable(ViewTripActivity.this)) {
                        Log.e("btnPolice", "Add Police  --->: ");
                        if (TampTripEntity != null) {
                            List<Police> list = TampTripEntity.getPoliceChargeData();
                            list.add(new Police("", String.valueOf(tripId), Integer.parseInt(amount), location, Utils.getCurrentTime(), "", false));
                            tripViewModel.updatePoliceData(String.valueOf(tripId), list);
                        }
                        progressHUD.dismiss();
                    } else {
                        addPolice(amount, location);
                    }
                }
            });
            policeDialog.show();
        } else if (v.getId() == R.id.btnOthers) {
            commonDialog = new CommonDialog(this, "Add Others", amount -> {
                if (!Utils.isInternetAvailable(ViewTripActivity.this)) {
                    if (TampTripEntity != null) {
                        List<OtherModel> list = TampTripEntity.getOtherData();
                        list.add(new OtherModel("", String.valueOf(tripId), Integer.parseInt(amount), Utils.getCurrentTime(), "", false));
                        tripViewModel.updateOtherData(String.valueOf(tripId), list);
                    }
                    progressHUD.dismiss();
                } else {
                    addOthers(amount);
                }

            });
            commonDialog.show();
        } else if (v.getId() == R.id.btnToll) {
            commonDialog = new CommonDialog(this, "Add Toll Tax", amount -> {
                if (!Utils.isInternetAvailable(ViewTripActivity.this)) {
                    if (TampTripEntity != null) {
                        List<Toll> list = TampTripEntity.getTallTaxData();
                        list.add(new Toll("", String.valueOf(tripId), Integer.parseInt(amount), Utils.getCurrentTime(), "", false));
                        tripViewModel.updateTollData(String.valueOf(tripId), list);
                    }
                    progressHUD.dismiss();
                } else {
                    addToll(amount);
                }
            });
            commonDialog.show();
        } else if (v.getId() == R.id.btnParking) {
            commonDialog = new CommonDialog(this, "Add Parking", amount -> {
                if (!Utils.isInternetAvailable(ViewTripActivity.this)) {
                    if (TampTripEntity != null) {
                        List<Parking> list = TampTripEntity.getParkingData();
                        list.add(new Parking("", String.valueOf(tripId), Integer.parseInt(amount), Utils.getCurrentTime(), "", false));
                        tripViewModel.updateParkingData(String.valueOf(tripId), list);
                    }
                    progressHUD.dismiss();
                } else {
                    addParking(amount);
                }

            });
            commonDialog.show();
        } else if (v.getId() == R.id.btnCollection) {
            receiveCollectionDialog = new ReceiveCollectionDialog(this, "Add Collection", new ReceiveCollectionDialog.OnItemClickListener() {
                @Override
                public void onAddClick(String amount, int paymentType) {
                    if (!Utils.isInternetAvailable(ViewTripActivity.this)) {
                        if (TampTripEntity != null) {
                            List<ReceivedCollection> list = new ArrayList<>();
                            list.add(new ReceivedCollection("", String.valueOf(tripId), Integer.parseInt(amount), paymentType + "", Utils.getCurrentTime(), "", false));
                            tripViewModel.updateReceivedCollectionData(String.valueOf(tripId), list);
                        }
                        progressHUD.dismiss();
                    } else {
                        addCollection(amount, paymentType);
                    }

                }
            });
            receiveCollectionDialog.show();
        } else if (v.getId() == binding.btnNote.getId()) {
            if (binding.EtNote.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please Enter Some Note", Toast.LENGTH_SHORT).show();
            } else {
                if (!Utils.isInternetAvailable(ViewTripActivity.this)) {
                    if (TampTripEntity != null) {
                        List<TripNote> list = TampTripEntity.getTripNotes();
                        list.add(new TripNote("", String.valueOf(tripId), binding.EtNote.getText().toString(), Utils.getCurrentTime(), "", false));
                        tripViewModel.updateTripNoteData(String.valueOf(tripId), list);
                    }
                    binding.EtNote.getText().clear();
                    progressHUD.dismiss();
                } else {
                    addNote(tripId, binding.EtNote.getText().toString(), Utils.getCurrentTime());
                }

            }
        }
    }

    private void addNote(int id, String note, String dateTime) {
        apiService.addNote(id, note, dateTime).enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                if (response.isSuccessful()) {
                    AddResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(getApplicationContext(), "Note Added Successfully", Toast.LENGTH_SHORT).show();
                        binding.EtNote.getText().clear();
                        initData();
                    }
                } else {
                    Log.e("Add Note", "Add Note failed");
                    Toast.makeText(getApplicationContext(), "Add Note failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {

            }
        });

    }

    private void addCollection(String str, int payment_type) {
        progressHUD.show();
        Call<AddResponse> call = apiService.addCollection(str, String.valueOf(tripId), String.valueOf(payment_type), Utils.getCurrentTime());
        call.enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                progressHUD.dismiss();

                if (response.isSuccessful()) {
                    AddResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(getApplicationContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                        initData();
                    }
                } else {
                    Log.e("addCollection", "addCollection failed");
                    Toast.makeText(getApplicationContext(), "addCollection failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {
                progressHUD.dismiss();
                Log.e("addCollection", "addCollection error: " + t.getMessage());
                Toast.makeText(getApplicationContext(), "addCollection error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addParking(String str) {
        progressHUD.dismiss();

        Call<AddResponse> call = apiService.addParking(str, String.valueOf(tripId), Utils.getCurrentTime());
        call.enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                progressHUD.dismiss();

                if (response.isSuccessful()) {
                    AddResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(getApplicationContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                        initData();
                    }
                } else {
                    Log.e("addParking", "addParking failed");
                    Toast.makeText(getApplicationContext(), "addParking failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {
                progressHUD.dismiss();
                Log.e("addToll", "addParking error: " + t.getMessage());
                Toast.makeText(getApplicationContext(), "addParking error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addToll(String str) {

        Call<AddResponse> call = apiService.addToll(str, String.valueOf(tripId), Utils.getCurrentTime());
        call.enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                progressHUD.dismiss();

                if (response.isSuccessful()) {
                    AddResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(getApplicationContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                        initData();
                    }
                } else {
                    Log.e("addToll", "addToll failed");
                    Toast.makeText(getApplicationContext(), "addOthers failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {
                progressHUD.dismiss();

                Log.e("addToll", "addToll error: " + t.getMessage());
                Toast.makeText(getApplicationContext(), "addToll error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void addOthers(String str) {
        progressHUD.show();

        Call<AddResponse> call = apiService.addOthers(str, String.valueOf(tripId), Utils.getCurrentTime());
        call.enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                progressHUD.dismiss();

                if (response.isSuccessful()) {
                    AddResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(getApplicationContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                        initData();
                    }
                } else {
                    Log.e("addOthers", "addOthers failed");
                    Toast.makeText(getApplicationContext(), "addOthers failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {
                progressHUD.dismiss();

                Log.e("Gas", "addOthers error: " + t.getMessage());
                Toast.makeText(getApplicationContext(), "addOthers error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void addPolice(String amoun, String location) {
        progressHUD.show();
        Call<AddResponse> call = apiService.addPolice(amoun, String.valueOf(tripId), location, Utils.getCurrentTime());
        call.enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                progressHUD.dismiss();
                if (response.isSuccessful()) {
                    AddResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(getApplicationContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                        initData();
                    }
                } else {
                    Log.e("addPolice", "addPolice failed");
                    Toast.makeText(getApplicationContext(), "addPolice failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {
                progressHUD.dismiss();

                Log.e("addPolice", "addPolice error: " + t.getMessage());
                Toast.makeText(getApplicationContext(), "addPolice error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    @SuppressLint("MissingPermission")
    private void requestNewLocationData() {


        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(5);
        mLocationRequest.setFastestInterval(0);
        mLocationRequest.setNumUpdates(1);


        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, Looper.myLooper());
    }

    private LocationCallback mLocationCallback = new LocationCallback() {

        @Override
        public void onLocationResult(LocationResult locationResult) {
            Location mLastLocation = locationResult.getLastLocation();
            getLocation();
        }
    };


    int PERMISSION_ID = 44;


    @Override
    public void
    onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_ID) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLocation();
            }
        }
    }

    private boolean checkPermissions() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }


    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_ID);
    }


    @Override
    public void onResume() {
        super.onResume();
        if (checkPermissions()) {
            getLocation();
        }
    }


}