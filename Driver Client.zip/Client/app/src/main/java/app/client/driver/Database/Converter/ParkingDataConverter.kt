package app.client.driver.Database.Converter

import androidx.room.TypeConverter
import app.client.driver.Model.Parking
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ParkingDataConverter {
    @TypeConverter
    fun fromString(value: String): List<Parking> {
        val listType = object : TypeToken<List<Parking>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromList(list: List<Parking>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}