package app.client.driver.Utils;

public class DataSaveModelUtil {
    private static final String PREF_NAME = "DataSaveModelPref";
    private static final String KEY_DATA_MODEL = "dataSaveModel";


}
