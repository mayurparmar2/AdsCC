package app.admin.driver.Model;


public class Gas {

    String trip_id;
    String image;
    String amount;
    String time;
    String payment_type;

    public Gas(String trip_id, String image, String amount, String time, String payment_type) {
        this.trip_id = trip_id;
        this.image = image;
        this.amount = amount;
        this.time = time;
        this.payment_type = payment_type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }


    public String getTrip_id() {
        return trip_id;
    }

    public void setTrip_id(String trip_id) {
        this.trip_id = trip_id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }
}
