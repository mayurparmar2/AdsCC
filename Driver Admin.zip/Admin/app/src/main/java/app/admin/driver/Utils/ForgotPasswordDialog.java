package app.admin.driver.Utils;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.Window;
import android.widget.Toast;
import androidx.annotation.NonNull;
import com.kaopiz.kprogresshud.KProgressHUD;

import app.admin.driver.R;
import app.admin.driver.databinding.DialogForgotPasswordBinding;
import app.admin.driver.Model.Gas;
import app.admin.driver.Network.ApiService;
import app.admin.driver.Network.Respose.LoginResponse;
import app.admin.driver.Network.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPasswordDialog extends Dialog {
    private Activity activity;
    boolean idSendOtp = false;
    KProgressHUD progressHUD;
    public interface OnItemClickListener {
        void onAddClick(Gas gas);
    }
    DialogForgotPasswordBinding binding;

    public ForgotPasswordDialog(@NonNull Activity activity) {
        super(new ContextThemeWrapper(activity, R.style.CustomDialogTheme));


        this.activity = activity;
    }

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        if (getWindow() != null) {
            getWindow().setGravity(17);
            getWindow().setBackgroundDrawableResource(17170445);
        }
        binding = DialogForgotPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        progressHUD = KProgressHUD.create(activity)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please wait")
//                .setDetailsLabel("Downloading data")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f);


        binding.BtnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Validator.isEmpty(binding.EtEmail)) {
                    binding.EtEmail.setError("email Id is required");
                    binding.EtEmail.requestFocus();
                    return;
                }
                if(idSendOtp){
                    if (Validator.isEmpty(binding.otp)) {
                        binding.otp.setError("otp is required");
                        binding.otp.requestFocus();
                        return;
                    }
                    if (Validator.isEmpty(binding.password)) {
                        binding.password.setError("password is required");
                        binding.password.requestFocus();
                        return;
                    }
                    if (Validator.isEmpty(binding.confirmPassword)) {
                        binding.confirmPassword.setError("Confirm Password is required");
                        binding.confirmPassword.requestFocus();
                        return;
                    }
                    if (!binding.password.getText().toString().equals(binding.confirmPassword.getText().toString())) {
                        binding.confirmPassword.setError("confirm Password and password not match");
                        binding.confirmPassword.requestFocus();
                        return;
                    }
                    callForgetPassword(binding);
                }
                sendEmailOTP(binding);
            }
        });
    }

    private void sendEmailOTP(DialogForgotPasswordBinding binding) {
        progressHUD.show();
        ApiService apiService = RetrofitClient.getClient(new AdminPreference(activity).getAuthToken()).create(ApiService.class);
        Call<LoginResponse> call = apiService.sendEmailOTP(
                binding.EtEmail.getText().toString().trim()
        );
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                progressHUD.dismiss();
                if (response.isSuccessful()) {
                    LoginResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(activity, "Send email OTP successful", Toast.LENGTH_SHORT).show();
//                        customDialog.dismiss();
                        idSendOtp = true;
                        binding.LinearLayoutForgotPassword.setVisibility(View.VISIBLE);
                        binding.BtnCreate.setText("Forgot");
                        binding.EtEmail.setEnabled(false);
                        binding.otp.requestFocus();
                    }
                    Log.e("sendEmailOTP", "Send email OTP successful, Token: " + error);
                } else {
                    Log.e("sendEmailOTP", "Login failed");
                }
            }
            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                progressHUD.dismiss();
                Log.e("sendEmailOTP", "send Email OTP error: " + t.getMessage());
                Toast.makeText(activity, "Send email OTP error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void callForgetPassword(DialogForgotPasswordBinding binding) {
        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
        Call<LoginResponse> call = apiService.forgot(
                binding.EtEmail.getText().toString(),
                Integer.parseInt(binding.otp.getText().toString()),
                binding.password.getText().toString(),
                binding.confirmPassword.getText().toString()
        );

        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful()) {
                    LoginResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(activity, "Forget password successful", Toast.LENGTH_SHORT).show();
                        dismiss();
                        return;
                    }
                    Log.e("Forget", "Login successful, Token: " + loginResponse.getMsg());
                    binding.errorMessage.setText("Login failed");
                    binding.errorMessage.setVisibility(View.VISIBLE);
                } else {
                    Log.e("Forget", "Login failed");
                    binding.errorMessage.setText("Login failed");
                    binding.errorMessage.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.e("Forget", "Forget Password error: " + t.getMessage());
                Toast.makeText(activity, "Forget password error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}


























































































































