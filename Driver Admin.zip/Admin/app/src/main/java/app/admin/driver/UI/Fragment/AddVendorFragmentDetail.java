package app.admin.driver.UI.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import app.admin.driver.Network.Respose.AddResponse;
import app.admin.driver.Network.RetrofitClient;
import app.admin.driver.Utils.Validator;
import app.admin.driver.databinding.FragmentAddVendorDetailsBinding;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddVendorFragmentDetail extends Fragment {
    FragmentAddVendorDetailsBinding binding;
    OnSubmitClickListener onSubmitClickListener;

    public interface OnSubmitClickListener {
        void  onSubmitClick();

//        void  onClickAdded();
//        void  onClickDeleted();

    }
    public AddVendorFragmentDetail(OnSubmitClickListener onSubmitClickListener) {
        this.onSubmitClickListener =onSubmitClickListener;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAddVendorDetailsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        binding.btnCreate.setOnClickListener(v -> {
            if (Validator.isEmpty(binding.EtName)) {
                binding.EtName.setError("Name is required");
                binding.EtName.requestFocus();
                return;
            }
            addVendor(binding.EtName.getText().toString());
        });
    }

    private void addVendor(String name) {
        Call<AddResponse> call = RetrofitClient.getVendorService(requireContext()).addVendor(name);
        call.enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                if (response.isSuccessful()) {
                    AddResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(requireContext(), "Data Vendor Successfully", Toast.LENGTH_SHORT).show();
                        binding.EtName.getText().clear();
                        onSubmitClickListener.onSubmitClick();
                    }
                } else {
                    Log.e("AddVendor", "Add Vendor failed");
                    Toast.makeText(requireContext(), "Add Vendor failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {
                Log.e("Login", "Add Vendor error: " + t.getMessage());
                Toast.makeText(requireContext(), "Add Vendor error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void clear() {
        binding.EtName.getText().clear();

    }
}