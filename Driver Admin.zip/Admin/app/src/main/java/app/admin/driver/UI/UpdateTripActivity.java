package app.admin.driver.UI;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import app.admin.driver.Adpater.ViewPagerAdapter;
import app.admin.driver.Model.Driver;
import app.admin.driver.Model.Vendor;
import app.admin.driver.Network.DriverService;
import app.admin.driver.Network.Respose.AddResponse;
import app.admin.driver.Network.Respose.DriverResponse;
import app.admin.driver.Network.Respose.VendorResponse;
import app.admin.driver.Network.RetrofitClient;
import app.admin.driver.Network.TripService;
import app.admin.driver.Network.TripsResponse.TripDetails;
import app.admin.driver.Network.VendorService;
import app.admin.driver.Utils.AdminPreference;
import app.admin.driver.Utils.Validator;
import app.admin.driver.databinding.ActivityCreateTripBinding;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateTripActivity extends BaseActivity {
    ActivityCreateTripBinding binding;
    private ViewPagerAdapter viewPagerAdapter;
    private Calendar calendar;
    private TripService tripService;
    private String selectedDateTime = "";
    List<Vendor> vendorList;
    List<Driver> driverList;

    int selectedItemVendorPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateTripBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.btnCreate.setText("Update");
        binding.name.setText("Update Trip");
        tripService = RetrofitClient.getClient(new AdminPreference(this).getAuthToken()).create(TripService.class);
        calendar = Calendar.getInstance();
        binding.imgBack.setOnClickListener(v -> {
            finish();
        });

        Intent intent = getIntent();
        String model = intent.getStringExtra("model");
        if (model != null) {
            Gson gson = new Gson();
            TripDetails tripDetails = gson.fromJson(model, TripDetails.class);

            loadData(tripDetails);
            getVendor();
            getDriver();

            binding.etDatetime.setOnClickListener(v -> {
                showDateTimePicker();
            });
            binding.btnCreate.setOnClickListener(v -> {
                if (Validator.isEmpty(binding.etCustomerName)) {
                    binding.etCustomerName.setError("Customer Name is required");
                    binding.etCustomerName.requestFocus();
                    return;
                }
                if (Validator.isEmpty(binding.etCustomerMobile)) {
                    binding.etCustomerMobile.setError("Customer mobile number is required");
                    binding.etCustomerMobile.requestFocus();
                    return;
                }

                if (Validator.isEmpty(binding.etPickupLocation)) {
                    binding.etPickupLocation.setError("Pickup Location  is required");
                    binding.etPickupLocation.requestFocus();
                    return;
                }
                if (Validator.isEmpty(binding.etDropLocation)) {
                    binding.etDropLocation.setError("Drop Location is required");
                    binding.etDropLocation.requestFocus();
                    return;
                }
                if (selectedDateTime.isEmpty()) {
                    binding.etDatetime.setError("Drop Location is required");
                    binding.etDatetime.requestFocus();
                    return;
                }
                if (Validator.isEmpty(binding.etVehicaleName)) {
                    binding.etVehicaleName.setError("Drop Location is required");
                    binding.etVehicaleName.requestFocus();
                    return;
                }
                if (Validator.isEmpty(binding.etTotalCollection)) {
                    binding.etTotalCollection.setError("Drop Location is required");
                    binding.etTotalCollection.requestFocus();
                    return;
                }
                if (Validator.isEmpty(binding.etAdvancePaid)) {
                    binding.etAdvancePaid.setError("Drop Location is required");
                    binding.etAdvancePaid.requestFocus();
                    return;
                }
                if (Validator.isEmpty(binding.etCommission)) {
                    binding.etCommission.setError("Drop Location is required");
                    binding.etCommission.requestFocus();
                    return;
                }
                editTrip(tripDetails.getId());
            });
        }

    }

    private void loadData(TripDetails tripDetails) {
        selectedDateTime = tripDetails.getDateTime();
        binding.etCustomerName.setText(tripDetails.getCustomerName());
        binding.etCustomerMobile.setText(tripDetails.getCustomerMobile());
        binding.etPickupLocation.setText(tripDetails.getPickupLocation());
        binding.etDropLocation.setText(tripDetails.getDropLocation());
        binding.etDatetime.setText(tripDetails.getDateTime());
        binding.etVehicaleName.setText(tripDetails.getVehicleName());
        binding.etTotalCollection.setText(tripDetails.getTotalCollection());
        binding.etAdvancePaid.setText(tripDetails.getAdvancePaid());
        binding.etCommission.setText(tripDetails.getCommission());

    }

    private void getDriver() {
        DriverService driverService = RetrofitClient.getClient(new AdminPreference(this).getAuthToken()).create(DriverService.class);
        Call<DriverResponse> call = driverService.getDriverList();
        call.enqueue(new Callback<DriverResponse>() {
            @Override
            public void onResponse(Call<DriverResponse> call, Response<DriverResponse> response) {
                if (response.isSuccessful()) {
                    DriverResponse driverResponse = response.body();
                    Boolean error = driverResponse.getError();
                    if (!error) {
                        if (driverResponse.getData() != null && !driverResponse.getData().getData().isEmpty()) {
                            List<String> stringList = new ArrayList<>();
                            driverList = new ArrayList<>();
                            driverList = driverResponse.getData().getData();
                            for (Driver driver : driverResponse.getData().getData()) {
                                stringList.add(driver.getName());
                            }
                            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, stringList);
                            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            binding.spinnerDriver.setAdapter(arrayAdapter);

                        }
                    }
                } else {
                    Log.e("AddDriver", "Add Driver failed");
                    Toast.makeText(getApplicationContext(), "Add Driver failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<DriverResponse> call, Throwable t) {
                Log.e("Login", "Add Driver error: " + t.getMessage());
                Toast.makeText(getApplicationContext(), "Add Driver error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void getVendor() {
        VendorService vendorService = RetrofitClient.getClient(new AdminPreference(this).getAuthToken()).create(VendorService.class);
        Call<VendorResponse> call = vendorService.getVendorList();
        call.enqueue(new Callback<VendorResponse>() {
            @Override
            public void onResponse(Call<VendorResponse> call, Response<VendorResponse> response) {
                if (response.isSuccessful()) {
                    VendorResponse vendorResponse = response.body();
                    Boolean error = vendorResponse.getError();
                    if (!error) {
                        if (vendorResponse.getData() != null && !vendorResponse.getData().getData().isEmpty()) {
                            vendorList = new ArrayList<>();
                            vendorList = vendorResponse.getData().getData();

                            List<String> StringList = new ArrayList<>();
                            StringList.add("No vendor");
                            for (Vendor vendor : vendorList) {
                                StringList.add(vendor.getName());
                            }
                            ArrayAdapter<String> adapterVendor = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, StringList);
                            adapterVendor.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            binding.spinnerVendor.setAdapter(adapterVendor);
                        }
                    }
                } else {
                    Log.e("showDriver", "Add Vendor failed");
                    Toast.makeText(getApplicationContext(), "Add Vendor failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<VendorResponse> call, Throwable t) {
                Log.e("Login", "show Vendor error: " + t.getMessage());
                Toast.makeText(getApplicationContext(), "show Vendor error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void editTrip(String tripId) {
        progressHUD.show();
        int selectedVendor = binding.spinnerVendor.getSelectedItemPosition();
        int selectedDriver = binding.spinnerDriver.getSelectedItemPosition();
//        String mVendor = getMvendor(selectedVendor);
//        String mDriver = getMvendor(selectedDriver);

        String mVendor = vendorList.get(selectedVendor).getId();
        String mDriver = driverList.get(selectedDriver).getId();


//        String trip_id = binding.etTripId.getText().toString();
        String cutomer_name = binding.etCustomerName.getText().toString();
        String cutomer_mobile = binding.etCustomerMobile.getText().toString();
        String pickup_location = binding.etPickupLocation.getText().toString();
        String drop_location = binding.etDropLocation.getText().toString();
        String date_time = binding.etDatetime.getText().toString();
        String vehicle_name = binding.etVehicaleName.getText().toString();
        int total_collection = Integer.parseInt(binding.etTotalCollection.getText().toString());
        int advance_paid = Integer.parseInt(binding.etAdvancePaid.getText().toString());
        int commission = Integer.parseInt(binding.etCommission.getText().toString());


        Log.e("MTAG", "InsertTrip: " + mDriver);

        Call<AddResponse> call = tripService.editTrip(
//                Integer.parseInt(trip_id),
                mDriver,
                mVendor,
                cutomer_name,
                cutomer_mobile,
                pickup_location,
                drop_location,
                date_time,
                vehicle_name,
                total_collection,
                advance_paid,
                commission,
                Integer.parseInt(tripId)
        );


        call.enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {
                progressHUD.dismiss();
                if (response.isSuccessful()) {
                    AddResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        Toast.makeText(getApplicationContext(), "Data Trip Successfully", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK);
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(), loginResponse.getMsg(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Log.e("AddTrip", "Add Trip failed:" + response.code());
                    Toast.makeText(getApplicationContext(), "Add Trip failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {
                progressHUD.dismiss();
                Log.e("Login", "Add Trip error: " + t.getMessage());
                Toast.makeText(getApplicationContext(), "Add Trip error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String getMvendor(int selectedItemPosition) {
        String mvendor = vendorList.get(selectedItemPosition).getId();
        return mvendor;
    }

    private void showDateTimePicker() {
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        showTimePicker();
                    }
                }, year, month, dayOfMonth);

        datePickerDialog
                .getDatePicker()
                .setMinDate(calendar.getTimeInMillis());
        datePickerDialog.show();
    }

    private void showTimePicker() {
        int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        calendar.set(Calendar.MINUTE, minute);


                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.getDefault());
                        selectedDateTime = dateFormat.format(calendar.getTime());
                        binding.etDatetime.setText(selectedDateTime);
                    }
                }, hourOfDay, minute, false);
        timePickerDialog.show();
    }


}