package app.admin.driver.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import app.admin.driver.R;
import app.admin.driver.Utils.Utils;
import app.admin.driver.databinding.ItemTripBinding;
import app.admin.driver.Model.Trips;

public class TripAdapter extends RecyclerView.Adapter<TripAdapter.ViewHolder> {
    private final String TAG = TripAdapter.class.getSimpleName();
    private Context context;
    private List<Trips> list;
    boolean isPastTrip;
    private OnItemClickListener onItemClickListener;


    public void updateList(List<Trips> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();

    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public TripAdapter(Context context, boolean isPastTrip, List<Trips> list, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.isPastTrip = isPastTrip;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemTripBinding binding = ItemTripBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ItemTripBinding binding = holder.binding;
        Trips item = list.get(position);
        binding.txtName.setText(item.getDriver_name()+"-"+item.getTrip_id());
        binding.txtPickup.setText(item.getPickupLocation());
        binding.txtDrop.setText(item.getDropLocation() + "");
        binding.txtDate.setText(Utils.getDayOfWeek(item.getDateTime()) + "," + item.getDate());
        binding.txtTime.setText(item.getTime());
        binding.txtStatus.setText(item.getStatus());
        binding.txtAmount.setText("₹ "+item.getTotalCollection());
        if(!item.getStatus().equals("pending")){
            binding.txtStatus.setTextColor(ContextCompat.getColor(context,R.color.textColor));
        }else {
            binding.txtStatus.setTextColor(ContextCompat.getColor(context,R.color.textRed));
        }
        holder.itemView.setOnClickListener(v -> {
            onItemClickListener.onItemClick(position);
        });

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemTripBinding binding;

        public ViewHolder(ItemTripBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}