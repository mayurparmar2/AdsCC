
package app.admin.driver.Network.TripsResponse;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TripDetails {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("driver_id")
    @Expose
    private String driverId;
    @SerializedName("vendor_name")
    @Expose
    private String vendorName;
    @SerializedName("customer_name")
    @Expose
    private String customerName;
    @SerializedName("customer_mobile")
    @Expose
    private String customerMobile;
    @SerializedName("pickup_location")
    @Expose
    private String pickupLocation;
    @SerializedName("drop_location")
    @Expose
    private String dropLocation;
    @SerializedName("date_time")
    @Expose
    private String dateTime;
    @SerializedName("vehicle_name")
    @Expose
    private String vehicleName;
    @SerializedName("total_collection")
    @Expose
    private String totalCollection;
    @SerializedName("advance_paid")
    @Expose
    private String advancePaid;
    @SerializedName("commission")
    @Expose
    private String commission;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("updated_at")
    @Expose
    private String updatedAt;
    @SerializedName("driver_name")
    @Expose
    private String driverName;
    @SerializedName("driver_phone")
    @Expose
    private String driverPhone;
    @SerializedName("totalGasAmount")
    @Expose
    private Integer totalGasAmount;
    @SerializedName("totalPuncherAmount")
    @Expose
    private Integer totalPuncherAmount;
    @SerializedName("totalParkingAmount")
    @Expose
    private Integer totalParkingAmount;
    @SerializedName("totalPoliceChargeAmount")
    @Expose
    private Integer totalPoliceChargeAmount;
    @SerializedName("totalTallTaxAmount")
    @Expose
    private Integer totalTallTaxAmount;
    @SerializedName("totalOtherAmount")
    @Expose
    private Integer totalOtherAmount;
    @SerializedName("gasData")
    @Expose
    private List<GasData> gasData;
    @SerializedName("puncherData")
    @Expose
    private List<PuncherData> puncherData;
    @SerializedName("parkingData")
    @Expose
    private List<ParkingData> parkingData;
    @SerializedName("policeChargeData")
    @Expose
    private List<PoliceChargeData> policeChargeData;
    @SerializedName("tallTaxData")
    @Expose
    private List<TallTaxData> tallTaxData;

    @SerializedName("otherData")
    @Expose
    private List<OtherData> otherData;

    @SerializedName("receivedCollection")
    @Expose
    private List<ReceivedCollectionData> receivedCollection;

    @SerializedName("tripNotes")
    @Expose
    private List<TripNoteData> tripNotes;

    @SerializedName("trip_id")
    @Expose
    private String tripId;


    @SerializedName("totalPL")
    @Expose
    private String totalPL;


    @SerializedName("cost")
    @Expose
    private String cost;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerMobile() {
        return customerMobile;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getDropLocation() {
        return dropLocation;
    }

    public void setDropLocation(String dropLocation) {
        this.dropLocation = dropLocation;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }

    public String getTotalCollection() {
        return totalCollection;
    }

    public void setTotalCollection(String totalCollection) {
        this.totalCollection = totalCollection;
    }

    public String getAdvancePaid() {
        return advancePaid;
    }

    public void setAdvancePaid(String advancePaid) {
        this.advancePaid = advancePaid;
    }

    public String getCommission() {
        return commission;
    }

    public void setCommission(String commission) {
        this.commission = commission;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDriverPhone() {
        return driverPhone;
    }

    public void setDriverPhone(String driverPhone) {
        this.driverPhone = driverPhone;
    }

    public Integer getTotalGasAmount() {
        return totalGasAmount;
    }

    public void setTotalGasAmount(Integer totalGasAmount) {
        this.totalGasAmount = totalGasAmount;
    }

    public Integer getTotalPuncherAmount() {
        return totalPuncherAmount;
    }

    public void setTotalPuncherAmount(Integer totalPuncherAmount) {
        this.totalPuncherAmount = totalPuncherAmount;
    }

    public Integer getTotalParkingAmount() {
        return totalParkingAmount;
    }

    public void setTotalParkingAmount(Integer totalParkingAmount) {
        this.totalParkingAmount = totalParkingAmount;
    }

    public Integer getTotalPoliceChargeAmount() {
        return totalPoliceChargeAmount;
    }

    public void setTotalPoliceChargeAmount(Integer totalPoliceChargeAmount) {
        this.totalPoliceChargeAmount = totalPoliceChargeAmount;
    }

    public Integer getTotalTallTaxAmount() {
        return totalTallTaxAmount;
    }

    public void setTotalTallTaxAmount(Integer totalTallTaxAmount) {
        this.totalTallTaxAmount = totalTallTaxAmount;
    }

    public Integer getTotalOtherAmount() {
        return totalOtherAmount;
    }

    public void setTotalOtherAmount(Integer totalOtherAmount) {
        this.totalOtherAmount = totalOtherAmount;
    }

    public List<GasData> getGasData() {
        return gasData;
    }

    public void setGasData(List<GasData> gasData) {
        this.gasData = gasData;
    }

    public List<PuncherData> getPuncherData() {
        return puncherData;
    }

    public void setPuncherData(List<PuncherData> puncherData) {
        this.puncherData = puncherData;
    }

    public List<ParkingData> getParkingData() {
        return parkingData;
    }

    public void setParkingData(List<ParkingData> parkingData) {
        this.parkingData = parkingData;
    }

    public List<PoliceChargeData> getPoliceChargeData() {
        return policeChargeData;
    }

    public void setPoliceChargeData(List<PoliceChargeData> policeChargeData) {
        this.policeChargeData = policeChargeData;
    }

    public List<TallTaxData> getTallTaxData() {
        return tallTaxData;
    }

    public void setTallTaxData(List<TallTaxData> tallTaxData) {
        this.tallTaxData = tallTaxData;
    }

    public List<OtherData> getOtherData() {
        return otherData;
    }

    public void setOtherData(List<OtherData> otherData) {
        this.otherData = otherData;
    }

    public List<ReceivedCollectionData> getReceivedCollection() {
        return receivedCollection;
    }

    public void setReceivedCollection(List<ReceivedCollectionData> receivedCollection) {
        this.receivedCollection = receivedCollection;
    }

    public List<TripNoteData> getTripNotes() {
        return tripNotes;
    }

    public void setTripNotes(List<TripNoteData> tripNotes) {
        this.tripNotes = tripNotes;
    }

    public String getTripId() {
        return tripId;
    }

    public void setTripId(String tripId) {
        this.tripId = tripId;
    }

    public String getTotalPL() {
        return totalPL;
    }

    public void setTotalPL(String totalPL) {
        this.totalPL = totalPL;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }
}
