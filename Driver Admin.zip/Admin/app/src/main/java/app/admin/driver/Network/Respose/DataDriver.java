package app.admin.driver.Network.Respose;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import app.admin.driver.Model.Driver;

public class DataDriver {

    @SerializedName("data")
    @Expose
    private List<Driver> data;

    public List<Driver> getData() {
        return data;
    }

    public void setData(List<Driver> data) {
        this.data = data;
    }

}