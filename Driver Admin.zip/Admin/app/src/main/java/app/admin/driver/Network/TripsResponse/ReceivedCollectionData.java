package app.admin.driver.Network.TripsResponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class ReceivedCollectionData {

@SerializedName("id")
@Expose
private String id;
@SerializedName("trip_id")
@Expose
private String tripId;
@SerializedName("amount")
@Expose
private String amount;
@SerializedName("payment_type")
@Expose
private String paymentType;
@SerializedName("created_at")
@Expose
private String createdAt;

public String getId() {
return id;
}

public void setId(String id) {
this.id = id;
}

public String getTripId() {
return tripId;
}

public void setTripId(String tripId) {
this.tripId = tripId;
}

public String getAmount() {
return amount;
}

public void setAmount(String amount) {
this.amount = amount;
}

public String getPaymentType() {
return paymentType;
}

public void setPaymentType(String paymentType) {
this.paymentType = paymentType;
}

public String getCreatedAt() {
return createdAt;
}

public void setCreatedAt(String createdAt) {
this.createdAt = createdAt;
}

}