package app.admin.driver.Utils;

import android.util.Patterns;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.regex.Pattern;

public class Validator {
    public static boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }

    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+$"
    );

    private boolean isValidEmail(String email) {
        String EMAIL_STRING = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        return Pattern.compile(EMAIL_STRING).matcher(email).matches();
    }


//    public static boolean isValidEmail(EditText editText) {
//        CharSequence email = editText.getText().toString().trim();
//        return (!isEmpty(editText) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
//    }


    public static boolean isValidMinLength(EditText editText, int minLength) {
        return editText.getText().toString().trim().length() >= minLength;
    }


    public static boolean isStrongPassword(EditText editText, int minLength) {
        String password = editText.getText().toString().trim();
        return password.length() >= minLength &&
                password.matches(".*[A-Z].*") &&
                password.matches(".*[a-z].*") &&
                password.matches(".*\\d.*");
    }

    public static boolean isValidSelection(Spinner spinner) {
        return spinner.getSelectedItemPosition() != 0;
    }

    public static boolean isTextValue(String input) {
        return input.matches(".*\\d.*");
    }

}
