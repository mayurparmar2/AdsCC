package app.admin.driver.Network;

import app.admin.driver.Network.Respose.LoginResponse;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {
    @FormUrlEncoded
    @POST("driver-management/Admin/Login")
    Call<LoginResponse> login(
            @Field("email") String email,
            @Field("password") String password
    );

//    @FormUrlEncoded
//    @POST("driver-management/admin/Login.php")
//    Call<LoginResponse> forgotPassword(
//            @Query("type") String type,
//            @Field("email") String email,
//            @Field("new_password") String newPassword,
//            @Field("confirm_password") String confirmPassword,
//            @Header("Content-Type") String contentType
//    );



    @FormUrlEncoded
    @POST("driver-management/Admin/Login/forgot_password")
    Call<LoginResponse> sendEmailOTP(
            @Field("email") String email
    );

//    {{BASE_URL}}Admin/Login/forgot

    @FormUrlEncoded
    @POST("driver-management/Admin/Login/forgot")
    Call<LoginResponse> forgot(
            @Field("email") String email,
            @Field("otp") int otp,
            @Field("password") String password,
            @Field("confirm_password") String confirm_password

    );
}