package app.admin.driver.Utils;

import android.content.Context;
import android.content.SharedPreferences;

public class AdminPreference {
    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    public AdminPreference(Context context) {
        preferences = context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);
        editor = preferences.edit();
    }

    public boolean isLogin() {
        return preferences.getBoolean("DC_LOGIN", false);
    }

    public void setLogin(boolean login) {
        editor.putBoolean("DC_LOGIN", login);
        editor.commit();
        editor.apply();
    }

    public void setAuthToken(String authToken) {
        editor.putString("DC_AUTHTOKEN", authToken);
        editor.commit();
        editor.apply();
    }
    public void setEmail(String email) {
        editor.putString("DC_EMAIL", email);
        editor.commit();
        editor.apply();
    }

    public String getEmail() {
        return preferences.getString("DC_EMAIL", "");
    }

    public String getAuthToken() {
        return preferences.getString("DC_AUTHTOKEN", "");
    }
}