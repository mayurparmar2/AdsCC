package app.admin.driver.Network;

import app.admin.driver.Network.TripsResponse.TripsDetailsResponse;
import app.admin.driver.Network.Respose.AddResponse;
import app.admin.driver.Network.Respose.TripsResponse;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface TripService {
    @GET("driver-management/Admin/Trip/list")
    Call<TripsResponse> getTripList();

    @GET("driver-management/Admin/Trip/TodayTripList")
    Call<TripsResponse> getTodayTripList();

    @GET("driver-management/Admin/Trip/PastTripList")
    Call<TripsResponse> getPastTripList();


    @FormUrlEncoded
    @POST("driver-management/Admin/Trip/createTrip")
    Call<AddResponse> addTrip(
//            @Field("trip_id") int tripId,
            @Field("driver_id") String driverId,
            @Field("vendor_name") String vendorId,
            @Field("customer_name") String customerName,
            @Field("customer_mobile") String customerMobile,
            @Field("pickup_location") String pickupLocation,
            @Field("drop_location") String dropLocation,
            @Field("date_time") String dateTime,
            @Field("vehicle_name") String vehicleName,
            @Field("total_collection") int totalCollection,
            @Field("advance_paid") int advancePaid,
            @Field("commission") int commission
    );

    @FormUrlEncoded
    @POST("driver-management/Admin/Trip/editTrip")
    Call<AddResponse> editTrip(
//            @Field("trip_id") int tripId,
            @Field("driver_id") String driverId,
            @Field("vendor_name") String vendorId,
            @Field("customer_name") String customerName,
            @Field("customer_mobile") String customerMobile,
            @Field("pickup_location") String pickupLocation,
            @Field("drop_location") String dropLocation,
            @Field("date_time") String dateTime,
            @Field("vehicle_name") String vehicleName,
            @Field("total_collection") int totalCollection,
            @Field("advance_paid") int advancePaid,
            @Field("commission") int commission,
            @Field("id") int tripId
    );

    @FormUrlEncoded
    @POST("driver-management/Admin/Trip/deleteTrip")
    Call<TripsDetailsResponse> deleteTrip(@Field("id") int id);




    @GET("driver-management/Admin/Trip/getTripDetails")
    Call<TripsDetailsResponse> showTripDetailsTrip(@Query("id") int id);
}
