package app.admin.driver.UI.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.List;

import app.admin.driver.Adpater.DriverAdapter;
import app.admin.driver.Adpater.ViewPagerAdapter;
import app.admin.driver.Utils.EditDriverDialog;
import app.admin.driver.Utils.Validator;
import app.admin.driver.databinding.FragmentAddDriverBinding;
import app.admin.driver.databinding.FragmentAddDriverDetailsBinding;
import app.admin.driver.databinding.FragmentDriverListBinding;
import app.admin.driver.Model.Driver;
import app.admin.driver.Network.Respose.AddResponse;
import app.admin.driver.Network.Respose.DriverResponse;
import app.admin.driver.Network.Respose.VendorResponse;
import app.admin.driver.Network.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddDriverFrag extends Fragment {
    FragmentAddDriverBinding binding;
    ViewPagerAdapter viewPagerAdapter;
    public AddDriverFragmentDetail addDriverFragmentDetail;
    public AddDriverFragmentSeeList addDriverFragmentSeeList;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAddDriverBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        addDriverFragmentDetail = new AddDriverFragmentDetail(new AddDriverFragmentDetail.onSubmitClickListener() {
            @Override
            public void onSubmitClick() {
                loadData();
                binding.DriverViewPager.setCurrentItem(1);
            }
        });
        addDriverFragmentSeeList = new AddDriverFragmentSeeList();
        viewPagerAdapter = new ViewPagerAdapter(getChildFragmentManager());
        viewPagerAdapter.addFragment(addDriverFragmentDetail, "Add Detail");
        viewPagerAdapter.addFragment(addDriverFragmentSeeList, "See List");
        loadData();
    }

    void loadData() {
        binding.DriverViewPager.setAdapter(viewPagerAdapter);
        binding.DriverTabLayout.setupWithViewPager(binding.DriverViewPager);
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}