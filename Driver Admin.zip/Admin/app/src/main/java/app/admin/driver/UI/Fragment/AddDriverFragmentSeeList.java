package app.admin.driver.UI.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.List;

import app.admin.driver.Adpater.DriverAdapter;
import app.admin.driver.Model.Driver;
import app.admin.driver.Network.Respose.DriverResponse;
import app.admin.driver.Network.Respose.VendorResponse;
import app.admin.driver.Network.RetrofitClient;
import app.admin.driver.Utils.EditDriverDialog;
import app.admin.driver.databinding.FragmentDriverListBinding;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public  class AddDriverFragmentSeeList extends Fragment {
    FragmentDriverListBinding binding;
    DriverAdapter driverAdapter;
    ArrayList<Driver> driverList;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentDriverListBinding.inflate(inflater, container, false);
        loadData();
        return binding.getRoot();
    }
    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }
    public void loadData() {
        driverList = new ArrayList<>();
        driverAdapter = new DriverAdapter(requireContext(), driverList, new DriverAdapter.OnItemClickListener() {
            @Override
            public void onDelete(String id) {
                deleteDriver(Integer.parseInt(id));
            }

            @Override
            public void onUpdate(Driver driver) {
                new EditDriverDialog(requireActivity(), driver, new EditDriverDialog.OnItemClickListener() {
                    @Override
                    public void onAddClick(Driver driver) {
//                            Log.e("MTAG", "onUpdate name:" + name + " onUpdate id:" + id);
                        editDriver(driver);
                    }
                }).show();
            }
        });
        binding.recycleView.setAdapter(driverAdapter);
        binding.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                showDriver();
            }
        });
        showDriver();
    }

    void updateAdapter(List<Driver> data) {
        if (!data.isEmpty()) {
            driverAdapter.updateList(data);
        } else {
            binding.txtNoTataFound.setVisibility(View.VISIBLE);
            binding.recycleView.setVisibility(View.GONE);
        }
    }


    private void deleteDriver(int id) {

        RetrofitClient.getDriverService(requireContext()).deleteDriver(id).enqueue(new Callback<VendorResponse>() {
            @Override
            public void onResponse(Call<VendorResponse> call, Response<VendorResponse> response) {
                if (response.isSuccessful()) {
                    VendorResponse vendorResponse = response.body();
                    Boolean error = vendorResponse.getError();
                    if (!error) {
                        Toast.makeText(requireContext(), "Delete Driver Successfully", Toast.LENGTH_SHORT).show();
                        showDriver();
                    }
                } else {
                    Log.e("delete", "delete Vendor failed");
                    Toast.makeText(requireContext(), "delete Driver failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<VendorResponse> call, Throwable t) {
                Log.e("Login", "delete Vendor error: " + t.getMessage());
                Toast.makeText(requireContext(), "delete Driver error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void editDriver(Driver driver) {
        RetrofitClient.getDriverService(requireContext()).editDriver(driver.getPhone(), driver.getName(), Integer.parseInt(driver.getId())).enqueue(new Callback<VendorResponse>() {
            @Override
            public void onResponse(Call<VendorResponse> call, Response<VendorResponse> response) {
                if (response.isSuccessful()) {
                    VendorResponse vendorResponse = response.body();
                    Boolean error = vendorResponse.getError();
                    if (!error) {
                        Toast.makeText(requireContext(), "Edit Vendor Successfully", Toast.LENGTH_SHORT).show();
                        showDriver();
                    }
                } else {
                    Log.e("AddVendor", "Edit Vendor failed");
                    Toast.makeText(requireContext(), "Edit Vendor failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<VendorResponse> call, Throwable t) {
                Log.e("Login", "Edit Vendor error: " + t.getMessage());
                Toast.makeText(requireContext(), "Edit Vendor error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    void showDriver() {
        binding.swipeContainer.setRefreshing(true);
        RetrofitClient.getDriverService(requireActivity()).getDriverList().enqueue(new Callback<DriverResponse>() {
            @Override
            public void onResponse(Call<DriverResponse> call, Response<DriverResponse> response) {
                binding.swipeContainer.setRefreshing(false);
                if (response.isSuccessful()) {
                    DriverResponse driverResponse = response.body();
                    Boolean error = driverResponse.getError();
                    if (!error) {
                        if (driverResponse.getData() != null && !driverResponse.getData().getData().isEmpty()) {
//                                driverAdapter.updateList();
                            updateAdapter(driverResponse.getData().getData());
                        } else {
                            binding.txtNoTataFound.setVisibility(View.VISIBLE);
                            binding.recycleView.setVisibility(View.GONE);
                        }
                    }
                } else {
                    binding.txtNoTataFound.setVisibility(View.VISIBLE);
                    binding.recycleView.setVisibility(View.GONE);
                    Log.e("AddDriver", "Add Driver failed");
                    Toast.makeText(requireContext(), "Add Driver failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<DriverResponse> call, Throwable t) {
                binding.swipeContainer.setRefreshing(false);

                binding.txtNoTataFound.setVisibility(View.VISIBLE);
                binding.recycleView.setVisibility(View.GONE);
                Log.e("Login", "Add Driver error: " + t.getMessage());
                Toast.makeText(requireContext(), "Add Driver error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}