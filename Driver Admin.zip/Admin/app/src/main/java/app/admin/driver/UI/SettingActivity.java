package app.admin.driver.UI;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import app.admin.driver.App;
import app.admin.driver.Utils.Utils;
import app.admin.driver.databinding.ActivitySettingBinding;

public class SettingActivity extends BaseActivity {
    ActivitySettingBinding binding;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.textUserName.setText(App.adminPreference.getEmail());
        binding.imgBack.setOnClickListener(v -> {
            finish();
        });

        binding.settingLogout.setOnClickListener(v -> {
            App.adminPreference.setLogin(false);
            App.adminPreference.setAuthToken("");
            App.adminPreference.setEmail("");
            BaseActivity.finishAllActivities();
            Utils.restartApp(getApplicationContext());
        });
        binding.addVendor.setOnClickListener(v -> {
            startActivity(new Intent(this, AddVendorActivity.class));
        });
    }
}