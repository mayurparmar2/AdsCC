package app.admin.driver.Utils;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.Window;

import androidx.annotation.NonNull;

import app.admin.driver.R;
import app.admin.driver.databinding.EditDriverDialogBinding;
import app.admin.driver.Model.Driver;

public class EditDriverDialog extends Dialog {
    private Activity activity;
    private Driver driver;
    OnItemClickListener listener;
    EditDriverDialogBinding binding;

    public interface OnItemClickListener {
        void onAddClick(Driver driver);
    }
    public EditDriverDialog(@NonNull Activity activity,Driver driver, OnItemClickListener listener) {
        super(new ContextThemeWrapper(activity, R.style.CustomDialogTheme));
        this.activity = activity;
        this.driver = driver;
        this.listener = listener;
    }

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        if (getWindow() != null) {
            getWindow().setGravity(17);
            getWindow().setBackgroundDrawableResource(17170445);
        }
        binding = EditDriverDialogBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.EtName.setText(EditDriverDialog.this.driver.getName());
//        binding.EtPassword.setText(EditDriverDialog.this.driver.getPassword());
        binding.EtPhone.setText(EditDriverDialog.this.driver.getPhone());
        binding.BtnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Validator.isEmpty(binding.EtName)) {
                    binding.EtName.setError("Please Enter Name");
                    binding.EtName.requestFocus();
                    return;
                }
                if (Validator.isEmpty(binding.EtPhone)) {
                    binding.EtPhone.setError("Please Enter Phone");
                    binding.EtPhone.requestFocus();
                    return;
                }
//                if (Validator.isEmpty(binding.EtPassword)) {
//                    binding.EtPassword.setError("Please Enter Password");
//                    binding.EtPassword.requestFocus();
//                    return;
//                }
                Driver driver =  new Driver();
                driver.setId(EditDriverDialog.this.driver.getId());
                driver.setName(binding.EtName.getText().toString());
                driver.setPhone(binding.EtPhone.getText().toString());
//                driver.setPassword(binding.EtPassword.getText().toString());
                listener.onAddClick(driver);
                dismiss();
            }
        });
    }
}