package app.admin.driver.Model;

import com.google.gson.annotations.SerializedName;
import app.admin.driver.Utils.Utils;

public class Trips {

    @SerializedName("id")
    String id;

    @SerializedName("driver_id")
    private String driverId;
    @SerializedName("vendor_name")
    private String vendorName;
    @SerializedName("customer_name")
    private String customerName;
    @SerializedName("customer_mobile")
    private String customerMobile;
    @SerializedName("pickup_location")
    private String pickupLocation;
    @SerializedName("drop_location")
    private String dropLocation;
    @SerializedName("date_time")
    private String dateTime;
    @SerializedName("vehicle_name")
    private String vehicleName;
    @SerializedName("total_collection")
    private String totalCollection;
    @SerializedName("advance_paid")
    private String advancePaid;
    @SerializedName("commission")
    private String commission;
    @SerializedName("status")
    private String status;
    @SerializedName("created_at")
    private String createdAt;
    @SerializedName("updated_at")
    private String updatedAt;

    @SerializedName("driver_name")
    private String driver_name;

    @SerializedName("trip_id")
    private String trip_id;


    public Trips(String driverId, String vendorName, String customerName, String customerMobile, String pickupLocation, String dropLocation, String dateTime, String vehicleName, String totalCollection, String advancePaid, String commission, String status, String createdAt, String updatedAt) {
        this.driverId = driverId;
        this.vendorName = vendorName;
        this.customerName = customerName;
        this.customerMobile = customerMobile;
        this.pickupLocation = pickupLocation;
        this.dropLocation = dropLocation;
        this.dateTime = dateTime;
        this.vehicleName = vehicleName;
        this.totalCollection = totalCollection;
        this.advancePaid = advancePaid;
        this.commission = commission;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public String getTrip_id() {
        return trip_id;
    }

    public void setTrip_id(String trip_id) {
        this.trip_id = trip_id;
    }


    public String getDriver_name() {
        return driver_name;
    }

    public void setDriver_name(String driver_name) {
        this.driver_name = driver_name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerMobile() {
        return customerMobile;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getDropLocation() {
        return dropLocation;
    }

    public void setDropLocation(String dropLocation) {
        this.dropLocation = dropLocation;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }

    public String getTotalCollection() {
        return totalCollection;
    }

    public void setTotalCollection(String totalCollection) {
        this.totalCollection = totalCollection;
    }

    public String getAdvancePaid() {
        return advancePaid;
    }

    public void setAdvancePaid(String advancePaid) {
        this.advancePaid = advancePaid;
    }

    public String getCommission() {
        return commission;
    }

    public void setCommission(String commission) {
        this.commission = commission;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getTime() {
        return Utils.getTime(dateTime);
    }

    public String getDate() {
        return Utils.getDate(dateTime);
    }


}