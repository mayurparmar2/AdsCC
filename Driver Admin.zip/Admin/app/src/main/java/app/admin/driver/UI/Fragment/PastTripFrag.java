package app.admin.driver.UI.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import app.admin.driver.UI.ViewTripActivity;
import app.admin.driver.Adpater.TripAdapter;
import app.admin.driver.Utils.AdminPreference;
import app.admin.driver.databinding.FragmentPastTripBinding;
import app.admin.driver.Model.Trips;
import app.admin.driver.Network.Respose.TripsResponse;
import app.admin.driver.Network.RetrofitClient;
import app.admin.driver.Network.TripService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PastTripFrag extends Fragment {
    FragmentPastTripBinding binding;
    TripAdapter PastTripAdapter;
    TripService tripService;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentPastTripBinding.inflate(inflater, container, false);
        tripService = RetrofitClient.getClient(new AdminPreference(requireContext()).getAuthToken()).create(TripService.class);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ArrayList<Trips> list = new ArrayList<>();
        PastTripAdapter = new TripAdapter(requireContext(), true, list, position -> {
            Intent intent = new Intent(requireContext(), ViewTripActivity.class);
            intent.putExtra("id", list.get(position).getId());
            startActivity(intent);
        });
        binding.recycleView.setAdapter(PastTripAdapter);

        binding.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                showPastTrip();
            }
        });
    }


    @Override
    public void onResume() {
        super.onResume();
        showPastTrip();
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    private void showPastTrip() {
        binding.swipeContainer.setRefreshing(true);
        tripService.getPastTripList().enqueue(new Callback<TripsResponse>() {
            @Override
            public void onResponse(Call<TripsResponse> call, Response<TripsResponse> response) {
                binding.swipeContainer.setRefreshing(false);
                if (response.isSuccessful()) {
                    TripsResponse tripsResponse = response.body();
                    Boolean error = tripsResponse.getError();
                    if (!error) {
                        if (tripsResponse.getData() != null && !tripsResponse.getData().getData().isEmpty()) {
                            Log.e("AddDriver", "Add PastTrip tripsResponse: " + tripsResponse.getData().getData().size());
                            updateAdapter(tripsResponse.getData().getData());
                        } else {
                            binding.recycleView.setVisibility(View.INVISIBLE);
                            binding.txtNoTataFound.setVisibility(View.VISIBLE);
                        }
                    }
                } else {
                    binding.txtNoTataFound.setVisibility(View.VISIBLE);
                    binding.recycleView.setVisibility(View.INVISIBLE);

                    Log.e("AddDriver", "Add PastTrip failed");
                    Toast.makeText(requireContext(), "Add PastTrip failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TripsResponse> call, Throwable t) {
                binding.swipeContainer.setRefreshing(false);

                binding.txtNoTataFound.setVisibility(View.VISIBLE);
                binding.recycleView.setVisibility(View.GONE);

                Log.e("Login", "Add PastTrip error: " + t.getMessage());
                Toast.makeText(requireContext(), "Add PastTrip error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    void updateAdapter(List<Trips> data) {
        if (!data.isEmpty()) {
            PastTripAdapter.updateList(data);
        } else {
            binding.txtNoTataFound.setVisibility(View.VISIBLE);
            binding.recycleView.setVisibility(View.GONE);
        }
    }


}