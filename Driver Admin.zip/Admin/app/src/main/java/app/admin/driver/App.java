package app.admin.driver;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import app.admin.driver.Utils.AdminPreference;

public class App extends Application {
    public static NetworkManager networkManager;
    private final String TAG = "App";
    public static AdminPreference adminPreference;
    @Override
    public void onCreate() {
        super.onCreate();
        adminPreference = new AdminPreference(getApplicationContext());
        networkManager = NetworkManager.getInstance(this);
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}

            @Override
            public void onActivityStarted(Activity activity) {}

            @Override
            public void onActivityResumed(Activity activity) {
                networkManager.setCurrentActivity(activity);
            }

            @Override
            public void onActivityPaused(Activity activity) {
                networkManager.setCurrentActivity(null);
            }

            @Override
            public void onActivityStopped(Activity activity) {}

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

            @Override
            public void onActivityDestroyed(Activity activity) {}
        });

    }


    @SuppressLint("ResourceType")
    public static void showExitDialog(final Activity activity) {
        final Dialog customDialog = new Dialog(activity);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (customDialog.getWindow() != null) {
            customDialog.getWindow().setGravity(17);
            customDialog.getWindow().setBackgroundDrawableResource(17170445);
        }
        customDialog.setContentView(R.layout.dialog_exit);
        customDialog.setCanceledOnTouchOutside(false);
        customDialog.setCancelable(false);
        customDialog.findViewById(R.id.btnNo).setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                customDialog.dismiss();
            }
        });
        customDialog.findViewById(R.id.btnExit).setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                customDialog.dismiss();
                activity.finishAffinity();
            }
        });
        customDialog.show();
    }
}
