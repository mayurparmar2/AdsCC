package app.admin.driver.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import app.admin.driver.databinding.ItemVendorBinding;
import app.admin.driver.Model.Vendor;

public class VendorAdapter extends RecyclerView.Adapter<VendorAdapter.ViewHolder> {
    private final String TAG = DriverAdapter.class.getSimpleName();
    private Context context;
    private List<Vendor> list;
    private OnItemClickListener onItemClickListener;



    public void updateList(List<Vendor> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();

    }

    public interface OnItemClickListener {
        void onDelete(String id);
        void onUpdate(String id,String name);
    }

    public VendorAdapter(Context context, List<Vendor> list, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public VendorAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemVendorBinding binding = ItemVendorBinding.inflate(LayoutInflater.from(context), parent, false);
        return new VendorAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(VendorAdapter.ViewHolder holder, int position) {
        ItemVendorBinding binding = holder.binding;
        Vendor item = list.get(position);


        binding.txtName.setText(item.getName());
        holder.binding.edit.setOnClickListener(v -> {
            onItemClickListener.onUpdate(item.getId(),item.getName());
        });
        holder.binding.delete.setOnClickListener(v -> {
            onItemClickListener.onDelete(item.getId());
        });
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemVendorBinding binding;

        public ViewHolder(ItemVendorBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}