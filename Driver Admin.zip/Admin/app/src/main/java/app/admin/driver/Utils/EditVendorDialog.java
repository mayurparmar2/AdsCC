package app.admin.driver.Utils;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.Window;

import androidx.annotation.NonNull;

import app.admin.driver.R;
import app.admin.driver.databinding.EditVendorDialogBinding;

public class EditVendorDialog extends Dialog {
    private final String name;
    private Activity activity;
    OnItemClickListener listener;
    EditVendorDialogBinding binding;

    public interface OnItemClickListener {
        void onAddClick(String name);
    }
    public EditVendorDialog(@NonNull Activity activity, String name, OnItemClickListener listener) {
        super(new ContextThemeWrapper(activity, R.style.CustomDialogTheme));
        this.activity = activity;
        this.name = name;
        this.listener = listener;
    }

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        if (getWindow() != null) {
            getWindow().setGravity(17);
            getWindow().setBackgroundDrawableResource(17170445);
        }
        binding = EditVendorDialogBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.etName.setText(name);

        binding.BtnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Validator.isEmpty(binding.etName)) {
                    binding.etName.setError("Please Enter Name");
                    binding.etName.requestFocus();
                    return;
                }
                dismiss();
                listener.onAddClick(binding.etName.getText().toString());
            }
        });
    }
}