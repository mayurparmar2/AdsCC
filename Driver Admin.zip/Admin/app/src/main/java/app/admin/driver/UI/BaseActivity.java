package app.admin.driver.UI;
import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.kaopiz.kprogresshud.KProgressHUD;

import java.util.ArrayList;
import java.util.List;
public class BaseActivity extends AppCompatActivity {
    private static List<Activity> activities = new ArrayList<>();
    KProgressHUD progressHUD;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activities.add(this);
        progressHUD = KProgressHUD.create(BaseActivity.this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please wait")
//                .setDetailsLabel("Downloading data")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        activities.remove(this);
    }
    public static void finishAllActivities() {
        for (Activity activity : activities) {
            activity.finish();
        }
        activities.clear();
    }
}