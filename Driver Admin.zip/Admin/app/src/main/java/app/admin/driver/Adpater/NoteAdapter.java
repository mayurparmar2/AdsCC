package app.admin.driver.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import app.admin.driver.Network.TripsResponse.TallTaxData;
import app.admin.driver.Network.TripsResponse.TripNoteData;
import app.admin.driver.UI.ViewTripActivity;
import app.admin.driver.Utils.Utils;
import app.admin.driver.databinding.ItemTripListBinding;
import app.admin.driver.databinding.ItemTripNoteBinding;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.ViewHolder>{
    private final String TAG = "NoteAdapter";
    private Context context;
    private List<TripNoteData> list;
    private OnItemClickListener onItemClickListener;

    public NoteAdapter(Context context, List<TripNoteData> tripNotes, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.list = tripNotes;
        this.onItemClickListener = onItemClickListener;
    }



    public void updateList(List<TripNoteData> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }


    @Override
    public NoteAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemTripNoteBinding binding = ItemTripNoteBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(NoteAdapter.ViewHolder holder, int position) {
        ItemTripNoteBinding binding = holder.binding;
        TripNoteData item = list.get(position);

        binding.textNotes.setText(item.getNotes());

        holder.itemView.setOnClickListener(v -> {
            onItemClickListener.onItemClick(position);
        });
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemTripNoteBinding binding;
        public ViewHolder(ItemTripNoteBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}
