package app.admin.driver.Network;

import app.admin.driver.Network.Respose.AddResponse;
import app.admin.driver.Network.Respose.DriverResponse;
import app.admin.driver.Network.Respose.VendorResponse;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface  DriverService {

    @FormUrlEncoded
    @POST("driver-management/Admin/Driver/adddriver")
    Call<AddResponse> addDriver(
            @Field("phone") String phone,
            @Field("password") String password,
            @Field("name") String name
    );

    @GET("driver-management/Admin/Driver/list")
    Call<DriverResponse> getDriverList();

    @FormUrlEncoded
    @POST("driver-management/Admin/Driver/editdriver")
    Call<VendorResponse> editDriver(
            @Field("phone") String phone,
//            @Field("password") String password,
            @Field("name") String name,
            @Field("id") int id
    );

    @FormUrlEncoded
    @POST("driver-management/Admin/Driver/deleteDriver")
    Call<VendorResponse> deleteDriver(
            @Field("id") int id
    );

}