
package app.admin.driver.Network.TripsResponse;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("data")
    @Expose
    private List<TripDetails> data;

    public List<TripDetails> getData() {
        return data;
    }

    public void setData(List<TripDetails> data) {
        this.data = data;
    }

}
