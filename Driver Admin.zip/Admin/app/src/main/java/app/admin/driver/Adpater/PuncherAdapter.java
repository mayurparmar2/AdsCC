package app.admin.driver.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import app.admin.driver.Utils.Utils;
import app.admin.driver.databinding.ItemGasBinding;
import app.admin.driver.Network.TripsResponse.PuncherData;

public class PuncherAdapter extends RecyclerView.Adapter<PuncherAdapter.ViewHolder> {
    private final String TAG = PuncherAdapter.class.getSimpleName();
    private Context context;
    private List<PuncherData> list;
    private OnItemClickListener onItemClickListener;


    public void updateList(List<PuncherData> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public PuncherAdapter(Context context, List<PuncherData> list, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemGasBinding binding = ItemGasBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ItemGasBinding binding = holder.binding;
        PuncherData item = list.get(position);
        binding.amount.setText(item.getAmount());

        binding.time.setText(Utils.getDateTimeWeek(item.getCreatedAt()));

        if (item.getPaymentType().equals("0")) {
            binding.paymentType.setText("Cash");
        } else {
            binding.paymentType.setText("Online");
        }
        ImageView[] imageViews = new ImageView[]{binding.img1, binding.img2, binding.img3};
        for (int i = 0; i < item.getImage().size(); i++) {
            if (i == 0) {
                Glide.with(context)
                        .load(item.getImage().get(i))
                        .into(binding.img1);
                binding.img1.setOnClickListener(v -> {
                    Utils.showImageDialog(context, item.getImage().get(0));
                });
            } else if (i == 1) {
                Glide.with(context)
                        .load(item.getImage().get(i))
                        .into(binding.img2);
                binding.img2.setOnClickListener(v -> {
                    Utils.showImageDialog(context, item.getImage().get(1));
                });
            } else {
                Glide.with(context)
                        .load(item.getImage().get(i))
                        .into(binding.img3);
                binding.img3.setOnClickListener(v -> {
                    Utils.showImageDialog(context, item.getImage().get(2));
                });
            }

        }

        holder.itemView.setOnClickListener(v -> {
            onItemClickListener.onItemClick(position);
        });
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemGasBinding binding;

        public ViewHolder(ItemGasBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}