package app.admin.driver.Network.Respose;

import com.google.gson.annotations.SerializedName;


import com.google.gson.annotations.Expose;

import javax.annotation.processing.Generated;

import app.admin.driver.Model.LoginData;

@Generated("jsonschema2pojo")
public class LoginResponse {

    @SerializedName("error")
    @Expose
    private Boolean error;
    @SerializedName("data")
    @Expose
    private LoginData data;
    @SerializedName("msg")
    @Expose
    private String msg;

    public Boolean getError() {
        return error;
    }

    public void setError(Boolean error) {
        this.error = error;
    }

    public LoginData getData() {
        return data;
    }

    public void setData(LoginData data) {
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
