package app.admin.driver.UI;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import app.admin.driver.App;
import app.admin.driver.UI.Fragment.AddDriverFrag;
import app.admin.driver.UI.Fragment.CreateTripFrag;
import app.admin.driver.UI.Fragment.PastTripFrag;
import app.admin.driver.UI.Fragment.TodaysTripFrag;
import app.admin.driver.R;
import app.admin.driver.Utils.AdminPreference;
import app.admin.driver.databinding.ActivityHomeBinding;
import app.admin.driver.Network.RetrofitClient;
import app.admin.driver.Network.TripService;

public class HomeActivity extends BaseActivity {
    ActivityHomeBinding binding;
    TripService tripService;
    public static HomeActivity homeActivity;

    TodaysTripFrag todaysTripFrag;
    PastTripFrag pastTripFrag;
    CreateTripFrag createTripFrag;
    AddDriverFrag addDriverFrag;
    public static HomeActivity activity;

    public static HomeActivity getInstance() {
        return homeActivity;
    }


    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        homeActivity = this;
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        tripService = RetrofitClient.getClient(new AdminPreference(this).getAuthToken()).create(TripService.class);


        setContentView(binding.getRoot());

        binding.btnSetting.setOnClickListener(v -> {
            startActivity(new Intent(this, SettingActivity.class));
        });
        activity = this;



        binding.viewPager.setAdapter(new ScreenSlidePagerAdapter(this));
        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                binding.bottomNavigationView.getMenu().getItem(position).setChecked(true);
            }
        });

        binding.bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.todayTripMenu) {

                binding.viewPager.setCurrentItem(0);
                return true;
            } else if (item.getItemId() == R.id.pastTripMenu) {
                binding.viewPager.setCurrentItem(1);
                return true;
            } else if (item.getItemId() == R.id.createTripMenu) {
                binding.viewPager.setCurrentItem(2);
                return true;
            } else if (item.getItemId() == R.id.addDriverTripMenu) {
                binding.viewPager.setCurrentItem(3);
                return true;
            } else {
                return false;
            }
        });
    }


    private class ScreenSlidePagerAdapter extends FragmentStateAdapter {
        public ScreenSlidePagerAdapter(@NonNull AppCompatActivity fragmentActivity) {
            super(fragmentActivity);
        }
        @NonNull
        @Override
        public Fragment createFragment(int position) {
            if (position == 0) {
                return new TodaysTripFrag();
            } else if (position == 1) {
                return new PastTripFrag();
            } else if (position == 2) {
                return new CreateTripFrag();
            } else if (position == 3) {
                return new AddDriverFrag();
            } else {
                return new TodaysTripFrag();
            }
        }

        @Override
        public int getItemCount() {
            return 4;
        }
    }

    public ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Log.e("MTAG", "onActivityResult :" + result);
                    binding.bottomNavigationView.setSelectedItemId(R.id.todayTripMenu);
                }
            }
    );

    @Override
    public void onBackPressed() {
        App.showExitDialog(this);
    }


}