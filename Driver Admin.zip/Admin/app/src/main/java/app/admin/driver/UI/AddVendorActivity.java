package app.admin.driver.UI;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.List;

import app.admin.driver.Adpater.VendorAdapter;
import app.admin.driver.Adpater.ViewPagerAdapter;
import app.admin.driver.UI.Fragment.AddVendorFragmentDetail;
import app.admin.driver.UI.Fragment.AddVendorFragmentSeeList;
import app.admin.driver.Utils.EditVendorDialog;
import app.admin.driver.Utils.Validator;
import app.admin.driver.databinding.ActivityAddVendorBinding;
import app.admin.driver.databinding.FragmentAddVendorDetailsBinding;
import app.admin.driver.databinding.FragmentVendorListBinding;
import app.admin.driver.Model.Vendor;
import app.admin.driver.Network.Respose.AddResponse;
import app.admin.driver.Network.Respose.VendorResponse;
import app.admin.driver.Network.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddVendorActivity extends BaseActivity {
    ActivityAddVendorBinding binding;
    ViewPagerAdapter viewPagerAdapter;
    public static AddVendorFragmentDetail fragmentDetail;
    public static AddVendorFragmentSeeList fragmentSeeList;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddVendorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.imgBack.setOnClickListener(v -> {
            finish();
        });

        fragmentDetail = new AddVendorFragmentDetail(new AddVendorFragmentDetail.OnSubmitClickListener() {
            @Override
            public void onSubmitClick() {
                loadData();
                binding.VendorViewPager.setCurrentItem(1);

            }
        });
        fragmentSeeList = new AddVendorFragmentSeeList();

        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragment(fragmentDetail, "Add Detail");
        viewPagerAdapter.addFragment(fragmentSeeList, "See List");
        loadData();

    }

    private void loadData() {
        binding.VendorViewPager.setAdapter(viewPagerAdapter);
        binding.VendorTabLayout.setupWithViewPager(binding.VendorViewPager);
    }


}