package app.admin.driver.UI;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import app.admin.driver.Adpater.GasAdapter;
import app.admin.driver.Adpater.NoteAdapter;
import app.admin.driver.Adpater.OthersAdapter;
import app.admin.driver.Adpater.PoliceAdapter;
import app.admin.driver.Adpater.PuncherAdapter;
import app.admin.driver.Adpater.ParkingAdapter;
import app.admin.driver.Adpater.TallTaxAdapter;
import app.admin.driver.Network.TripsResponse.TripNoteData;
import app.admin.driver.R;
import app.admin.driver.Utils.AdminPreference;
import app.admin.driver.Utils.Utils;
import app.admin.driver.databinding.ActivityViewTripBinding;
import app.admin.driver.Network.TripsResponse.TripDetails;
import app.admin.driver.Network.TripsResponse.TripsDetailsResponse;
import app.admin.driver.Network.RetrofitClient;
import app.admin.driver.Network.TripService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import androidx.appcompat.widget.Toolbar;

import com.google.gson.Gson;

public class ViewTripActivity extends BaseActivity {
    ActivityViewTripBinding binding;
    TripService tripService;
    TripDetails trip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewTripBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        binding.imgBack.setOnClickListener(v -> {
            onBackPressed();
        });

        tripService = RetrofitClient.getClient(new AdminPreference(this).getAuthToken()).create(TripService.class);
        String position = getIntent().getStringExtra("id");
        if (!position.isEmpty()) {
            showTripDetailsTrip(Integer.parseInt(position));
        }
    }

    private void showTripDetailsTrip(int position) {
        tripService.showTripDetailsTrip(position).enqueue(new Callback<TripsDetailsResponse>() {
            @Override
            public void onResponse(Call<TripsDetailsResponse> call, Response<TripsDetailsResponse> response) {
                if (response.isSuccessful()) {
                    TripsDetailsResponse tripsResponse = response.body();
                    Boolean error = tripsResponse.getError();
                    if (!error) {
                        if (tripsResponse.getData() != null && !tripsResponse.getData().getData().isEmpty()) {



                            trip = tripsResponse.getData().getData().get(0);

                            if(trip.getStatus().equals("completed")){
                                binding.toolbar.getMenu().getItem(0).setVisible(false);
                            }
                            binding.txtId.setText("ID:" + trip.getId());
                            binding.txtVendor.setText(trip.getVendorName());
                            binding.txtName.setText(trip.getDriverName());
                            binding.txtAdvancePaid.setText(trip.getAdvancePaid());
                            binding.txtCutomerMobile.setText(trip.getCustomerMobile());
                            binding.txtCutomerName.setText(trip.getCustomerName());
                            binding.txtPickupLocation.setText(trip.getPickupLocation());
                            binding.txtDropLocation.setText(trip.getDropLocation());

                            SimpleDateFormat originalFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.ENGLISH);

                            binding.txtDateTime.setText(Utils.getDateTimeWeek(trip.getDateTime(), originalFormat));
                            binding.txtVehicleName.setText(trip.getVehicleName());
                            binding.txtTotalCollection.setText(trip.getTotalCollection());
                            binding.txtCommission.setText(trip.getCommission());
                            binding.txtTotalPL.setText(trip.getTotalPL());
                            binding.txtCost.setText(trip.getCost());


                            GasAdapter gasAdapter = new GasAdapter(ViewTripActivity.this, trip.getGasData(), position1 -> {
                            });
                            binding.rVGas.setAdapter(gasAdapter);

                            PuncherAdapter puncherAdapter = new PuncherAdapter(ViewTripActivity.this, trip.getPuncherData(), position1 -> {
                            });
                            binding.rVPuncher.setAdapter(puncherAdapter);

                            ParkingAdapter parkingChargeAdapter = new ParkingAdapter(ViewTripActivity.this, trip.getParkingData(), position1 -> {
                            });
                            binding.rVParking.setAdapter(parkingChargeAdapter);

                            PoliceAdapter policeChargeAdapter = new PoliceAdapter(ViewTripActivity.this, trip.getPoliceChargeData(), position1 -> {
                            });
                            binding.rVPolice.setAdapter(policeChargeAdapter);


                            TallTaxAdapter tollTaxChargeAdapter = new TallTaxAdapter(ViewTripActivity.this, trip.getTallTaxData(), position1 -> {
                            });
                            binding.rVTollTax.setAdapter(tollTaxChargeAdapter);

                            OthersAdapter othersChargeAdapter = new OthersAdapter(ViewTripActivity.this, trip.getOtherData(), position1 -> {
                            });
                            binding.rVOthers.setAdapter(othersChargeAdapter);



                            if(trip.getTripNotes()!=null && !trip.getTripNotes().isEmpty()){
//                                List<TripNoteData> list = new ArrayList<>();

                                NoteAdapter noteAdapter = new NoteAdapter(ViewTripActivity.this, trip.getTripNotes(), position1 -> {
                                });
                                binding.rVNote.setAdapter(noteAdapter);
                            }
                        }
                    }
                } else {

                    Log.e("AddDriver", "TripDetails failed");
                    Toast.makeText(ViewTripActivity.this, "TripDetails failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TripsDetailsResponse> call, Throwable t) {

                Log.e("Login", "TripDetails error: " + t.getMessage());
                Toast.makeText(ViewTripActivity.this, "TripDetails error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.btnDelete) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Do you want to delete this item?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    // User clicked Yes button
                    deleteItem();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    // User clicked No button
                    dialog.dismiss();
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
            return true;
        }
        else if (id == R.id.btnEdite) {
            Gson gson = new Gson();
            String tripString = gson.toJson(trip);

            Intent intent = new Intent(this, UpdateTripActivity.class);
            intent.putExtra("model",  tripString);
            activityResultLauncher.launch(intent);
//            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Log.e("MTAG", "onActivityResult :" + result);
                    showTripDetailsTrip(Integer.parseInt(trip.getId()));
                }
            }
    );




    private void deleteItem() {
        tripService.deleteTrip(Integer.parseInt(trip.getId())).enqueue(new Callback<TripsDetailsResponse>() {
            @Override
            public void onResponse(Call<TripsDetailsResponse> call, Response<TripsDetailsResponse> response) {
                if (response.isSuccessful()) {
                    TripsDetailsResponse tripsResponse = response.body();
                    Boolean error = tripsResponse.getError();
                    if (!error) {
                        Toast.makeText(ViewTripActivity.this, "Delete Trip Successful", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                } else {

                    Log.e("AddDriver", "deleteItem failed");
                    Toast.makeText(ViewTripActivity.this, "Delete Trip failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TripsDetailsResponse> call, Throwable t) {

                Log.e("Login", "deleteItem error: " + t.getMessage());
                Toast.makeText(ViewTripActivity.this, "Delete Trip error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}