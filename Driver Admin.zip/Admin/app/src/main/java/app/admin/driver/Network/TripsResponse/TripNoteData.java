package app.admin.driver.Network.TripsResponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import javax.annotation.processing.Generated;

public class TripNoteData {

@SerializedName("id")
@Expose
private String id;
@SerializedName("trip_id")
@Expose
private String tripId;
@SerializedName("notes")
@Expose
private String notes;
@SerializedName("created_at")
@Expose
private String createdAt;

public String getId() {
return id;
}

public void setId(String id) {
this.id = id;
}

public String getTripId() {
return tripId;
}

public void setTripId(String tripId) {
this.tripId = tripId;
}

public String getNotes() {
return notes;
}

public void setNotes(String notes) {
this.notes = notes;
}

public String getCreatedAt() {
return createdAt;
}

public void setCreatedAt(String createdAt) {
this.createdAt = createdAt;
}

}