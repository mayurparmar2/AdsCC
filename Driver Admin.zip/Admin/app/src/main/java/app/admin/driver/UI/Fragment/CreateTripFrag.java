package app.admin.driver.UI.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Calendar;

import app.admin.driver.UI.CreateTripActivity;
import app.admin.driver.UI.HomeActivity;
import app.admin.driver.databinding.FragmentCreateTripBinding;

public class CreateTripFrag extends Fragment {
    FragmentCreateTripBinding binding;
    private Calendar calendar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentCreateTripBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        calendar = Calendar.getInstance();

        binding.btnCreate.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), CreateTripActivity.class);
            HomeActivity.getInstance().activityResultLauncher.launch(intent);
        });


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}