package app.admin.driver;
import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;

import app.admin.driver.databinding.DialogNoInternetBinding;

public class NetworkManager extends BroadcastReceiver {
    private static NetworkManager instance;
    private Activity currentActivity;
    private final Application application;
    private Dialog dialog;

    private NetworkManager(Application application) {
        this.application = application;
    }



    public static synchronized NetworkManager getInstance(Application application) {
        if (instance == null) {
            instance = new NetworkManager(application);
            IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
            application.registerReceiver(instance, filter);
        }
        return instance;
    }

    public void setCurrentActivity(Activity activity) {
        this.currentActivity = activity;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!isConnected(context)) {
            showNoInternetDialog(isConnect -> {

            });
        }
    }

    public static boolean isConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }
    public interface OnConnectedListener {
        void Connect(boolean isConnect);
    }

    public void showNoInternetDialog(OnConnectedListener onConnectedListener) {
        if (currentActivity != null) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (dialog == null || !dialog.isShowing()) {
                            dialog = new Dialog(currentActivity, R.style.CustomDialog95Percent);
                            dialog.setCancelable(false);
                            dialog.setCanceledOnTouchOutside(false);
                            Window window = dialog.getWindow();
                            if (window != null) {
                                window.setGravity(Gravity.CENTER);
                                window.setBackgroundDrawableResource(android.R.color.transparent);
                            }

                            DialogNoInternetBinding dialogNoInternetBinding =  DialogNoInternetBinding.inflate(currentActivity.getLayoutInflater());
                            dialog.setContentView(dialogNoInternetBinding.getRoot());

                            dialogNoInternetBinding.btnRetry.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (isConnected(currentActivity)) {
                                        onConnectedListener.Connect(true);
                                        new Handler().postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                dialog.dismiss();
                                            }
                                        },  1000);
                                    }
                                }
                            });
                            dialog.show();
                        }

                    }catch (Exception e){
                        e.printStackTrace();
                        Log.e("MTAG", "run" + e);
                    }
                }
            });
        }
    }
}
