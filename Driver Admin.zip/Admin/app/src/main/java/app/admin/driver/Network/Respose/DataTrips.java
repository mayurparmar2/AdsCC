package app.admin.driver.Network.Respose;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import app.admin.driver.Model.Trips;

public class DataTrips {

    @SerializedName("data")
    @Expose
    private List<Trips> data;

    public List<Trips> getData() {
        return data;
    }

    public void setData(List<Trips> data) {
        this.data = data;
    }

}