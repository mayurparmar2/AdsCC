package app.admin.driver.UI.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.List;

import app.admin.driver.Adpater.DriverAdapter;
import app.admin.driver.Adpater.VendorAdapter;
import app.admin.driver.Model.Driver;
import app.admin.driver.Model.Vendor;
import app.admin.driver.Network.Respose.AddResponse;
import app.admin.driver.Network.Respose.VendorResponse;
import app.admin.driver.Network.RetrofitClient;
import app.admin.driver.Utils.EditDriverDialog;
import app.admin.driver.Utils.EditVendorDialog;
import app.admin.driver.databinding.FragmentDriverListBinding;
import app.admin.driver.databinding.FragmentVendorListBinding;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddVendorFragmentSeeList extends Fragment {
    FragmentVendorListBinding binding;
    VendorAdapter driverAdapter;
    //        VendorService vendorService;
    ArrayList<Vendor> vendorArrayList;

//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        binding = FragmentVendorListBinding.inflate(inflater, container, false);
////            vendorService = RetrofitClient.getClient(new AdminPreference(requireContext()).getAuthToken()).create(VendorService.class);
//        return binding.getRoot();
//    }
//
//    @Override
//    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
//        binding.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                showVendor();
//            }
//        });
//        showVendor();
//    }



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentVendorListBinding.inflate(inflater, container, false);
        loadData();
        return binding.getRoot();
    }
    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    public void loadData() {
        vendorArrayList = new ArrayList<>();
        driverAdapter = new VendorAdapter(requireContext(), vendorArrayList, new VendorAdapter.OnItemClickListener() {
            @Override
            public void onDelete(String id) {
                deleteVendor(Integer.parseInt(id));
            }

            @Override
            public void onUpdate(String id, String EditeName) {
                new EditVendorDialog(requireActivity(), EditeName, new EditVendorDialog.OnItemClickListener() {
                    @Override
                    public void onAddClick(String name) {
                        editVendor(name, Integer.parseInt(id));
                    }
                }).show();

            }
        });
        binding.recycleView.setAdapter(driverAdapter);
        binding.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                showVendor();
            }
        });
        showVendor();
    }



    void updateAdapter(List<Vendor> data) {
        data.remove(0);
        if (!data.isEmpty()) {
            driverAdapter.updateList(data);
        } else {
            binding.txtNoTataFound.setVisibility(View.VISIBLE);
            binding.recycleView.setVisibility(View.GONE);
        }
    }

//    void updateAdapter(List<Vendor> data) {
////            vendorArrayList = new ArrayList<>();
//        driverAdapter = new VendorAdapter(requireContext(), data, new VendorAdapter.OnItemClickListener() {
//            @Override
//            public void onDelete(String id) {
//                deleteVendor(Integer.parseInt(id));
//            }
//
//            @Override
//            public void onUpdate(String id, String EditeName) {
//                new EditVendorDialog(requireActivity(), EditeName, new EditVendorDialog.OnItemClickListener() {
//                    @Override
//                    public void onAddClick(String name) {
//                        editVendor(name, Integer.parseInt(id));
//                    }
//                }).show();
//            }
//        });
//        binding.recycleView.setAdapter(driverAdapter);
//        if (!data.isEmpty()) {
//            binding.txtNoTataFound.setVisibility(View.VISIBLE);
//            binding.recycleView.setVisibility(View.GONE);
//        }
//    }


    private void deleteVendor(int id) {
        RetrofitClient.getVendorService(requireContext()).deleteVendor(id).enqueue(new Callback<VendorResponse>() {
            @Override
            public void onResponse(Call<VendorResponse> call, Response<VendorResponse> response) {
                if (response.isSuccessful()) {
                    VendorResponse vendorResponse = response.body();
                    Boolean error = vendorResponse.getError();
                    if (!error) {
                        Toast.makeText(requireContext(), "Delete Vendor Successfully", Toast.LENGTH_SHORT).show();
                        showVendor();
                    }
                } else {
                    Log.e("delete", "delete Vendor failed");
                    Toast.makeText(requireContext(), "delete Vendor failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<VendorResponse> call, Throwable t) {
                Log.e("Login", "delete Vendor error: " + t.getMessage());
                Toast.makeText(requireContext(), "delete Vendor error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void editVendor(String name,int id) {
        RetrofitClient.getVendorService(requireContext()).editVendor(name,id).enqueue(new Callback<VendorResponse>() {
            @Override
            public void onResponse(Call<VendorResponse> call, Response<VendorResponse> response) {
                if (response.isSuccessful()) {
                    VendorResponse vendorResponse = response.body();
                    Boolean error = vendorResponse.getError();
                    if (!error) {
                        Toast.makeText(requireContext(), "Edit Vendor Successfully", Toast.LENGTH_SHORT).show();
                        showVendor();
                    }
                } else {
                    Log.e("AddVendor", "Edit Vendor failed");
                    Toast.makeText(requireContext(), "Edit Vendor failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<VendorResponse> call, Throwable t) {
                Log.e("Login", "Edit Vendor error: " + t.getMessage());
                Toast.makeText(requireContext(), "Edit Vendor error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showVendor() {
        binding.swipeContainer.setRefreshing(true);
        RetrofitClient.getVendorService(requireContext()).getVendorList().enqueue(new Callback<VendorResponse>() {
            @Override
            public void onResponse(Call<VendorResponse> call, Response<VendorResponse> response) {
                binding.swipeContainer.setRefreshing(false);
                if (response.isSuccessful()) {
                    VendorResponse vendorResponse = response.body();
                    Boolean error = vendorResponse.getError();
                    if (!error) {
                        if (vendorResponse.getData() != null && !vendorResponse.getData().getData().isEmpty()) {

                            updateAdapter(vendorResponse.getData().getData());
                        }else {
                            binding.txtNoTataFound.setVisibility(View.VISIBLE);
                            binding.recycleView.setVisibility(View.GONE);
                        }
                    }
                } else {
                    binding.txtNoTataFound.setVisibility(View.VISIBLE);
                    binding.recycleView.setVisibility(View.GONE);
                    Log.e("showDriver", "Add Vendor failed");
                    Toast.makeText(requireContext(), "Add Vendor failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<VendorResponse> call, Throwable t) {
                binding.swipeContainer.setRefreshing(false);

                binding.txtNoTataFound.setVisibility(View.VISIBLE);
                binding.recycleView.setVisibility(View.GONE);
                Log.e("Login", "show Vendor error: " + t.getMessage());
                Toast.makeText(requireContext(), "show Vendor error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }





}