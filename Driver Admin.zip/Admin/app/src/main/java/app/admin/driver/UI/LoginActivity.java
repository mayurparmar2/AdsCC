package app.admin.driver.UI;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.kaopiz.kprogresshud.KProgressHUD;

import app.admin.driver.App;
import app.admin.driver.Utils.AdminPreference;
import app.admin.driver.Utils.ForgotPasswordDialog;
import app.admin.driver.Utils.Utils;
import app.admin.driver.Utils.Validator;
import app.admin.driver.databinding.ActivityLoginBinding;
import app.admin.driver.Network.ApiService;
import app.admin.driver.Network.Respose.LoginResponse;
import app.admin.driver.Network.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends BaseActivity {
    ActivityLoginBinding binding;
    ForgotPasswordDialog forgotPasswordDialog;
    AdminPreference preference;
    boolean idSendOtp = false;
    KProgressHUD progressHUD;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        progressHUD = KProgressHUD.create(this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please wait")
//                .setDetailsLabel("Downloading data")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f);

        preference = new AdminPreference(this);
        binding.forgotPassword.setOnClickListener(v -> {
            forgotPasswordDialog = new ForgotPasswordDialog(this);
            forgotPasswordDialog.show();
        });
        binding.btnLogin.setOnClickListener(v -> {
            if (Validator.isEmpty(binding.txtUserId)) {
                binding.txtUserId.setError("User Id is required");
                binding.txtUserId.requestFocus();
                return;
            }
            if (Validator.isEmpty(binding.EtPassword)) {
                binding.EtPassword.setError("Password is required");
                binding.EtPassword.requestFocus();
                return;
            }
            if (Utils.isNetworkAvailable(getApplicationContext())) {
                login(binding.txtUserId.getText().toString(), binding.EtPassword.getText().toString());
            } else {
                Utils.showNoInternetDialog(getApplicationContext());
            }
        });
    }

    private void login(String username, String password) {
        progressHUD.show();
        ApiService apiService = RetrofitClient.getClient(preference.getAuthToken()).create(ApiService.class);

        apiService.login(username, password).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                progressHUD.dismiss();
                if (response.isSuccessful()) {
                    LoginResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        if (loginResponse.getData() != null) {
                            App.adminPreference.setLogin(true);
                            App.adminPreference.setAuthToken(loginResponse.getData().getAuthToken());
                            App.adminPreference.setEmail(username);
                        }
                        Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                        finish();
                        return;
                    }
                    binding.EtPassword.requestFocus();
                    Log.e("Login", "Login successful, Token: " + loginResponse.getMsg());
                    Toast.makeText(LoginActivity.this,  loginResponse.getMsg(), Toast.LENGTH_SHORT).show();
                } else {

                    Log.e("Login", "Login failed");
                    Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                progressHUD.dismiss();
                Log.e("Login", "Login error: " + t.getMessage());
                Toast.makeText(LoginActivity.this, "Login error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }





}