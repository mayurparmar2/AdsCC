package app.admin.driver.Network;

import app.admin.driver.Network.Respose.AddResponse;
import app.admin.driver.Network.Respose.VendorResponse;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface VendorService {

    @FormUrlEncoded
    @POST("driver-management/Admin/Vendor/addvendor")
    Call<AddResponse> addVendor(
            @Field("name") String name
    );

    @GET("driver-management/Admin/Vendor/list")
    Call<VendorResponse> getVendorList();

    @FormUrlEncoded
    @POST("driver-management/Admin/Vendor/editvendor")
    Call<VendorResponse> editVendor(
            @Field("name") String name,
            @Field("id") int id
    );

    @FormUrlEncoded
    @POST("driver-management/Admin/Vendor/deleteVendor")
    Call<VendorResponse> deleteVendor(
            @Field("id") int id
    );

}