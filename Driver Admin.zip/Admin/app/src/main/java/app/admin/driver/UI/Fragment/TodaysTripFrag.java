package app.admin.driver.UI.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import app.admin.driver.UI.ViewTripActivity;
import app.admin.driver.Adpater.TripAdapter;
import app.admin.driver.Utils.AdminPreference;
import app.admin.driver.databinding.FragmentTodaysTripBinding;
import app.admin.driver.Model.Trips;
import app.admin.driver.Network.Respose.TripsResponse;
import app.admin.driver.Network.RetrofitClient;
import app.admin.driver.Network.TripService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TodaysTripFrag extends Fragment {
    FragmentTodaysTripBinding binding;
    TripAdapter todaysTripAdapater;
    TripService tripService;
    ArrayList<Trips> list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentTodaysTripBinding.inflate(inflater, container, false);
        tripService = RetrofitClient.getClient(new AdminPreference(requireContext()).getAuthToken()).create(TripService.class);

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



    }

    void loadData(){
        list = new ArrayList<>();
        todaysTripAdapater = new TripAdapter(requireContext(), false, list, position -> {
            Intent intent = new Intent(requireContext(), ViewTripActivity.class);
            intent.putExtra("id", list.get(position).getId());
            startActivity(intent);
        });
        binding.recycleView.setAdapter(todaysTripAdapater);
        binding.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                showTodaysTrip();
            }
        });
        showTodaysTrip();
    }

    public void showTodaysTrip() {
        binding.swipeContainer.setRefreshing(true);
        Call<TripsResponse> call = tripService.getTodayTripList();
        call.enqueue(new Callback<TripsResponse>() {
            @Override
            public void onResponse(Call<TripsResponse> call, Response<TripsResponse> response) {
                binding.swipeContainer.setRefreshing(false);
                if (response.isSuccessful()) {
                    TripsResponse tripsResponse = response.body();
                    Boolean error = tripsResponse.getError();
                    if (!error) {
                        if (tripsResponse.getData() != null && !tripsResponse.getData().getData().isEmpty()) {
                            updateAdapter(tripsResponse.getData().getData());
                        } else {
                            binding.recycleView.setVisibility(View.INVISIBLE);
                            binding.txtNoTataFound.setVisibility(View.VISIBLE);
                        }
                    }
                } else {
                    binding.txtNoTataFound.setVisibility(View.VISIBLE);
                    binding.recycleView.setVisibility(View.GONE);
                    Log.e("TodaysTripFrag", "show Todays  failed");
//                    Toast.makeText(requireContext(), "Show today's  failed", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<TripsResponse> call, Throwable t) {
                binding.swipeContainer.setRefreshing(false);

                binding.txtNoTataFound.setVisibility(View.VISIBLE);
                binding.recycleView.setVisibility(View.GONE);

                Log.e("Login", "show Todays error: " + t.getMessage());
//                Toast.makeText(requireContext(), "show Todays error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    void updateAdapter(List<Trips> data) {
        if (!data.isEmpty()) {
            todaysTripAdapater.updateList(data);
        } else {
            binding.txtNoTataFound.setVisibility(View.VISIBLE);
            binding.recycleView.setVisibility(View.GONE);
        }
    }
}