package app.admin.driver.Utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import app.admin.driver.R;
import app.admin.driver.UI.SplashScreenActivity;

public class Utils {
//    public static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("hh:mma ddMMM yyyy");
    public static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm a");


    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        return false;
    }

    public static void showNoInternetDialog(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(false);
        builder.setView(R.layout.dialog_no_internet);

        final AlertDialog dialog = builder.create();
        dialog.show();

        Button retryButton = dialog.findViewById(R.id.btnRetry);

        retryButton.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                if (isNetworkAvailable(context)) {
                    dialog.dismiss();
                }
            }
        });
    }


    private void showDateTimePicker(Calendar calendar, Context context) {
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        showTimePicker(calendar, context);
                    }
                }, year, month, dayOfMonth);
        datePickerDialog.show();
    }

    private void showTimePicker(Calendar calendar, Context context) {
        int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(context,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        calendar.set(Calendar.MINUTE, minute);


                        String selectedDateTime = dateTimeFormat.format(calendar.getTime());


                    }
                }, hourOfDay, minute, false);
        timePickerDialog.show();
    }

    public static boolean isToday(String dateString, String dateFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.getDefault());
        try {
            Date date = sdf.parse(dateString);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            Calendar today = Calendar.getInstance();
            return (calendar.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                    calendar.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR));
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }


    public static String getDayOfWeek(String dateStr) {
        try {

            Date date = dateTimeFormat.parse(dateStr);


            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);


            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);


            String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};


            return days[dayOfWeek - 1];

        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid date";
        }
    }


    public static String getTime(String dateStr) {
        try {
            Date now = dateTimeFormat.parse(dateStr);
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mma");
            String formattedTime = timeFormat.format(now);
            return formattedTime;
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid date";
        }
    }

    public static String getDate(String dateStr) {
        try {
            Date now = dateTimeFormat.parse(dateStr);
            SimpleDateFormat timeFormat = new SimpleDateFormat("dd/MM/yyyy");
            String formattedTime = timeFormat.format(now);
            return formattedTime;
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid date";
        }
    }

    public static String getDateTimeWeek(String inputDateString) {
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat outputDateFormat = new SimpleDateFormat("EEE, dd/MM/yyyy, hh:mm a");
        try {
            Date date = inputDateFormat.parse(inputDateString);
            return outputDateFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid date";
        }
    }

    public static String getDateTimeWeek(String inputDateString, SimpleDateFormat inputDateFormat) {
        SimpleDateFormat outputDateFormat = new SimpleDateFormat("EEE, dd/MM/yyyy, hh:mm a");
        try {
            Date date = inputDateFormat.parse(inputDateString);
            return outputDateFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid date";
        }
    }


    public static void showImageDialog(Context context, String Url) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.dialog_image, null);
        PhotoView imageView = dialogView.findViewById(R.id.dialogImageView);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(context);
        builder.setView(dialogView)
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        androidx.appcompat.app.AlertDialog dialog = builder.create();
        dialog.show();

        Glide.with(context).load(Url).into(imageView);
        // Optionally, you can set an image programmatically
    }

    public static void restartApp(Context context) {
        Intent intent = new Intent(context, SplashScreenActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
        if (context instanceof Activity) {
            ((Activity) context).finish();
        }
        System.exit(0); // Optional, to ensure the app fully restarts
    }


}
