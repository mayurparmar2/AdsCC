package app.admin.driver.Network.Respose;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import app.admin.driver.Model.Vendor;

public class DataVendor {

    @SerializedName("data")
    @Expose
    private List<Vendor> data;

    public List<Vendor> getData() {
        return data;
    }

    public void setData(List<Vendor> data) {
        this.data = data;
    }

}