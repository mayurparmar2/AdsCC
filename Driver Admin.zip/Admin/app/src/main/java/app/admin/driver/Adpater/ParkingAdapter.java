package app.admin.driver.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import app.admin.driver.Utils.Utils;
import app.admin.driver.databinding.ItemTripListBinding;
import app.admin.driver.Network.TripsResponse.ParkingData;


public class ParkingAdapter extends RecyclerView.Adapter<ParkingAdapter.ViewHolder> {
    private final String TAG = ParkingAdapter.class.getSimpleName();
    private Context context;
    private List<ParkingData> list;
    private OnItemClickListener onItemClickListener;

    public void updateList(List<ParkingData> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public ParkingAdapter(Context context, List<ParkingData> list, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemTripListBinding binding = ItemTripListBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ItemTripListBinding binding = holder.binding;
        ParkingData item = list.get(position);


        binding.textAmount.setText(item.getAmount());
        binding.textDateAndTime.setText(Utils.getDateTimeWeek(item.getCreatedAt()));


        holder.itemView.setOnClickListener(v -> {
            onItemClickListener.onItemClick(position);

        });
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemTripListBinding binding;

        public ViewHolder(ItemTripListBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}