package app.admin.driver.UI.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import app.admin.driver.Network.Respose.AddResponse;
import app.admin.driver.Network.RetrofitClient;
import app.admin.driver.Utils.Validator;
import app.admin.driver.databinding.FragmentAddDriverDetailsBinding;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public  class AddDriverFragmentDetail extends Fragment {
    FragmentAddDriverDetailsBinding binding;

    onSubmitClickListener onSubmitClickListener;
    interface onSubmitClickListener{
        void  onSubmitClick();
    }
    public AddDriverFragmentDetail(onSubmitClickListener onSubmitClickListener) {
        this.onSubmitClickListener =onSubmitClickListener;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAddDriverDetailsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        binding.btnCreate.setOnClickListener(v -> {
            if (Validator.isEmpty(binding.EtName)) {
                binding.EtName.setError("Name is required");
                binding.EtName.requestFocus();
                return;
            }
            if (Validator.isEmpty(binding.EtPhone)) {
                binding.EtPhone.setError("Phone is required");
                binding.EtPhone.requestFocus();
                return;
            }
            if (Validator.isEmpty(binding.EtPassword)) {
                binding.EtPassword.setError("Password is required");
                binding.EtPassword.requestFocus();
                return;
            }

            addDriver(
                    binding.EtPhone.getText().toString(),
                    binding.EtPassword.getText().toString(),
                    binding.EtName.getText().toString()
            );
        });
    }


    void addDriver(String phone, String password, String name) {
        Call<AddResponse> call = RetrofitClient.getDriverService(requireContext()).addDriver(phone, password, name);
        call.enqueue(new Callback<AddResponse>() {
            @Override
            public void onResponse(Call<AddResponse> call, Response<AddResponse> response) {

                if (response.isSuccessful()) {
                    AddResponse loginResponse = response.body();
                    Boolean error = loginResponse.getError();
                    if (!error) {
                        binding.EtName.getText().clear();
                        binding.EtPhone.getText().clear();
                        binding.EtPassword.getText().clear();
                        Toast.makeText(requireContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                        onSubmitClickListener.onSubmitClick();
                    }
                } else {

                    Log.e("AddDriver", "Add Driver failed");
                    Toast.makeText(requireContext(), "Add Driver failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddResponse> call, Throwable t) {


                Log.e("Login", "Add Driver error: " + t.getMessage());
                Toast.makeText(requireContext(), "Add Driver error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
