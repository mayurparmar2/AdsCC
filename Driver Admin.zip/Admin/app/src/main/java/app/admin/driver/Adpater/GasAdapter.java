package app.admin.driver.Adpater;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import app.admin.driver.Utils.Utils;
import app.admin.driver.databinding.ItemGasBinding;
import app.admin.driver.Network.TripsResponse.GasData;

public class GasAdapter extends RecyclerView.Adapter<GasAdapter.ViewHolder> {
    private final String TAG = GasAdapter.class.getSimpleName();
    private Context context;
    private List<GasData> list;
    private OnItemClickListener onItemClickListener;


    public void updateList(List<GasData> filteredList) {
        list.clear();
        list.addAll(filteredList);
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public GasAdapter(Context context, List<GasData> list, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        ItemGasBinding binding = ItemGasBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ItemGasBinding binding = holder.binding;
        GasData item = list.get(position);
        binding.amount.setText(item.getAmount());

        binding.time.setText(Utils.getDateTimeWeek(item.getCreatedAt()));



        if (item.getPaymentType().equals("0")) {
            binding.paymentType.setText("Cash");
        } else {
            binding.paymentType.setText("Online");
        }
        if (item.getImage() != null && !item.getImage().isEmpty()) {
            try {
                ImageView[] imageViews = new ImageView[]{binding.img1, binding.img2, binding.img3};
                for (int i = 0; i < item.getImage().size(); i++) {
                    int finalI = i;
                    imageViews[i].setOnClickListener(v -> {
                        Utils.showImageDialog(context,item.getImage().get(finalI));
                    });

                    Glide.with(context)
                            .load(item.getImage().get(i))
                            .into(imageViews[i]);
                }
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("MTAG", "onBindViewHolder 01:" + e);
            }
        }


        holder.itemView.setOnClickListener(v -> {
            onItemClickListener.onItemClick(position);

        });
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemGasBinding binding;

        public ViewHolder(ItemGasBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}