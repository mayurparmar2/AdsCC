package com.app.coroutinedemo.Network.Retrofit.Response

data class User(
    val body: String,
    val id: Int,
    val title: String,
    val userId: Int
)
