package com.app.coroutinedemo.Network.Room.Mvvm

import android.app.Application
import com.app.coroutinedemo.Network.Retrofit.ApiService
import com.app.coroutinedemo.Network.Retrofit.Response.User
import com.app.coroutinedemo.Network.Retrofit.RetrofitInstance
import com.app.coroutinedemo.Network.Room.AppDatabase
import com.app.coroutinedemo.Network.Room.Dao.UserDao
import com.app.coroutinedemo.Network.Room.Entity.UserEntity

import androidx.lifecycle.LiveData
import com.app.coroutinedemo.Network.Retrofit.Response.UserX

class UserRepository(application: Application) {
    private val userDao: UserDao
    private val apiService: ApiService

    init {
        val database = AppDatabase.getDatabase(application)
        userDao = database.userDao()
        apiService = RetrofitInstance.api
    }

    suspend fun getUsersFromApi(): List<User> {
        return apiService.getUsers()
    }

    fun getUsersFromDb(): LiveData<List<UserEntity>> {
        return userDao.getAllUsers()
    }

    suspend fun insertUser(user: UserEntity) {
        userDao.insert(user)
    }
}

