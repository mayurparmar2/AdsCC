package com.app.coroutinedemo
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.app.coroutinedemo.Network.Retrofit.ApiService
import com.app.coroutinedemo.Network.Retrofit.Response.User
import com.app.coroutinedemo.Network.Retrofit.Response.UserX
import com.app.coroutinedemo.Network.Retrofit.RetrofitInstance
import com.app.coroutinedemo.Network.Room.Mvvm.UserViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private val userViewModel: UserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        val apiService: ApiService = RetrofitInstance.api
//        apiService.getUsers2().enqueue(object :Callback<UserX>{
//            override fun onResponse(call: Call<UserX>, response: Response<UserX>) {
//                response.body()?.forEach{
//                    Log.e("TAG", "onCreate: ${it.id}")
//                }
//            }
//            override fun onFailure(call: Call<UserX>, it: Throwable) {
//                Log.e("TAG", "onCreate: ${it.message}")
//            }
//
//        })
        userViewModel.fetchUsers()
        userViewModel.getUsers().observe(this, Observer { users ->
            users.map {
                Log.e("TAG", "onCreate: $it")
            }
        })
    }
}
