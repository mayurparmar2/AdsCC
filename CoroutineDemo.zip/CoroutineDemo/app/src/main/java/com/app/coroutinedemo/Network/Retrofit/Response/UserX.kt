package com.app.coroutinedemo.Network.Retrofit.Response

class UserX : ArrayList<User>()