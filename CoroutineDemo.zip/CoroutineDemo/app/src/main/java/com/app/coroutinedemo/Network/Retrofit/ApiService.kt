package com.app.coroutinedemo.Network.Retrofit

import com.app.coroutinedemo.Network.Retrofit.Response.User
import com.app.coroutinedemo.Network.Retrofit.Response.UserX
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("posts")
    suspend fun getUsers(): List<User>

    @GET("posts")
    fun getUsers2(): Call<UserX>

}
