package com.app.coroutinedemo.Network.Room.Dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.app.coroutinedemo.Network.Room.Entity.UserEntity

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(users: UserEntity)

    @Query("SELECT * FROM UserEntity")
    fun getAllUsers(): LiveData<List<UserEntity>>
}
