package com.app.coroutinedemo.Network.Room.Mvvm

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.app.coroutinedemo.Network.Room.Entity.UserEntity
import kotlinx.coroutines.launch

class UserViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: UserRepository = UserRepository(application)

    fun fetchUsers() {
        viewModelScope.launch {
            val users = repository.getUsersFromApi()
            Log.e("TAG", "fetchUsers: " + users.size)
            users.forEach {
                repository.insertUser(UserEntity(it.id, it.body, it.title, it.userId))
            }
        }
    }

    fun getUsers(): LiveData<List<UserEntity>> {
        return repository.getUsersFromDb()
    }
}
